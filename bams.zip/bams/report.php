<?php
if(isset($_GET['content_sw']))  {
	$content_sw = $_GET['content_sw'];
}

if(isset($_POST['content_sw']))  {
	$content_sw = $_POST['content_sw'];
}
if(!isset($content_sw)) {
	echo "content_sw is not set";
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	<meta name="description" content="....PUT SOMETHING HERE....." />
	<meta name="keywords" content="BLAH, BLAHBLAH, ....." />
    <title> </title>
    <link rel="stylesheet" href="styles/reports.css" type="text/css" />
	<link rel="stylesheet" href="styles/printreports.css" media=print type="text/css" />
    <script src="scripts/jquery.js"></script>
    <!-- <script src="scripts/     .js"></script> -->
  </head>
  <body>
	<?php
    switch ($content_sw) {
		case 1:	include("reports/empemployeereport.php");
				break;
		case 2:	include("reports/sltslotsreport.php");
				break;
		case 3:	include("reports/gtstasksheet.php");
				break;
		default :
				echo "Invalid content_sw";
				echo "$content_sw";
	}
	?>
  </body>
</html>
