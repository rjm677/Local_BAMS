<?php
// test_array.php

$x = 112;
echo $x;
echo '<br>';
$z = array(
		array(" "),
		array(" "),
		array(" ")
	);
	
$z[0][0] = $x;

var_dump($z);













?>