<!-- EMPemployeeReport.php -->
<script>
$(document).ready(function()  {
	$("#printIt").click(function()  {
	window.print();
	});
});
</script>
<div id=operationButtons>

<div id=printIt>
<span>Print Report</span>
</div>


<div id=EMPreturn>
	<a href="index.php?content_sw=6&attention_bar=Make a Selection&title=Employee Menu">Return</a>
</div> 
</div>

<?php
require_once('includes/truefalse.php');
$formfeed = FALSE;
$i = 0;
$PageNumb = 1;
function outputReportHeader($formfeed, $PageNumb) {  
  if($formfeed)  {
	echo "</div class=EMPreportDetail>\n";
	echo "<div class=\"EMPBanner PageBreak\">\n";
  } else {
	
	echo "<div class=\"EMPBanner\">\n";
  }
  
  echo "<div class=EMPmyHeadings>\n";
				echo "<h2>\n";
				echo "BlaisCo's <br>\n";
				echo "BAMS: BlaisCo's Aisle Maintainers System <br>\n";
				echo "Employees in the Database\n";
				echo "<br>\n";
				$today = getdate();
				$month = $today['month'];
				$day   = $today['mday'];
				$year  = $today['year'];
				$string_today = $month . ' ' . $day . ', ' . $year;
				echo $string_today ."\n";
				echo "</h2>\n";
				echo "<h3>Page Number: " . $PageNumb . "</h3>\n";
  echo "</div>\n";  //EMPmyHeadings
		
	
echo "<div class=EMPreportHeadings>\n"; 
	echo "<div class=\"EMPwarehouseNoHeading\">\n";
		echo "<span>Warehouse No.</span>\n";
	echo "</div>\n"; 
	echo "<div class=EMPshiftHeading>\n";
		echo "<span>Shift</span>\n";
	echo "</div>\n";
	echo "<div  class=EMPFirstNameHeading>\n";	
		echo "<span>First Name</span>\n";
	echo "</div>\n";
	echo "<div  class=EMPlastNameHeading>\n";
		echo "<span>Last Name</span>\n";
	echo "</div>\n";
	echo "<div class=EMPmanNumberHeading>\n";
		echo "<span>Man Number</span>\n";
	echo "</div>\n"; 
echo "</div>\n"; //End of EMPReportHeadings Div. 

 echo "</div>\n"; //End of container Div for everything above the actual data. 
echo "<div class=EMPreportDetail>\n";
} //End of function outputReportHeader. 
?>   

<?php
require_once('includes/connect_vars.inc.php');
$dbc_RPT_EMP = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_RPT_EMP)  {
	echo "Failed to connect to Database server.<br>\n";
}  else  {
		$query_RPT_EMP  = "SELECT * \n";
		$query_RPT_EMP .= "FROM employees \n";
		$query_RPT_EMP .= "ORDER by WarehouseNo, Shift, LastName ";
	
		$data_RPT_EMP   = mysqli_query($dbc_RPT_EMP, $query_RPT_EMP);
		if(!$data_RPT_EMP)  {
			echo "Query failed to execute<br>\n";
		}  else  {
			if(mysqli_affected_rows($dbc_RPT_EMP) < 1)  {
				echo "No Data<br>\n";
			}  else  {
					if(!$i)  {
						 outputReportHeader(FALSE,$PageNumb);
						 $PageNumb++;
					} 
					while ($row_RPT_EMP = mysqli_fetch_array($data_RPT_EMP))  {
						$WarehouseNo = $row_RPT_EMP['WarehouseNo'];
						$Shift       = $row_RPT_EMP['Shift'];
						$FirstName   = $row_RPT_EMP['FirstName'];
						$LastName    = $row_RPT_EMP['LastName'];
						$manNumber   = $row_RPT_EMP['manNumber'];
						
						$LastName = stripslashes($LastName);
						
						if($i > 26) {
							outputReportHeader(TRUE,$PageNumb);
							$i = 0;
							$PageNumb++;
						}
						 echo "<div class=EMPdataRecord>\n"; 
						
						echo "<div class=EMPfield1>\n";
						echo $WarehouseNo;
						echo "</div>\n";
		
						echo "<div class=EMPfield2>\n";
						echo $Shift;
						echo "</div>\n";
		
						echo "<div class=EMPfield3>\n";
						echo $FirstName;
						echo "</div>\n";
		
						echo "<div class=EMPfield4>\n";
						echo $LastName;
						echo "</div>\n";
		
						echo "<div class=EMPfield5>\n";
						echo $manNumber;
						echo "</div>\n";
						
						 echo "</div>\n";  //class=EMPdataRecord.
						$i++;
					
					} //end of while loop.
echo "</div class=EMPreportDetail>\n";
} // end of else for have data.
} //end of else for good mysqli_query execution.
} //End of else for good mysqli_connect.

?>
 