<?php
//Reports/GTStaskSheet.php
//Generate Task Sheet.
?>
<script>
$(document).ready(function()  {
	$("#printIt").click(function()  {
	window.print();
	});
});
</script>

<div id=operationButtons>
	<div id=printIt>
		<span>Print Sheets</span>
	</div>
	<div id=GTSreturn>
		<a href="index.php?content_sw=17&attention_bar=Please fill out form&title=Generate Task Sheet">Return</a>
	</div> 
</div>
<?php
//FUNCTION AREA



function reportHeading($pageNo, $page_break)  {
	//echo "I am in reportHeading";
	echo "<div class=\"GTSBanner $page_break\">";
		echo "Aisle Maintainer - Record of slots leveled <span>Pg No: " . "$pageNo" . '</span>';
	echo '</div>';
	echo '<div id=GTSHeadingFrame>';
		echo'<div class=GTSslotHeading>';
			echo 'Slot';
		echo '</div>';
		echo '<div class=GTSlevelHeader>';
			echo 'Leveled';
		echo '</div>';
		echo '<div class=GTSslotHeading>';
			echo 'Slot';
		echo '</div>';
		echo '<div class=GTSlevelHeader>';
			echo 'Leveled';
		echo '</div>';
		echo '<div class=GTSslotHeading>';
			echo 'Slot';
		echo '</div>';
		echo '<div class=GTSlevelHeader>';
			echo 'Leveled';
		echo '</div>';
		echo '<div class=GTSslotHeading>';
			echo 'Slot';
		echo '</div>';
		echo '<div class="GTSlevelHeader GTSLastGuy">';
			echo 'Leveled';
		echo '</div>';	
	echo '</div>';
} // End of function reportHeading().		

function reportDetail($printColumn001, $printColumn002, $printColumn003, $printColumn004) {
		//echo "I am in reportDetail";
		echo '<div class=GTSdetailLineFrame>';
			echo '<div class=GTSdetail_lineSlot>';
				echo $printColumn001;
			echo '</div>';
			echo '<div class=GTSd_lineLeveled>';
				//echo 'Y <input type=checkbox disabled=disabled>';
				echo 'Y <img src=images/checkbox.jpg>';
				echo 'N <img src=images/checkbox.jpg>';
			echo '</div>';
		
		
			echo '<div class=GTSdetail_lineSlot>';
				echo $printColumn002;
			echo '</div>';
			echo '<div class=GTSd_lineLeveled>';
				echo 'Y <img src=images/checkbox.jpg>';
				echo 'N <img src=images/checkbox.jpg>';
			echo '</div>';
		
		
			echo '<div class=GTSdetail_lineSlot>';
				echo $printColumn003;
			echo '</div>';
			echo '<div class=GTSd_lineLeveled>';
				echo 'Y <img src=images/checkbox.jpg>';
				echo 'N <img src=images/checkbox.jpg>';
			echo '</div>';
			echo '<div class=GTSdetail_lineSlot>';
				echo $printColumn004;
			echo '</div>';
			echo '<div class="GTSd_lineLeveled GTSLastDetail">';
				echo 'Y <img src=images/checkbox.jpg>';
				echo 'N <img src=images/checkbox.jpg>';
			echo '</div>';
		
		
		echo '</div>';		
} //end of function reportDetail().  


function Footer($EmployeeName, $EmployeeNumber, $ReportDate) {
//echo "I am in Footer";
echo '<div class = the_footer> ';
		echo '<div class=EmployeeNameDiv>';
		echo 	'Name: ';
		echo 	"$EmployeeName";
		echo '</div>';
		echo '<div class=EmployeeNumberDiv>';
		echo 'Man Number: ';
		echo 	$EmployeeNumber;
		echo '</div>';
		echo '<div class=ReportDateDiv>';
		echo 	'Date: ' . "$ReportDate";
		echo '</div>';
		
echo '</div>';
}
/*
function PageBreak($pageNo, $EmployeeName, $EmployeeNumber, $ReportDate, $slotBank) {
echo "I am in PageBreak";
if($pageNo != 1) {
	Footer($EmployeeName, $EmployeeNumber, $ReportDate);
}
reportHeading($pageNo);
Dump_slotBank($printColumn, $printRow, $slotBank);
$pageNo++;
return $pageNo;
} //End of function PageBreak
*/



//MAIN BODY OF SCRIPT
require_once('includes/truefalse.php');
require_once('includes/connect_vars.inc.php');
$starting_slot_found = FALSE;  
$ending_slot_found=FALSE;
$phpOkay = TRUE;
$error_msg = " ";
$pageNo = 1;
$page_break = " ";

$slotBank = array(array(),array(),array(),array());
for($i = 0; $i < 4; $i++) {
	for($j = 0; $j < 29; $j++) {
		$slotBank[$i][$j] = ' ';
	}
}
//var_dump($slotBank);
/*
$slotBank = array(
		array(' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '),
		array(' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '),
		array(' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '),
		array(' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')
	);
*/
$ReportDate = date('m/j/Y');
	
	

/*	$month = $today['j'];
	$day   = $today['m'];
	$year  = $today['y'];

	$ReportDate = $month . ' ' . $day . ', ' . $year;
*/
$I_am_not_a_loop = TRUE; // using to break to end of file on error.
while($I_am_not_a_loop) {
	$I_am_not_a_loop = FALSE;
	//var_dump($I_am_not_a_loop);
$dbc_RPT_GTS = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_RPT_GTS) {
	$error_msg = "mysqli_connect has failed to create a database connection\n";
	$phpOkay = FALSE;
	break;
} else {


$GTSemployeeNumber 	= mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSemployeeNumber']));
$GTSemployeeName 	= mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSemployeeName']));
$GTSwarehouseNo_sw 	= mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSwarehouseNo_sw']));
$GTSstartingaisle 	= mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSstartingaisle']));
$GTSstartingBay 	= mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSstartingBay']));
$GTSEndingAisle 	= mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSEndingAisle']));
$GTSEndingBay 	    = mysqli_real_escape_string($dbc_RPT_GTS, trim($_POST['GTSEndingBay']));

$GTSEndingBaySideCode = $GTSEndingBay % 2;
$GTSStartingBaySideCode = $GTSstartingBay % 2;




if(!isset($_POST['level_1']))  {
	$level_1 = FALSE;
} else {
	$level_1 = TRUE;
}

if(!isset($_POST['level_2']))  {
	$level_2 = FALSE;
} else {
	$level_2 = TRUE;
}

if(!isset($_POST['level_3']))  {
	$level_3 = FALSE;
} else {
	$level_3 = TRUE;
}



//Debug block.

/*
echo "GTSemployeeNumber: "  . $GTSemployeeNumber . "<br>\n";
echo "GTSemployeeName: "    . $GTSemployeeName   . "<br>\n";
echo "GTSwarehouseNo_sw: "  . $GTSwarehouseNo_sw . "<br>\n";
echo "GTSstartingaisle: "   . $GTSstartingaisle  . "<br>\n";
echo "GTSstartingBay:"      .  $GTSstartingBay   . "<br>\n";
echo "level_1: "            . $level_1           . "<br>\n";
echo "level_2: "            . $level_2           . "<br>\n";
echo "level_3: "            . $level_3           . "<br>\n";
echo "GTSEndingAisle: "     . $GTSEndingAisle    . "<br>\n";
echo "GTSEndingBay: "       . $GTSEndingBay      . "<br>\n";

*/ 
//End of debug block.
 
//$starting_slot  = get_starting_slot($GTSstartingBay, $level_1, $level_2, $GTSstartingaisle);

$int_GTSEndingBay = (int) $GTSEndingBay;
if($int_GTSEndingBay < 10)  {
	if(strlen($GTSEndingBay) == 1) {
		$GTSEndingBay = "0" . "$GTSEndingBay";
		}
	}

/*
if($level_3)  {
	$GTSEndingLevel = 3;
} elseif($level_2) {
	$GTSEndingLevel = 2;
} else {
	$GTSEndingLevel = 1;
}
echo "GTSEndingLevel: " . "$GTSEndingLevel" . "<br>\n";
$sideCode = $GTSEndingBay%2;


$query_GTS_001  = "SELECT l.slotsPerBay \n"; 
$query_GTS_001 .= "FROM warehouse w \n";
$query_GTS_001 .= "INNER JOIN aisle a \n";
$query_GTS_001 .= "ON (w.WarehouseID = a.WarehouseID) \n";
$query_GTS_001 .= "INNER JOIN sides si \n";
$query_GTS_001 .= "ON (a.AisleID = si.AisleID) \n";
$query_GTS_001 .= "INNER JOIN bay b \n";
$query_GTS_001 .= "ON (si.sidesID = b.sidesID) \n";
$query_GTS_001 .= "INNER JOIN level l \n";
$query_GTS_001 .= "ON (b.bayID = l.bayID) \n";
$query_GTS_001 .= "WHERE w.WarehouseID = '{$GTSwarehouseNo_sw}' \n";
$query_GTS_001 .= "AND a.Aisle = '{$GTSEndingAisle}' \n";
$query_GTS_001 .= "AND si.SideCode = '{$sideCode}' \n";
$query_GTS_001 .= "AND b.bay = '{$GTSEndingBay}' \n";
$query_GTS_001 .= "AND l.the_level = '{$GTSEndingLevel}'";
		
$data_GTS   = mysqli_query($dbc_RPT_GTS, $query_GTS_001);
if(!$data_GTS)  {
	$error_msg = "Failed to establish a good query database resource while determining slots per bay of ending level<br>\n";
	$phpOkay = FALSE;
	break;
} else {
	$numRows = mysqli_affected_rows($dbc_RPT_GTS);
	if($numRows != 1) {
		$error_msg = "Error -- Query should have produced one row with slots per bay of last slot, numrows = " . "$numRows<br>\n";
		$phpOkay = FALSE;
		break;
	} else {
		$row_GTS = mysqli_fetch_array($data_GTS);
		if(!$row_GTS) {
			$error_msg = "Error -- fetch for ending slots per bay has failed<br>\n";
			$phpOkay = FALSE;
			break;
		} else {
			$GTSslotsPerBay = $row_GTS['slotsPerBay'];
	
	$Ending_slot_of_slot = ($GTSEndingLevel * 10) + $GTSslotsPerBay;
	$GTS_EndingSlot = "$GTSEndingAisle" . "-" . "$GTSEndingBay" . "$Ending_slot_of_slot";
		
	
	//echo "starting_slot: " . "$starting_slot" . "<br>\n";
	//echo "GTS_EndingSlot "  . "$GTS_EndingSlot" . "<br>\n";;
	} //End of else for good database connection - mysqli_query.
	} //End of else for one row with slots per bay of last slot produced.
	}//good fetch of slots per bay of last level.
*/
	
	if($level_1) {
		if($level_2) {
			if($level_3) {
				$level_sw = 1; //1,1,1
			} else {
				$level_sw = 2; //1,1,0
			}
		} else { //not $level_2   
			if($level_3) {
				$level_sw = 3; //1,0,1
			} else {
				$level_sw = 4; //1,0,0
			}
		}
	} else { //not $level_1.
		if($level_2) {
			if($level_3) {
				$level_sw = 5; //0,1,1
			} else {
				$level_sw = 6; //0,1,0
			}
		} else { //not $level_2   
			if($level_3) {
				$level_sw = 7; //0,0,1
			} else {
				$level_sw = 8; //0,0,0
				$error_msg =  "javaScript validation failed, no level has been clicked.<br>\n";
				$phpOkay = FALSE;
				break;
			}
		}
	}
	
	$level_array = array(""," ", 										//case #1
						 "AND l.the_level = 1 OR l.the_level = 2 \n",	//case #2
						 "AND l.the_level = 1 or l.the_level = 3 \n",	//case #3
						 "AND l.the_level = 1 \n",						//case #4
						 "AND l.the_level = 3 OR l.level = 2 \n",		//case #5
						 "AND l.the_level = 2 \n",						//case #6
						 "AND l.the_level = 3 \n");						//case #7
//+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
// Determine what Starting Aisle Id is
//=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
    $query_GTS_002  = "SELECT a.AisleID ";
	$query_GTS_002 .= "FROM warehouse w \n";
	$query_GTS_002 .= "INNER JOIN aisle a \n";
	$query_GTS_002 .= "ON (w.WarehouseID = a.WarehouseID) \n";
	$query_GTS_002 .= "WHERE w.WarehouseID = '{$GTSwarehouseNo_sw}' \n";
	$query_GTS_002 .= "AND a.Aisle = '{$GTSstartingaisle}'\n";
	
	$data_GTS_002   = mysqli_query($dbc_RPT_GTS, $query_GTS_002);
	if(!$data_GTS_002)  {
		$error_msg = "Failed to establish a good query when trying to determine primary key of starting aisle<br>\n";
		$phpOkay = FALSE;
		break;
	} else {
		//echo "hello from line 378";
		$numRows = mysqli_affected_rows($dbc_RPT_GTS);
		if($numRows != 1) {
			$error_msg = "Failed to obtain one AisleID for query_GTS_002<br>\n";
			$phpOkay = FALSE;
			break;
		} else {
			$row_GTS_002 = mysqli_fetch_array($data_GTS_002);
			$starting_aisleID = $row_GTS_002['AisleID'];
			//echo "starting_aisleID: " . "$starting_aisleID" . "<br>\n";
//+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
// Determine what Ending Aisle Id is
//=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
			
			$query_GTS_003  = "SELECT a.AisleID ";
			$query_GTS_003 .= "FROM warehouse w \n";
			$query_GTS_003 .= "INNER JOIN aisle a \n";
			$query_GTS_003 .= "ON (w.WarehouseID = a.WarehouseID) \n";
			$query_GTS_003 .= "WHERE w.WarehouseID = '{$GTSwarehouseNo_sw}' \n";
			$query_GTS_003 .= "AND a.Aisle = '{$GTSEndingAisle}'\n";
	
			$data_GTS_003   = mysqli_query($dbc_RPT_GTS, $query_GTS_003);
			if(!$data_GTS_003)  {
				$error_msg = "Failed to execute query 003 when trying to determine primary key of Ending aisle<br>\n";
				$phpOkay = FALSE;
				break;
			} else {
				$numRows = mysqli_affected_rows($dbc_RPT_GTS);
				if($numRows != 1) {
					$error_msg = "Failed to obtain one AisleID for query_GTS_003<br>\n";
					$phpOkay = FALSE;
					break;
				} else {
					$row_GTS_003 = mysqli_fetch_array($data_GTS_003);
					if(!$row_GTS_003) {
						$error_msg = "Fetch failed while trying to determine primary key for ending slot\n";
						$phpOkay = FALSE;
						break;
					} else {
						$Ending_aisleID = $row_GTS_003['AisleID'];
				//echo "Ending aisle primary key is: " . "$Ending_aisleID";
					}
				}
			}
//+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
// This is our rough extract from the database which is based on whole aisles
//=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
			
		$query_GTS_004  = "SELECT sl.slot \n"; 
		$query_GTS_004 .= "FROM warehouse w \n";
		$query_GTS_004 .= "INNER JOIN aisle a \n";
		$query_GTS_004 .= "ON (w.WarehouseID = a.WarehouseID) \n";
		$query_GTS_004 .= "INNER JOIN sides si \n";
		$query_GTS_004 .= "ON (a.AisleID = si.AisleID) \n";
		$query_GTS_004 .= "INNER JOIN bay b \n";
		$query_GTS_004 .= "ON (si.sidesID = b.sidesID) \n";
		$query_GTS_004 .= "INNER JOIN level l \n";
		$query_GTS_004 .= "ON (b.bayID = l.bayID) \n";
		$query_GTS_004 .= "INNER JOIN slots sl \n";
		$query_GTS_004 .= "on (l.levelID = sl.levelID) \n";
		$query_GTS_004 .= "WHERE w.WarehouseID = '{$GTSwarehouseNo_sw}' \n";
		$query_GTS_004 .= "AND a.AisleID >= '{$starting_aisleID}' \n";
		$query_GTS_004 .= "AND a.AisleID <= '{$Ending_aisleID}' \n";
		$query_GTS_004 .= $level_array["$level_sw"];
		$query_GTS_004 .= "ORDER BY w.WarehouseNo, a.Aisle, si.SideCode, \n";
		$query_GTS_004 .= "b.bay, l.the_level, sl.slot \n";	
		//$query_GTS_004 .= "LIMIT 10";
		
		//echo $query_GTS_004;
		$data_GTS_004 = mysqli_query($dbc_RPT_GTS, $query_GTS_004);
		if(!$data_GTS_004)  {
			$error_msg = "Query 004 has failed at mysqli_query statement.\n";
			$phpOkay = FALSE;
			break;
		} else {
			$numrows004 = mysqli_affected_rows($dbc_RPT_GTS);
			if($numrows004 < 1) {
				$error_msg = "No data\n";
				$phpOkay = FALSE;
				break;
				
			} else {
				//var_dump($numrows004);
				//Initialize my two following pointers to the first element of the 2-D array.
				$printColumn = 0;
				$printRow    = 0;
				
				while($row_GTS_004 = mysqli_fetch_array($data_GTS_004)) {
					$slot = $row_GTS_004['slot'];
					
					//echo "my slot is: " . "$slot";
		
					$Extract_Aisle = substr($slot, 0, 2);
					$Extract_Bay   = substr($slot, 3,2);
					//echo "Extract_Aisle: " . "$Extract_Aisle" .'<br>';
					//echo "Extract_Bay: " . "$Extract_Bay" .'<br>';
					
					$Extract_Bay_Side_Code = $Extract_Bay % 2;
					
					
					if($Extract_Aisle == $GTSstartingaisle) {
						if($Extract_Bay_Side_Code == $GTSStartingBaySideCode) {
							if($Extract_Bay < $GTSstartingBay) {
								//echo " I am in continue section <br>";
								continue;
							}
						}
					}
					
					
					if($Extract_Aisle == $GTSEndingAisle) { 
						if($Extract_Bay_Side_Code == $GTSEndingBaySideCode){
							if($Extract_Bay > $GTSEndingBay) {
								//echo " I am at break line <br>";
								break;
							}
						}
					}
						//echo "hello from line 456";
						if($printRow > 28) {
							$printRow = 0;
							$printColumn++;
						}
						if($printColumn > 3) {
							//var_dump(slotBank);
							//print the footer if pageno != 1.
							//print the header.
							//print the detail lines.
							if ($pageNo !=1) {
								$page_break = "PageBreak";
								Footer($GTSemployeeName, $GTSemployeeNumber, $ReportDate);
							}
							//PageBreak($pageNo, $EmployeeName, $EmployeeNumber, $ReportDate, $slotBank);
							
								
							reportHeading($pageNo, $page_break);
							$pageNo++;
							$page_break = "PageBreak";
							//+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
							// Print Detail lines
							//+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
							for($m = 0; $m < 29; $m++) {
								reportDetail($slotBank[0][$m], $slotBank[1][$m], $slotBank[2][$m], $slotBank[3][$m]);
							}
							
							$printColumn = 0;
							$printRow = 0;
							//$slotBank = init_slotBank();
							for($i = 0; $i < 4; $i++) {
								for($j = 0; $j < 29; $j++) {
									$slotBank[$i][$j] = ' ';
								}
							}
						}
						
						
						// send $slot into slot bank.
						//echo "line 471 says that slot is: " . "$slot";
						//setSlotBank($slotBank, $printColumn, $printRow, $slot);
						$slotBank[$printColumn][$printRow] = $slot;
						//echo "slotbank is: ";
						//echo $slotBank[$printColumn][$printRow];
						//echo '<br>';
						$printRow++;
						//var_dump($slotBank);
					}	
							
							
					
				} //End of while loop.
				//var_dump($slotBank);
				if ($pageNo !=1) {
					$page_break = "PageBreak";
					Footer($GTSemployeeName, $GTSemployeeNumber, $ReportDate);
				}
				reportHeading($pageNo, $page_break);
				for($m = 0; $m < 29; $m++) {
					reportDetail($slotBank[0][$m], $slotBank[1][$m], $slotBank[2][$m], $slotBank[3][$m]);
				}
				Footer($GTSemployeeName, $GTSemployeeNumber, $ReportDate);
				
				
				
				
				
			} //End of have data per mysqli_affected_rows.
		} // end of else for good mysqli_query 004.

	//} //End of Else for have good query resource for get begining aisle primary key.
	} //End of Else for obtained a good primary key for starting key.
//	$threadID= mysqli_thread_id($dbc_RPT_GTS);
//	mysqli_kill($dbc_RPT_GTS, $threadID);
//	mysqli_close($dbc_RPT_GTS);
	} //end of else for made a good database connection
} // end of ($I_am_not_a_loop) loop	.
	
if(!$phpOkay) {
	echo $error_msg;
}

?>




