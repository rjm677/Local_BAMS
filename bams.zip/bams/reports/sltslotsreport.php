<!-- SLTslotsReport.php -->
<script>
$(document).ready(function()  {
	$("#printIt").click(function()  {
	window.print();
	});
});
</script>
<div id=operationButtons>

<div id=printIt>
<span>Print Report</span>
</div>


<div id=SLTreturn>
	<a href="index.php?content_sw=15&attention_bar=Make a Selection&title=Aisle Changes Menu">Return</a>
</div> 
</div>

<?php
//
require_once('includes/truefalse.php');
$formfeed = FALSE;
$i = 0;
$PageNumb = 1;
function outputReportHeader($formfeed,$PageNumb) {  
 //use $formfeed to handle form feed class.
if($formfeed) {
		echo "</div class=SLTreportDetail>\n";
		echo "<div class=\"SLTBanner PageBreak\">\n";
		//PageBreak is use on more than one report.
		
} else {
	echo "<div class=\"SLTBanner\">\n";
	
}
echo "<div class=SLTmyHeadings>\n";
	echo "<h2>\n";
	echo "BlaisCo's <br>\n";
	echo "BAMS: BlaisCo's Aisle Maintainers System <br>\n";
	echo "Slots in the Database\n";
	echo "<br>\n";
	$today = getdate();
	$month = $today['month'];
	$day   = $today['mday'];
	$year  = $today['year'];
	$string_today = $month . ' ' . $day . ', ' . $year;
	echo $string_today ."\n";
	echo "</h2>\n";
	echo "<h3>Page Number: " . $PageNumb . "</h3>\n";
echo "</div>\n"; //End of div myHeadings
echo "</div>\n"; //End of div SLTBanner
echo "<div class=SLTReportHeadings>\n";

	echo "<div class=SLTwarehouseNoHeading>\n";
		echo "<span>Warehouse No.</span>\n";
	echo "</div>\n"; 
	
	echo "<div class=SLTAisleHeading>\n";
		echo "<span>Aisle</span>\n";
	echo "</div>\n";
	
	echo "<div  class=SLTSideHeading>\n";	
		echo "<span>Side of the Aisle</span>\n";
	echo "</div>\n";
	
	echo "<div  class=SLTbayHeading>\n";
		echo "<span>Bay</span>\n";
	echo "</div>\n";
	
	echo "<div class=SLTSlotsPerBayHeading>\n";
		echo "<span>Slots Per Bay</span>\n";
	echo "</div>\n"; 

	echo "<div  class=SLTLevelHeading>\n";
		echo "<span>Level</span>\n";
	echo "</div>\n";
	
	echo "<div class=SLTslotHeading>\n";
		echo "<span>Slot</span>\n";
	echo "</div>\n";
echo '</div>'; //End of div for class SLTReportHeadings.
echo "<div class=SLTreportDetail>\n";
} //End of function outputReportHeader.

require_once('includes/connect_vars.inc.php');
$dbc_RPT_SLT = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_RPT_SLT)  {
	echo "Failed to connect to Database server.<br>\n";
}  else  {
		$query_RPT_SLT  = "SELECT w.WarehouseNo, a.Aisle, si.SideCode, \n"; 
		$query_RPT_SLT .= "b.bay, l.slotsPerBay, l.the_level, sl.slot \n";
		$query_RPT_SLT .= "FROM warehouse w \n";
		$query_RPT_SLT .= "INNER JOIN aisle a \n";
		$query_RPT_SLT .= "ON (w.WarehouseID = a.WarehouseID) \n";
		$query_RPT_SLT .= "INNER JOIN sides si \n";
		$query_RPT_SLT .= "ON (a.AisleID = si.AisleID) \n";
		$query_RPT_SLT .= "INNER JOIN bay b \n";
		$query_RPT_SLT .= "ON (si.sidesID = b.sidesID) \n";
		$query_RPT_SLT .= "INNER JOIN level l \n";
		$query_RPT_SLT .= "ON (b.bayID = l.bayID) \n";
		$query_RPT_SLT .= "INNER JOIN slots sl \n";
		$query_RPT_SLT .= "on (l.levelID = sl.levelID) \n";
		$query_RPT_SLT .= "ORDER BY w.WarehouseNo, a.Aisle, si.SideCode, \n";
		$query_RPT_SLT .= "b.bay, l.the_level, sl.slot\n";
		
		$data_RPT_SLT   = mysqli_query($dbc_RPT_SLT, $query_RPT_SLT);
		if(!$data_RPT_SLT)  {
			echo "Query failed to execute<br>\n";
		}  else  {
			if(mysqli_affected_rows($dbc_RPT_SLT) < 1)  {
				echo "No Data<br>\n";
			}  else  {
					if(!$i)  {
						 outputReportHeader(FALSE,$PageNumb);
						 $PageNumb++;
					} 
					while ($row_RPT_SLT  = mysqli_fetch_array($data_RPT_SLT))  {

						   $WarehouseNo  = $row_RPT_SLT['WarehouseNo'];
						   $Aisle        = $row_RPT_SLT['Aisle'];
						   $SideCode     = $row_RPT_SLT['SideCode'];
						   $bay          = $row_RPT_SLT['bay'];
						   $slotsPerBay  = $row_RPT_SLT['slotsPerBay'];
						   $the_level    =  $row_RPT_SLT['the_level'];
						   $slot         =  $row_RPT_SLT['slot'];
						
						if($i > 26) {
							outputReportHeader(TRUE,$PageNumb);
							$i = 0;
							$PageNumb++;
						}
						 echo "<div class=SLTdataRecord>\n"; 
						
						echo "<div class=SLTfield1>\n";
						echo $WarehouseNo;
						echo "</div>\n";
		
						echo "<div class=SLTfield2>\n";
						echo $Aisle;
						echo "</div>\n";
		
						echo "<div class=SLTfield3>\n";
						if ($SideCode == 0) {
							echo "Even\n";
						} elseif ($SideCode == 1) {
							echo "Odd\n";
						} else {
							echo "Error\n";
						}
						echo "</div>\n";
		
						echo "<div class=SLTfield4>\n";
						echo $bay;
						echo "</div>\n";
		
						echo "<div class=SLTfield5>\n";
						echo $slotsPerBay;
						echo "</div>\n";
						
						echo "<div class=SLTfield6>\n";
						echo $the_level;
						echo "</div>\n";

						echo "<div class=SLTfield7>\n";
						echo $slot;
						echo "</div>\n";



						echo "</div>\n";  //class=SLTdataRecord.
						$i++;
						
					} //end of while loop.
echo "</div class=SLTreportDetail>\n";
} // end of else for have data.
} //end of else for good mysqli_query execution.
} //End of else for good mysqli_connect.

?>
 
  

















