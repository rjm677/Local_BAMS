  //Test_GetName.php

<form name=myform action=GetName.php method=post>
<input type=text name=GTSemployeeNumber>
<input type=submit name=mySubmitButton>
</form>

