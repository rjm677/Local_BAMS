<?php
$FPPmanNumber = $_POST['FPPmanNumber'];
$FPPanswer = $_POST['FPPanswer'];
$info = $_POST['info'];
echo $FPPmanNumber;
echo "<br>";
echo $FPPanswer;
echo "<br>";
echo $info;
var_dump($info);
?>