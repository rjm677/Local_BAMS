<?php
session_start();

$AdminUsersIndex = 0;
$AdminUsersName  = "";
$welcomeMsg      = "";
if(!isset($BackgroundRed)) {
    $BackgroundRed   = 0;
}

$scriptOut  = '<script>';
$scriptOut .= '$(document).ready(function(){';
$scriptOut .= '$("#Attention_bar").css({"background-color":"#990000"});';
$scriptOut .= '});';

$scriptOut .= '</script>';


//var_dump($_SESSION);
//echo "AdminUsersIndex is" . $_SESSION['AdminUsersIndex'];
if(isset($_SESSION['AdminUsersIndex'])) {
  //echo "logged in";  //debug
  
    $AdminUsersIndex = $_SESSION['AdminUsersIndex'];
    $AdminUsersName  = $_SESSION['AdminUsersName'];
    $showLogout      = 1;
  
    if(isset($_POST['content_sw']))    {
        $content_sw = $_POST['content_sw'];
     }
    if(isset($_POST['title']))   {
        $title = htmlspecialchars($_POST['title']);
    }
    if(isset($_POST['attention_bar']))    {
     $attention_bar = htmlspecialchars($_POST['attention_bar']);
    }
	
	if(isset($_GET['content_sw']))    {
        $content_sw = (int)   htmlspecialchars($_GET['content_sw']);
     }
    if(isset($_GET['title']))   {
        $title = htmlspecialchars($_GET['title']);
    }
    if(isset($_GET['attention_bar']))    {
     $attention_bar = htmlspecialchars($_GET['attention_bar']);
    }
	
	if(isset($_GET['linkAction']))  {
		$linkAction = htmlspecialchars($_GET['linkAction']);
    }
	if(isset($_POST['linkAction']))  {
		$linkAction = htmlspecialchars($_POST['linkAction']);
	}
// Put logic for CPP Stage 02 here.  
if(isset($_POST['CPPbuttonNext'])) { 
			//echo "click acknowledged";
			include('includes/cpp_stage02_formhandler.inc.php');
} elseif(isset($_POST['EIPsubmit']))  {
			include('includes/eippartialformhandler.php');
} elseif(isset($_POST['EMPsearchbutton'])) {
			include('includes/espartialformhandler.php');
} elseif(isset($_POST['EDPsubmit'])) {
			include('includes/edppartialformhandler.php');			
} elseif(isset($_POST['EEPsubmit'])) {
			include('includes/eeppartialformhandler.php');
} elseif(isset($_POST['ACGsubmit'])) {
			include('includes/acgpartialformhandler.php');
} elseif(isset($_POST['ACDsubmit'])) {
			include('includes/acdpartialformhandler.php');
} else  {
    //Set up for login screen on an error. 
	if(!isset($content_sw)or !isset($title)or!isset($attention_bar)or!is_numeric($content_sw)) { 
       
		$logout_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/logout.php';
		header('Location: ' . $logout_url);		
		
		
    } 
	//Will fall throught if coming from a menu or form and the three GET or POST variables are set properly.
}

  
//============================================================================== 
} else { // Not logged in, $_SESSION['AdminUsersIndex'] not set.
         // Try to loggin user. 
	
	if(!isset($content_sw)) {
			$content_sw = 1;
	}
		 
    require_once('includes/loginformhandler.inc.php');	
    if(isset($_POST['submit_form']))  {
        $LFPreturnVars = loginFormHandler($_POST['manNumber'], $_POST['passWord']);  
        //Call Php function found in .inc file.
        $attention_bar = $LFPreturnVars['attention_bar'];
        $BackgroundRed = $LFPreturnVars['BackgroundRed'];
        $content_sw    = $LFPreturnVars['content_sw'];
        $title  = $LFPreturnVars['title'];
        $AdminUsersName = $LFPreturnVars['AdminUsersName'];
       //echo "Index.php adm name is: " . $AdminUsersName;
        if (isset($_SESSION['AdminUsersIndex']))  {  //Successful Login.
            $showLogout = 1; 
        } else  {  //login attempt failed    
            $showLogout = 0; 
        }
    } else {  //The Input type = submit button on the login screen was not clicked.
		if(!isset($showLogout))  {
				$showLogout= 0;
			}
	            
    if(isset($_GET['linkAction']))  {  // pull up new partials when one of 3 aux buttons on login screen clicked.
            
		if(isset($_GET['content_sw']))    {
			$content_sw = $_GET['content_sw'];
		}  
		if(isset($_GET['title']))   {
			$title = htmlspecialchars($_GET['title']);
		}
		if(isset($_GET['attention_bar']))    {
			$attention_bar = htmlspecialchars($_GET['attention_bar']);
		}   
	} else {
		if(isset($_POST['LRP_Submit']))  {  //here is where I add logic for admn Register main button click.
			
			 include('includes/regadmnformhandler.inc.php');
		} else  {
				//echo "I am just above my if statement";
				if(isset($_POST['CPPbuttonContinue']))  {
					include('includes/cpp_stage01_formhandler.inc.php');
					//echo "submit button on stage one of change password clicked";
				} elseif(isset($_POST['FPPsearchForPassword'])) {
					//echo "FPPsearchforpassword clicked.";
					include('includes/fpp_stage01_formhandler.inc.php');
				} else  {
				//This is where I go when first pass thru website occurs.
				$content_sw = 1;
				$title   = "Login Form";
				$attention_bar = "Please Login";
				$showLogout = 0;
				//echo "I am here.";
					
				
				} //end of else of CPPbuttonContinue clicked.		
	} //end of else of linkAction set.
    } //End of no buttons clicked on LFP, other than main submit button.
} //End of submit button not clicked.
} //End of Not logged in.
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	<meta name="description" content="....PUT SOMETHING HERE....." />
	<meta name="keywords" content="BLAH, BLAHBLAH, ....." />
    <title> </title>
    <link rel="stylesheet" href="styles/bams.css" type="text/css" />
    <script src="scripts/jquery.js" type="text/javascript"> </script>
    <!--<script src="Scripts/BAMS.js" type="text/javascript"> </script> -->
	
  </head>
  <body>


<?php
	
	if (!empty($AdminUsersName))  {
		$welcomeMsg = "Welcome: " . $AdminUsersName;  
               //$AdminUsersName can be empty except on a good login.
	}
	echo "<div id=greating>\n";
	echo "<div id=welcome> $welcomeMsg </div>\n"; 
                    //$welcome is empty when a good login did not occur.
	if($showLogout) { //we only allow user to log out when logged in.
		echo "<div id=logout> <a href=logout.php> Logout </a></div>\n";
    }
	echo "</div>\n";	

?>	
	
	<header>
		<hgroup>
		<h1> B.A.M.S. </h1>
		<h2> BlaisCo's Aisle Maintainer's System </h2>
		</hgroup>
	</header>
	
    <div id=Attention_bar>
	<h2> <?php echo $attention_bar; ?>   </h2>
	</div>	

	<div id=title_bar>
	<h2> <?php echo $title; ?></h2>
	</div>
<?php
if($BackgroundRed) {	
	echo $scriptOut;
}
?>
	<section>
<?php
       //var_dump($content_sw);
        switch ($content_sw) {
            case 1:    include('includes/loginformpartial.php');    
                            break;
            case  2:   include('includes/mainmenupartial.php');
                            break;
            case  3:    include('includes/loginregisterpartial.php');
                            break;                        
            case  4:    include('includes/fpppartialstage01.php');
                            break;
            case  5:    include('includes/changepasswordpartialstage01.php');
                            break;
            case  6:    include('includes/employeemenupartial.php');
                            break;
            case  7:    include('includes/changepasswordpartialstage02.php');
							break;
			case  8:    include('includes/fpppartialstage02.php');
                            break;
			case  9:    include('includes/eippartial.php');
                            break;
			case  10:   include('includes/employeesearch.php');
                            break;
			case  11:   include('includes/eeppartial.php');
                            break;
			case  12:   include('includes/edppartial.php');
                            break;							
			case  13:   include('includes/acgpartial.php');
                            break;							
			case  14:   include('includes/acdpartial.php');
                            break;
			case  15:   include('includes/aislechangesmenu.php');
                            break;
			case  16:	include('includes/acdpartial.php');
                            break;
			case  17:	include('includes/gtspartial.php');
                            break;
							
			default:    include('includes/loginformpartial.php');
            }
?>    
    
	</section>
	
	<footer>
	<a href="#"> Contact Web Developer </a>
	</footer>
  </body>
</html>