<?php
//GetName.php
require_once('includes/truefalse.php');
require_once('includes/connect_vars.inc.php');
define('FAILED_CONNECT', -1);
define('NOT_FOUND', -2);
define('NO_NUMBER', -3);
define('QUERY_FAILED', -4);
define('FETCH_FAILED', -5);

$okayPHP = 1;

$dbc_GetName = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_GetName)  {
	$GTSemployeeName = 'X';
	$okayPHP = FAILED_CONNECT;
} else  {
	$GTSemployeeNumber = mysqli_real_escape_string($dbc_GetName, trim($_POST['GTSemployeeNumber']));
	if(!$GTSemployeeNumber)  {
		$okayPHP = NO_NUMBER;
	} else {
		$Query  = "SELECT FirstName, LastName \n";
		$Query .= "FROM employees \n";
		$Query .= "WHERE manNumber = '{$GTSemployeeNumber}'\n";
		
		$data_GetName = mysqli_query($dbc_GetName, $Query);
		if(!$data_GetName)  {
			$okayPHP = QUERY_FAILED;
		} else {
			$row_GetName = mysqli_fetch_array($data_GetName);
			if(mysqli_affected_rows($dbc_GetName) != 1) {
					$okayPHP = NOT_FOUND;
			} else {
			if(!$row_GetName)  {
				$okayPHP = FETCH_FAILED;	
				} else {
					$FirstName = $row_GetName['FirstName'];
					$LastName  = $row_GetName['LastName'];
					$Name      = $FirstName . ' ' .$LastName  ;
					$Response = array( 'GTSemployeeName' => $Name, 'PHPstatus' => $okayPHP);
					$ResponseJSON = json_encode($Response);
					echo $ResponseJSON;
				} //end of else for found one row as is correct.
			}//End of Else for good fetch_array operation.
		}//End of Else for good query execution.
	}//End of else for posted good employee number.
	
	if($okayPHP != 1) {
		$Name = 'X';
		$Response = array( 'EmployeeName' => $Name, 'PHPstatus' => $okayPHP);
		$ResponseJSON = json_encode($Response);
		echo $ResponseJSON;
	}
} //End of else for good database connection.







?>