//LoginFormPartialScript.js
alert("Hi There");  /*
	$("#buttonRegAdmin").click(function()  {
		$("#title_bar").html("<h2>Registration Form<h2>");
		$("#Attention_bar").html("<h2>Please Register as an Admin. User<h2>");
		$("#Attention_bar").css({"background-color" : "#004D99"});
		$("#Attention_bar").css({"color": "#FFFFFF"});
		$("section").load("Partials/LoginRegisterPartial.htm");
	});
	
	$("#changePassword").click(function()  {
		$("#Attention_bar").css({"background-color" : "#004D99"});
		$("#Attention_bar").css({"color": "#FFFFFF"});
		$("#Attention_bar").html("<h2>Please Change your Password</h2>");
		$("#title_bar").html("<h2>Change Password Form</h2>");
		$("section").load("Partials/ChangePasswordPartial.htm");
	});
	
	
	
	$("#forgotPassword").click(function()  {
		$("#Attention_bar").css({"background-color" : "#004D99"});
		$("#Attention_bar").css({"color": "#FFFFFF"});
		$("#Attention_bar").html("<h2>Please Enter the Following Fields</h2>");
		$("#title_bar").html("<h2>Forgot Password Form</h2>");	
		$("section").load("Partials/FPPpartial.htm");
	});
	
	$("#submit_form").click(function()  {
	//alert('in submit_form'); 
		var manNumber = $("#manNumber").val();
		//alert('manNumber is: ' + manNumber);
		
		var passWord  = $("#passWord").val();
		//alert('password is: ' + passWord);
		LoginOBJ = {};
		LoginOBJ.manNumber = manNumber;
		LoginOBJ.passWord  = passWord;
		
		
		Xglobal.AdminUsersIndex = 0;
		Xglobal.AdminUsersName  = 'X';
		var jqXHR = $.post("login.php", LoginOBJ, loginResponse , "json" ); 
		alert(jqXHR.error());
	});

	function loginResponse(ResponseJSON)  {
		alert('in loginReponse function'); 
		var Attentionbar   = ResponseJSON.Attention_bar;
		alert(Attentionbar);
		Attentionbar = '<h2>' + Attentionbar + '<h2>';
		var okayJS          = ResponseJSON.okayPHP;
		alert(okayJS);
		$("#Attention_bar").html(Attentionbar);/*
		
		if(okayJS)  { 
			var AdminUsersIndex     = ResponseJSON.AdminUsersIndex;
			
			Xglobal.AdminUsersIndex = AdminUsersIndex;
			
			var AdminUsersName      = ResponseJSON.AdminUsersName;
			Xglobal.AdminUsersName  = AdminUsersName; 
			
			var WelomeMsg = '<h2>Welcome ' + AdminUsersName '</h2>;
			alert(WelomeMsg);
			$("#welcome").html(WelcomeMsg).show();
			
			$("#logout").show();
			
			$("title_bar").html('<h2>Main Menu</h2>');
		
			$("#Attention_bar").css({"background-color":"#004D99"});
			
			$("section").load("MainMenuPartial.htm");
		}else {   //okayJS is false.
			$("#Attention_bar").css({"background-color":"#990000"});
		} */
	}
