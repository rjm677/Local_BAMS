$(document).ready(function()  {
$("#CPPbuttonBackgroundCancel").click(function()  {
		$("#Attention_bar").css({"background-color":"#004D99"});
		$("#Attention_bar").css({"color":"#FFFFFF"});
		$("#Attention_bar").html("<h2>Please Log In</h2>");
		$("#title_bar").html("<h2>Log In Form</h2>");
		$("section").load("partials/LoginFormPartial.htm")
	});
});



