//MainMenuPartialScript.js

$("#MainMenuEmployeeChanges").click(function()  {
	$("#title_bar").html("<h2>Employee Menu</h2>");
	$("#Attention_bar").css({"background-color":"#004D99"});
	$("#Attention_bar").css({"color":"#FFFFFF"});
	$("#Attention_bar").html("<h2>Please Make a Selection<h2>");
	$("section").load("partials/EmployeeMenuPartial.htm");
});