//LoginRegisterPartialScript.js



$("#LRP_Submit").click(function ()  {
	var formVarObj = {};
	formVarObj.LRP_manNumber       = $("#LRP_manNumber").val();
	formVarObj.LRP_AdminName       = $("#LRP_AdminName").val();
	formVarObj.LRP_passWord        = $("#LRP_passWord").val();
	formVarObj.LRP_passWordConfirm = $("#LRP_passWordConfirm").val();
	formVarObj.LRP_phoneNumber     = $("#LRP_phoneNumber").val();
	formVarObj.LRP_mothersName     = $("#LRP_mothersName").val();
	formVarObj.LRP_fathersName     = $("#LRP_fathersName").val();
	formVarObj.LRP_masterKey       = $("#LRP_masterKey").val();

	$.post("RegAdmn.php", formVarObj, returnScript, "json");
	});
	
	
	
	function returnScript(returnJSON)  {
		//alert('in returnScript');
		var attentionBar = returnJSON.attention_bar;
		var okay         = returnJSON.okay;
		var manNumberBlank         = returnJSON.setRed.LRP_manNumber;
		var AdminNameBlank		   = returnJSON.setRed.LRP_AdminName;
		var passWordBlank		   = returnJSON.setRed.LRP_passWord;
		var passWordConfirmBlank   = returnJSON.setRed.LRP_passWordConfirm;
		var phoneNumberBlank	   = returnJSON.setRed.LRP_phoneNumber;
		var mothersNameBlank       = returnJSON.setRed.LRP_mothersName;
		var fathersnameBlank	   = returnJSON.setRed.LRP_fathersName;
		var masterKeyBlank		   = returnJSON.setRed.LRP_masterKey;
		//alert(okay);
		//alert(passWordBlank);
		//alert(passWordConfirmBlank);
		if(okay) {

		} else {	
			//alert(attentionBar);
			$("#Attention_bar").html(attentionBar);
			$("#Attention_bar").css({"background-color":"#990000"})
			
			if(manNumberBlank) {$("#LRP_manNumber").css({"background-color":"#FF4242"});
			} else { $("#LRP_manNumber").css({"background-color":"#FFFFFF"})};
		
			if(AdminNameBlank) {$("#LRP_AdminName").css({"background-color":"#FF4242"});
			} else { $("#LRP_AdminName").css({"background-color":"#FFFFFF"})};
		
			if(passWordBlank) {$("#LRP_passWord").css({"background-color":"#FF4242"});
			} else { $("#LRP_passWord").css({"background-color":"#FFFFFF"})};
		
			if(passWordConfirmBlank) {$("#LRP_passWordConfirm").css({"background-color":"#FF4242"});
			} else { $("#LRP_passwordConfirm").css({"background-color":"#FFFFFF"})};
		
			if(phoneNumberBlank) {$("#LRP_phoneNumber").css({"background-color":"#FF4242"});
			} else { $("#LRP_phoneNumber").css({"background-color":"#FFFFFF"})};
			
			if(mothersNameBlank) {$("#LRP_mothersName").css({"background-color":"#FF4242"});
			} else { $("#LRP_mothersName").css({"background-color":"#FFFFFF"})};
		
			if(fathersnameBlank) {$("#LRP_fathersName").css({"background-color":"#FF4242"});
			} else { $("#LRP_fathersName").css({"background-color":"#FFFFFF"})};
		
			if(masterKeyBlank) {$("#LRP_masterKey").css({"background-color":"#FF4242"});
			} else { $("#LRP_masterKey").css({"background-color":"#FFFFFF"})};
		} 
	}
	
function returnScript2(returnJSON2)  {
	var attentionBar   = returnJSON2.attentionMsg;
	attentionBar = '<h2>' + attentionBar + '</h2>';
	//alert(attentionBar);
	var okay2           = returnJSON2.okay;

	$("#Attention_bar").html(attentionBar);
	if(okay2) {
		$("#Attention_bar").css({"background-color": "#004D99"});
		$("#title_bar").html("<h2>Main Menu</h2>");
		var name = 'Welcome: ' + $(LRP_AdminName).val();
		$("#welcome").show().html(name);
		$("#logout").show();
		$("section").load("Partials/MainMenuPartial.htm");
	} else { //not Okay, display a message w/ red background.
		$("#Attention_bar").css({"background-color":"#990000"});
	}

	
}









	

