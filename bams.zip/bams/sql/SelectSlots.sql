SELECT w.WarehouseNo, a.Aisle, si.SideCode, b.bay, l.slotsPerBay, l.the_level, sl.slot
FROM warehouse w
INNER JOIN aisle a
ON (w.WarehouseID = a.WarehouseID)
INNER JOIN sides si
ON (a.AisleID = si.AisleID)
INNER JOIN bay b
ON (si.sidesID = b.sidesID)
INNER JOIN level l
ON (b.bayID = l.bayID)
INNER JOIN slots sl
on (l.levelID = sl.levelID)
ORDER BY w.WarehouseNo, a.Aisle, si.SideCode, b.bay, l.the_level, sl.slot