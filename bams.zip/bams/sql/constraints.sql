constraints.sql

copy and paste each section into sql window on PhpMyAdmin tool.

	ALTER TABLE aisle
	ADD CONSTRAINT   warehouse_WarehouseID_FK
	FOREIGN KEY (WarehouseID) REFERENCES
	warehouse (WarehouseID)
============================================
	ALTER TABLE sides
	ADD CONSTRAINT      aisle_AisleID_FK
	FOREIGN KEY (AisleID) REFERENCES
	aisle(AisleID)
============================================
	ALTER TABLE bay
	ADD CONSTRAINT sides_sidesID_FK
	FOREIGN KEY (sidesID) REFERENCES
	sides(sidesID)
============================================
	ALTER TABLE level
	ADD CONSTRAINT   bay_bayID_FK
	FOREIGN KEY (bayID) REFERENCES
	bay(bayID)
============================================
	ALTER TABLE slots
	ADD CONSTRAINT level_levelID_FK
	FOREIGN KEY (levelID) REFERENCES
	level(levelID)
============================================












		