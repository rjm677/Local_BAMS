-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 17, 2014 at 10:43 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bams`
--
CREATE DATABASE IF NOT EXISTS `bams` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bams`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE IF NOT EXISTS `adminusers` (
  `AdminUsersIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `AdminUserName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phoneNumber` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'No () - just digits',
  `passWord` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `MothersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  `FathersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AdminUsersIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=87 ;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`AdminUsersIndex`, `manNumber`, `AdminUserName`, `phoneNumber`, `passWord`, `MothersName`, `FathersName`) VALUES
(64, '8084', 'Bob Morelli', '203 213-0725', 'WH8084', 'Lucy', 'Jim'),
(65, '8085', 'Dad', '203 677-2566', 'WH8085', 'Mili', 'Luigi'),
(66, '8086', 'Lucy', '203 677-2566', 'WH8086', 'Nunziatta', 'Francucc'),
(67, '8087', 'Dennis Hopper', '123', 'WH8087', 'mom', 'dad'),
(68, '8088', 'Marcia Hopkins', '123', 'WH8088', 'Mom', 'Dad'),
(70, '9051', 'Mike Roche', '666777', 'WH9051', 'Mary', 'Sam'),
(71, '7070', 'Kari Underwood', '203 124 4567', 'WH7070', 'Mom', 'Dad'),
(72, '2001', 'Ralph Lauren', '203 677-2566', 'WH2001', 'Mama', 'Popa'),
(73, '1234', 'Mary Smith', '860 123 4567', 'WH1234', 'Mother', 'Father'),
(74, '5678', 'Don Henley', '340 678 9124', 'WH5678', 'Esmerelda', 'Dennis'),
(75, '55990', 'Sam Snead', '222', 'WH55990', 'Mom', 'Dad'),
(78, '12377', 'Young Blood', '123', 'WH12377', 'Mommy', 'Daddy'),
(79, '2010', 'Warren Beatty', '123', 'WH2010', 'Mom', 'Dad'),
(80, '20116', 'Earl the Pearl', '245', 'WH20116', 'm', 'd'),
(81, '8089', 'Larry Niven', '2032130725', 'WH8089', 'Greta', 'Warren'),
(85, '4343', 'Kevin Sharp', '1234', 'WH4343', 'Mommy', 'Daddy'),
(86, '10199', 'Sanjay Gupta', '123', 'WH10199', 'Mommy', 'Daddy');

-- --------------------------------------------------------

--
-- Table structure for table `aisle`
--

CREATE TABLE IF NOT EXISTS `aisle` (
  `AisleID` int(11) NOT NULL AUTO_INCREMENT,
  `WarehouseID` int(11) NOT NULL,
  `Aisle` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AisleID`),
  KEY `warehouse_WarehouseID_FK` (`WarehouseID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- Table structure for table `bay`
--

CREATE TABLE IF NOT EXISTS `bay` (
  `bayID` int(11) NOT NULL AUTO_INCREMENT,
  `sidesID` int(11) NOT NULL,
  `bay` int(11) NOT NULL,
  PRIMARY KEY (`bayID`),
  KEY `sides_sidesID_FK` (`sidesID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=756 ;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employeeIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` int(11) NOT NULL,
  `LastName` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `FirstName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Shift` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`employeeIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=70 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employeeIndex`, `manNumber`, `LastName`, `FirstName`, `Shift`, `WarehouseNo`) VALUES
(28, 9000, 'Police', 'Sting', '1st', 101),
(29, 9001, 'Mia Mia', 'Maddona', '3rd', 101),
(30, 9002, 'Abdule', 'Paula', '1st', 101),
(31, 9003, 'Aiken', 'Clay', '1st', 101),
(32, 9004, 'Benatar', 'Patrick', '2nd', 101),
(33, 9005, 'Beegee', 'Sam', '1st', 101),
(34, 9006, 'Blunt', 'James', '3rd', 402),
(35, 9007, 'Bowie', 'David', '1st', 102),
(37, 9009, 'Carey', 'Mike', '2nd', 102),
(38, 9010, 'Clapton', 'Eric', '2nd', 102),
(39, 9011, 'Collins', 'Phil', '3rd', 102),
(40, 9012, 'Groban', 'Josh', '1st', 402),
(41, 9013, 'Mellancamp', 'John', '2nd', 402),
(42, 9014, 'Steward', 'Rod', '1st', 402),
(43, 9015, 'Van Dross', 'Luthor', '2nd', 402),
(44, 9016, 'Stark', 'Ringo', '3rd', 402),
(45, 9500, 'Andrews', 'Gavin', '2nd', 101),
(46, 9501, 'Bartos', 'Robert', '3rd', 102),
(47, 9502, 'Camilleri', 'Carmen', '1st', 402),
(48, 9503, 'Innis', 'David', '1st', 101),
(49, 9504, 'Hunter', 'Ralph', '3rd', 102),
(50, 9505, 'O\\''Brien', 'Henry', '1st', 102),
(51, 9506, 'Regina', 'Magda', '3rd', 101),
(52, 9507, 'Sangan', 'Kurt', '3rd', 101),
(53, 9508, 'Sheary', 'Cliff', '2nd', 402),
(54, 9509, 'Sweeney', 'Tom', '1st', 402),
(55, 9510, 'Woodford', 'Penny', '3rd', 402),
(56, 9511, 'Hartigan', 'Charlie', '2nd', 101),
(57, 9512, 'Hammick', 'Maura', '1st', 101),
(58, 9513, 'Gibb', 'Karen', '3rd', 101),
(59, 9514, 'Gebrian', 'Robin', '1st', 402),
(60, 9515, 'French', 'Katie', '1st', 102),
(61, 9516, 'Campagna', 'Karen', '1st', 402),
(62, 9517, 'Barnet', 'Kris', '3rd', 101),
(63, 9518, 'Atkins', 'Phyllis', '1st', 102),
(64, 9519, 'Seifts', 'Ellen', '3rd', 402),
(65, 9520, 'Gebrian', 'Robin', '3rd', 402),
(66, 9521, 'Mitchell', 'Paul', '1st', 102),
(67, 9522, 'Penwood', 'Tom', '3rd', 402),
(68, 9523, 'Prescott', 'Sara', '2nd', 101),
(69, 9524, 'Sperandio', 'Mark', '1st', 102);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `levelID` int(11) NOT NULL AUTO_INCREMENT,
  `bayID` int(11) NOT NULL,
  `slotsPerBay` int(11) NOT NULL,
  `the_level` int(11) NOT NULL,
  PRIMARY KEY (`levelID`),
  KEY `bay_bayID_FK` (`bayID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=797 ;

-- --------------------------------------------------------

--
-- Table structure for table `sides`
--

CREATE TABLE IF NOT EXISTS `sides` (
  `sidesID` int(11) NOT NULL AUTO_INCREMENT,
  `AisleID` int(11) NOT NULL,
  `SideCode` int(11) NOT NULL,
  PRIMARY KEY (`sidesID`),
  KEY `aisle_AisleID_FK` (`AisleID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE IF NOT EXISTS `slots` (
  `slotID` int(11) NOT NULL AUTO_INCREMENT,
  `levelID` int(11) NOT NULL,
  `slot` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `slot_of_slot` int(11) NOT NULL,
  PRIMARY KEY (`slotID`),
  KEY `level_levelID_FK` (`levelID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3500 ;

-- --------------------------------------------------------

--
-- Table structure for table `slotsleveled`
--

CREATE TABLE IF NOT EXISTS `slotsleveled` (
  `SlotsLeveledIndex` int(11) NOT NULL AUTO_INCREMENT,
  `Aisle` int(11) NOT NULL,
  `Bay` int(11) NOT NULL,
  `Position` int(11) NOT NULL,
  `YesLeveled` int(11) NOT NULL,
  `NoLeveled` int(11) NOT NULL,
  PRIMARY KEY (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tasksheet`
--

CREATE TABLE IF NOT EXISTS `tasksheet` (
  `TaskSheetIndex` int(11) NOT NULL AUTO_INCREMENT,
  `employeeIndex` int(11) NOT NULL,
  `SlotsLeveledIndex` int(11) NOT NULL,
  PRIMARY KEY (`TaskSheetIndex`),
  KEY `EmployeeIndexEmployeeTable_fk` (`employeeIndex`),
  KEY `SlotsLeveledIndex_SlotLeveled_fk` (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
  `WarehouseID` int(11) NOT NULL AUTO_INCREMENT,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`WarehouseID`),
  UNIQUE KEY `WarehouseNo` (`WarehouseNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`WarehouseID`, `WarehouseNo`) VALUES
(1, 101),
(2, 102),
(3, 402);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aisle`
--
ALTER TABLE `aisle`
  ADD CONSTRAINT `warehouse_WarehouseID_FK` FOREIGN KEY (`WarehouseID`) REFERENCES `warehouse` (`WarehouseID`);

--
-- Constraints for table `bay`
--
ALTER TABLE `bay`
  ADD CONSTRAINT `sides_sidesID_FK` FOREIGN KEY (`sidesID`) REFERENCES `sides` (`sidesID`);

--
-- Constraints for table `level`
--
ALTER TABLE `level`
  ADD CONSTRAINT `bay_bayID_FK` FOREIGN KEY (`bayID`) REFERENCES `bay` (`bayID`);

--
-- Constraints for table `sides`
--
ALTER TABLE `sides`
  ADD CONSTRAINT `aisle_AisleID_FK` FOREIGN KEY (`AisleID`) REFERENCES `aisle` (`AisleID`);

--
-- Constraints for table `slots`
--
ALTER TABLE `slots`
  ADD CONSTRAINT `level_levelID_FK` FOREIGN KEY (`levelID`) REFERENCES `level` (`levelID`);

--
-- Constraints for table `tasksheet`
--
ALTER TABLE `tasksheet`
  ADD CONSTRAINT `EmployeeIndexEmployeeTable_fk` FOREIGN KEY (`employeeIndex`) REFERENCES `employees` (`employeeIndex`),
  ADD CONSTRAINT `SlotsLeveledIndex_SlotLeveled_fk` FOREIGN KEY (`SlotsLeveledIndex`) REFERENCES `slotsleveled` (`SlotsLeveledIndex`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
