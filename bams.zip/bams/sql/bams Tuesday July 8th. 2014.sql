-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2014 at 07:05 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bams`
--
CREATE DATABASE IF NOT EXISTS `bams` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bams`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE IF NOT EXISTS `adminusers` (
  `AdminUsersIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `AdminUserName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phoneNumber` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'No () - just digits',
  `passWord` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `MothersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  `FathersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AdminUsersIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=87 ;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`AdminUsersIndex`, `manNumber`, `AdminUserName`, `phoneNumber`, `passWord`, `MothersName`, `FathersName`) VALUES
(64, '8084', 'Bob Morelli', '203 213-0725', 'WH8084', 'Lucy', 'Jim'),
(65, '8085', 'Dad', '203 677-2566', 'WH8085', 'Mili', 'Luigi'),
(66, '8086', 'Lucy', '203 677-2566', 'WH8086', 'Nonni', 'Francucc'),
(67, '8087', 'Dennis Hopper', '123', 'WH8087', 'mom', 'dad'),
(68, '8088', 'Marcia Hopkins', '123', 'WH8088', 'Mom', 'Dad'),
(70, '9051', 'Mike Roche', '666777', 'WH9051', 'Mary', 'Sam'),
(71, '7070', 'Kari Underwood', '203 124 4567', 'WH7070', 'Mom', 'Dad'),
(72, '2001', 'Ralph Lauren', '203 677-2566', 'WH2001', 'Mama', 'Popa'),
(73, '1234', 'Mary Smith', '860 123 4567', 'WH1234', 'Mother', 'Father'),
(74, '5678', 'Don Henley', '340 678 9124', 'WH5678', 'Esmerelda', 'Dennis'),
(75, '55990', 'Sam Snead', '222', 'WH55990', 'Mom', 'Dad'),
(78, '12377', 'Young Blood', '123', 'WH12377', 'Mommy', 'Daddy'),
(79, '2010', 'Warren Beatty', '123', 'WH2010', 'Mom', 'Dad'),
(80, '20116', 'Earl the Pearl', '245', 'WH20116', 'm', 'd'),
(81, '8089', 'Larry Niven', '2032130725', 'WH8089', 'Greta', 'Warren'),
(84, '888888', 'xxx', 'xxx', 'xxx', 'xxx', 'xxx'),
(85, '4343', 'Kevin Sharp', '1234', 'WH4343', 'Mommy', 'Daddy'),
(86, '10199', 'Sanjay Gupta', '123', 'WH10199', 'Mommy', 'Daddy');

-- --------------------------------------------------------

--
-- Table structure for table `aisle`
--

CREATE TABLE IF NOT EXISTS `aisle` (
  `AisleID` int(11) NOT NULL AUTO_INCREMENT,
  `WarehouseID` int(11) NOT NULL,
  `Aisle` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AisleID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `aisle`
--

INSERT INTO `aisle` (`AisleID`, `WarehouseID`, `Aisle`) VALUES
(1, 1, '51'),
(2, 1, '52');

-- --------------------------------------------------------

--
-- Table structure for table `bay`
--

CREATE TABLE IF NOT EXISTS `bay` (
  `bayID` int(11) NOT NULL AUTO_INCREMENT,
  `sidesID` int(11) NOT NULL,
  `bay` int(11) NOT NULL,
  PRIMARY KEY (`bayID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `bay`
--

INSERT INTO `bay` (`bayID`, `sidesID`, `bay`) VALUES
(1, 1, 4),
(2, 1, 6),
(3, 1, 8),
(4, 1, 10),
(5, 1, 12),
(6, 1, 14),
(7, 1, 16),
(8, 2, 4),
(9, 2, 6),
(10, 2, 8),
(11, 2, 10),
(12, 2, 12),
(13, 2, 14),
(14, 2, 16),
(15, 3, 3),
(16, 3, 5),
(17, 3, 7),
(18, 3, 9),
(19, 3, 11),
(20, 3, 13),
(21, 3, 15);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employeeIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` int(11) NOT NULL,
  `LastName` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `FirstName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Shift` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`employeeIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=70 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employeeIndex`, `manNumber`, `LastName`, `FirstName`, `Shift`, `WarehouseNo`) VALUES
(28, 9000, 'Police', 'Sting', '1st', 101),
(29, 9001, 'Mia Mia', 'Maddona', '3rd', 101),
(30, 9002, 'Abdule', 'Paula', '1st', 101),
(31, 9003, 'Aiken', 'Clay', '1st', 101),
(32, 9004, 'Benatar', 'Patrick', '2nd', 101),
(33, 9005, 'Beegee', 'Sam', '1st', 101),
(34, 9006, 'Blunt', 'James', '3rd', 402),
(35, 9007, 'Bowie', 'David', '1st', 102),
(37, 9009, 'Carey', 'Mike', '2nd', 102),
(38, 9010, 'Clapton', 'Eric', '2nd', 102),
(39, 9011, 'Collins', 'Phil', '3rd', 102),
(40, 9012, 'Groban', 'Josh', '1st', 402),
(41, 9013, 'Mellancamp', 'John', '2nd', 402),
(42, 9014, 'Steward', 'Rod', '1st', 402),
(43, 9015, 'Van Dross', 'Luthor', '2nd', 402),
(44, 9016, 'Stark', 'Ringo', '3rd', 402),
(45, 9500, 'Andrews', 'Gavin', '2nd', 101),
(46, 9501, 'Bartos', 'Robert', '3rd', 102),
(47, 9502, 'Camilleri', 'Carmen', '1st', 402),
(48, 9503, 'Innis', 'David', '1st', 101),
(49, 9504, 'Hunter', 'Ralph', '3rd', 102),
(50, 9505, 'O\\''Brien', 'Henry', '1st', 102),
(51, 9506, 'Regina', 'Magda', '3rd', 101),
(52, 9507, 'Sangan', 'Kurt', '3rd', 101),
(53, 9508, 'Sheary', 'Cliff', '2nd', 402),
(54, 9509, 'Sweeney', 'Tom', '1st', 402),
(55, 9510, 'Woodford', 'Penny', '3rd', 402),
(56, 9511, 'Hartigan', 'Charlie', '2nd', 101),
(57, 9512, 'Hammick', 'Maura', '1st', 101),
(58, 9513, 'Gibb', 'Karen', '3rd', 101),
(59, 9514, 'Gebrian', 'Robin', '1st', 402),
(60, 9515, 'French', 'Katie', '1st', 102),
(61, 9516, 'Campagna', 'Karen', '1st', 402),
(62, 9517, 'Barnet', 'Kris', '3rd', 101),
(63, 9518, 'Atkins', 'Phyllis', '1st', 102),
(64, 9519, 'Seifts', 'Ellen', '3rd', 402),
(65, 9520, 'Gebrian', 'Robin', '3rd', 402),
(66, 9521, 'Mitchell', 'Paul', '1st', 102),
(67, 9522, 'Penwood', 'Tom', '3rd', 402),
(68, 9523, 'Prescott', 'Sara', '2nd', 101),
(69, 9524, 'Sperandio', 'Mark', '1st', 102);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `levelID` int(11) NOT NULL AUTO_INCREMENT,
  `bayID` int(11) NOT NULL,
  `slotsPerBay` int(11) NOT NULL,
  `the_level` int(11) NOT NULL,
  PRIMARY KEY (`levelID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`levelID`, `bayID`, `slotsPerBay`, `the_level`) VALUES
(1, 1, 2, 1),
(2, 2, 2, 1),
(3, 3, 2, 1),
(4, 4, 2, 1),
(5, 5, 2, 1),
(6, 6, 2, 1),
(7, 7, 2, 1),
(8, 1, 5, 2),
(9, 2, 5, 2),
(10, 3, 5, 2),
(11, 4, 5, 2),
(12, 5, 5, 2),
(13, 6, 5, 2),
(14, 7, 5, 2),
(15, 8, 2, 1),
(16, 9, 2, 1),
(17, 10, 2, 1),
(18, 11, 2, 1),
(19, 12, 2, 1),
(20, 13, 2, 1),
(21, 14, 2, 1),
(22, 8, 4, 2),
(23, 9, 4, 2),
(24, 10, 4, 2),
(25, 11, 4, 2),
(26, 12, 4, 2),
(27, 13, 4, 2),
(28, 14, 4, 2),
(29, 8, 4, 3),
(30, 9, 4, 3),
(31, 10, 4, 3),
(32, 11, 4, 3),
(33, 12, 4, 3),
(34, 13, 4, 3),
(35, 14, 4, 3),
(36, 15, 2, 1),
(37, 16, 2, 1),
(38, 17, 2, 1),
(39, 18, 2, 1),
(40, 19, 2, 1),
(41, 20, 2, 1),
(42, 21, 2, 1),
(43, 15, 5, 2),
(44, 16, 5, 2),
(45, 17, 5, 2),
(46, 18, 5, 2),
(47, 19, 5, 2),
(48, 20, 5, 2),
(49, 21, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sides`
--

CREATE TABLE IF NOT EXISTS `sides` (
  `sidesID` int(11) NOT NULL AUTO_INCREMENT,
  `AisleID` int(11) NOT NULL,
  `SideCode` int(11) NOT NULL,
  PRIMARY KEY (`sidesID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `sides`
--

INSERT INTO `sides` (`sidesID`, `AisleID`, `SideCode`) VALUES
(1, 1, 0),
(2, 2, 0),
(3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE IF NOT EXISTS `slots` (
  `slotID` int(11) NOT NULL AUTO_INCREMENT,
  `levelID` int(11) NOT NULL,
  `slot` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `slot_of_slot` int(11) NOT NULL,
  PRIMARY KEY (`slotID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=169 ;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`slotID`, `levelID`, `slot`, `slot_of_slot`) VALUES
(1, 1, '51-0411', 11),
(2, 1, '51-0412', 12),
(3, 2, '51-0611', 11),
(4, 2, '51-0612', 12),
(5, 3, '51-0811', 11),
(6, 3, '51-0812', 12),
(7, 4, '51-1011', 11),
(8, 4, '51-1012', 12),
(9, 5, '51-1211', 11),
(10, 5, '51-1212', 12),
(11, 6, '51-1411', 11),
(12, 6, '51-1412', 12),
(13, 7, '51-1611', 11),
(14, 7, '51-1612', 12),
(15, 8, '51-0421', 21),
(16, 8, '51-0422', 22),
(17, 8, '51-0423', 23),
(18, 8, '51-0424', 24),
(19, 8, '51-0425', 25),
(20, 9, '51-0621', 21),
(21, 9, '51-0622', 22),
(22, 9, '51-0623', 23),
(23, 9, '51-0624', 24),
(24, 9, '51-0625', 25),
(25, 10, '51-0821', 21),
(26, 10, '51-0822', 22),
(27, 10, '51-0823', 23),
(28, 10, '51-0824', 24),
(29, 10, '51-0825', 25),
(30, 11, '51-1021', 21),
(31, 11, '51-1022', 22),
(32, 11, '51-1023', 23),
(33, 11, '51-1024', 24),
(34, 11, '51-1025', 25),
(35, 12, '51-1221', 21),
(36, 12, '51-1222', 22),
(37, 12, '51-1223', 23),
(38, 12, '51-1224', 24),
(39, 12, '51-1225', 25),
(40, 13, '51-1421', 21),
(41, 13, '51-1422', 22),
(42, 13, '51-1423', 23),
(43, 13, '51-1424', 24),
(44, 13, '51-1425', 25),
(45, 14, '51-1621', 21),
(46, 14, '51-1622', 22),
(47, 14, '51-1623', 23),
(48, 14, '51-1624', 24),
(49, 14, '51-1625', 25),
(50, 15, '52-0411', 11),
(51, 15, '52-0412', 12),
(52, 16, '52-0611', 11),
(53, 16, '52-0612', 12),
(54, 17, '52-0811', 11),
(55, 17, '52-0812', 12),
(56, 18, '52-1011', 11),
(57, 18, '52-1012', 12),
(58, 19, '52-1211', 11),
(59, 19, '52-1212', 12),
(60, 20, '52-1411', 11),
(61, 20, '52-1412', 12),
(62, 21, '52-1611', 11),
(63, 21, '52-1612', 12),
(64, 22, '52-0421', 21),
(65, 22, '52-0422', 22),
(66, 22, '52-0423', 23),
(67, 22, '52-0424', 24),
(68, 23, '52-0621', 21),
(69, 23, '52-0622', 22),
(70, 23, '52-0623', 23),
(71, 23, '52-0624', 24),
(72, 24, '52-0821', 21),
(73, 24, '52-0822', 22),
(74, 24, '52-0823', 23),
(75, 24, '52-0824', 24),
(76, 25, '52-1021', 21),
(77, 25, '52-1022', 22),
(78, 25, '52-1023', 23),
(79, 25, '52-1024', 24),
(80, 26, '52-1221', 21),
(81, 26, '52-1222', 22),
(82, 26, '52-1223', 23),
(83, 26, '52-1224', 24),
(84, 27, '52-1421', 21),
(85, 27, '52-1422', 22),
(86, 27, '52-1423', 23),
(87, 27, '52-1424', 24),
(88, 28, '52-1621', 21),
(89, 28, '52-1622', 22),
(90, 28, '52-1623', 23),
(91, 28, '52-1624', 24),
(92, 29, '52-0431', 31),
(93, 29, '52-0432', 32),
(94, 29, '52-0433', 33),
(95, 29, '52-0434', 34),
(96, 30, '52-0631', 31),
(97, 30, '52-0632', 32),
(98, 30, '52-0633', 33),
(99, 30, '52-0634', 34),
(100, 31, '52-0831', 31),
(101, 31, '52-0832', 32),
(102, 31, '52-0833', 33),
(103, 31, '52-0834', 34),
(104, 32, '52-1031', 31),
(105, 32, '52-1032', 32),
(106, 32, '52-1033', 33),
(107, 32, '52-1034', 34),
(108, 33, '52-1231', 31),
(109, 33, '52-1232', 32),
(110, 33, '52-1233', 33),
(111, 33, '52-1234', 34),
(112, 34, '52-1431', 31),
(113, 34, '52-1432', 32),
(114, 34, '52-1433', 33),
(115, 34, '52-1434', 34),
(116, 35, '52-1631', 31),
(117, 35, '52-1632', 32),
(118, 35, '52-1633', 33),
(119, 35, '52-1634', 34),
(120, 36, '52-0311', 11),
(121, 36, '52-0312', 12),
(122, 37, '52-0511', 11),
(123, 37, '52-0512', 12),
(124, 38, '52-0711', 11),
(125, 38, '52-0712', 12),
(126, 39, '52-0911', 11),
(127, 39, '52-0912', 12),
(128, 40, '52-1111', 11),
(129, 40, '52-1112', 12),
(130, 41, '52-1311', 11),
(131, 41, '52-1312', 12),
(132, 42, '52-1511', 11),
(133, 42, '52-1512', 12),
(134, 43, '52-0321', 21),
(135, 43, '52-0322', 22),
(136, 43, '52-0323', 23),
(137, 43, '52-0324', 24),
(138, 43, '52-0325', 25),
(139, 44, '52-0521', 21),
(140, 44, '52-0522', 22),
(141, 44, '52-0523', 23),
(142, 44, '52-0524', 24),
(143, 44, '52-0525', 25),
(144, 45, '52-0721', 21),
(145, 45, '52-0722', 22),
(146, 45, '52-0723', 23),
(147, 45, '52-0724', 24),
(148, 45, '52-0725', 25),
(149, 46, '52-0921', 21),
(150, 46, '52-0922', 22),
(151, 46, '52-0923', 23),
(152, 46, '52-0924', 24),
(153, 46, '52-0925', 25),
(154, 47, '52-1121', 21),
(155, 47, '52-1122', 22),
(156, 47, '52-1123', 23),
(157, 47, '52-1124', 24),
(158, 47, '52-1125', 25),
(159, 48, '52-1321', 21),
(160, 48, '52-1322', 22),
(161, 48, '52-1323', 23),
(162, 48, '52-1324', 24),
(163, 48, '52-1325', 25),
(164, 49, '52-1521', 21),
(165, 49, '52-1522', 22),
(166, 49, '52-1523', 23),
(167, 49, '52-1524', 24),
(168, 49, '52-1525', 25);

-- --------------------------------------------------------

--
-- Table structure for table `slotsleveled`
--

CREATE TABLE IF NOT EXISTS `slotsleveled` (
  `SlotsLeveledIndex` int(11) NOT NULL AUTO_INCREMENT,
  `Aisle` int(11) NOT NULL,
  `Bay` int(11) NOT NULL,
  `Position` int(11) NOT NULL,
  `YesLeveled` int(11) NOT NULL,
  `NoLeveled` int(11) NOT NULL,
  PRIMARY KEY (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tasksheet`
--

CREATE TABLE IF NOT EXISTS `tasksheet` (
  `TaskSheetIndex` int(11) NOT NULL AUTO_INCREMENT,
  `employeeIndex` int(11) NOT NULL,
  `SlotsLeveledIndex` int(11) NOT NULL,
  PRIMARY KEY (`TaskSheetIndex`),
  KEY `EmployeeIndexEmployeeTable_fk` (`employeeIndex`),
  KEY `SlotsLeveledIndex_SlotLeveled_fk` (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
  `WarehouseID` int(11) NOT NULL AUTO_INCREMENT,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`WarehouseID`),
  UNIQUE KEY `WarehouseNo` (`WarehouseNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`WarehouseID`, `WarehouseNo`) VALUES
(1, 101),
(2, 102),
(3, 402);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tasksheet`
--
ALTER TABLE `tasksheet`
  ADD CONSTRAINT `EmployeeIndexEmployeeTable_fk` FOREIGN KEY (`employeeIndex`) REFERENCES `employees` (`employeeIndex`),
  ADD CONSTRAINT `SlotsLeveledIndex_SlotLeveled_fk` FOREIGN KEY (`SlotsLeveledIndex`) REFERENCES `slotsleveled` (`SlotsLeveledIndex`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
