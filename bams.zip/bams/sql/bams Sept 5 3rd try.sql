-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 05, 2014 at 05:22 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bams`
--
CREATE DATABASE IF NOT EXISTS `bams` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bams`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE IF NOT EXISTS `adminusers` (
  `AdminUsersIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `AdminUserName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phoneNumber` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'No () - just digits',
  `passWord` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `MothersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  `FathersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AdminUsersIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=87 ;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`AdminUsersIndex`, `manNumber`, `AdminUserName`, `phoneNumber`, `passWord`, `MothersName`, `FathersName`) VALUES
(64, '8084', 'Bob Morelli', '203 213-0725', 'WH8084', 'Lucy', 'Jim'),
(65, '8085', 'Dad', '203 677-2566', 'WH8085', 'Mili', 'Luigi'),
(66, '8086', 'Lucy', '203 677-2566', 'WH8086', 'Nunziatta', 'Francucc'),
(67, '8087', 'Dennis Hopper', '123', 'WH8087', 'mom', 'dad'),
(68, '8088', 'Marcia Hopkins', '123', 'WH8088', 'Mom', 'Dad'),
(70, '9051', 'Mike Roche', '666777', 'WH9051', 'Mary', 'Sam'),
(71, '7070', 'Kari Underwood', '203 124 4567', 'WH7070', 'Mom', 'Dad'),
(72, '2001', 'Ralph Lauren', '203 677-2566', 'WH2001', 'Mama', 'Popa'),
(73, '1234', 'Mary Smith', '860 123 4567', 'WH1234', 'Mother', 'Father'),
(74, '5678', 'Don Henley', '340 678 9124', 'WH5678', 'Esmerelda', 'Dennis'),
(75, '55990', 'Sam Snead', '222', 'WH55990', 'Mom', 'Dad'),
(78, '12377', 'Young Blood', '123', 'WH12377', 'Mommy', 'Daddy'),
(79, '2010', 'Warren Beatty', '123', 'WH2010', 'Mom', 'Dad'),
(80, '20116', 'Earl the Pearl', '245', 'WH20116', 'm', 'd'),
(81, '8089', 'Larry Niven', '2032130725', 'WH8089', 'Greta', 'Warren'),
(85, '4343', 'Kevin Sharp', '1234', 'WH4343', 'Mommy', 'Daddy'),
(86, '10199', 'Sanjay Gupta', '123', 'WH10199', 'Mommy', 'Daddy');

-- --------------------------------------------------------

--
-- Table structure for table `aisle`
--

CREATE TABLE IF NOT EXISTS `aisle` (
  `AisleID` int(11) NOT NULL AUTO_INCREMENT,
  `WarehouseID` int(11) NOT NULL,
  `Aisle` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AisleID`),
  KEY `warehouse_WarehouseID_FK` (`WarehouseID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `aisle`
--

INSERT INTO `aisle` (`AisleID`, `WarehouseID`, `Aisle`) VALUES
(7, 1, '51'),
(8, 1, '52'),
(9, 1, '53');

-- --------------------------------------------------------

--
-- Table structure for table `bay`
--

CREATE TABLE IF NOT EXISTS `bay` (
  `bayID` int(11) NOT NULL AUTO_INCREMENT,
  `sidesID` int(11) NOT NULL,
  `bay` int(11) NOT NULL,
  PRIMARY KEY (`bayID`),
  KEY `sides_sidesID_FK` (`sidesID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=102 ;

--
-- Dumping data for table `bay`
--

INSERT INTO `bay` (`bayID`, `sidesID`, `bay`) VALUES
(67, 10, 4),
(68, 10, 6),
(69, 10, 8),
(70, 10, 10),
(71, 10, 12),
(72, 10, 14),
(73, 10, 16),
(74, 11, 4),
(75, 11, 6),
(76, 11, 8),
(77, 11, 10),
(78, 11, 12),
(79, 11, 14),
(80, 11, 16),
(81, 12, 3),
(82, 12, 5),
(83, 12, 7),
(84, 12, 9),
(85, 12, 11),
(86, 12, 13),
(87, 12, 15),
(88, 13, 3),
(89, 13, 5),
(90, 13, 7),
(91, 13, 9),
(92, 13, 11),
(93, 13, 13),
(94, 13, 15),
(95, 14, 4),
(96, 14, 6),
(97, 14, 8),
(98, 14, 10),
(99, 14, 12),
(100, 14, 14),
(101, 14, 16);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employeeIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` int(11) NOT NULL,
  `LastName` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `FirstName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Shift` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`employeeIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=70 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employeeIndex`, `manNumber`, `LastName`, `FirstName`, `Shift`, `WarehouseNo`) VALUES
(28, 9000, 'Police', 'Sting', '1st', 101),
(29, 9001, 'Mia Mia', 'Maddona', '3rd', 101),
(30, 9002, 'Abdule', 'Paula', '1st', 101),
(31, 9003, 'Aiken', 'Clay', '1st', 101),
(32, 9004, 'Benatar', 'Patrick', '2nd', 101),
(33, 9005, 'Beegee', 'Sam', '1st', 101),
(34, 9006, 'Blunt', 'James', '3rd', 402),
(35, 9007, 'Bowie', 'David', '1st', 102),
(37, 9009, 'Carey', 'Mike', '2nd', 102),
(38, 9010, 'Clapton', 'Eric', '2nd', 102),
(39, 9011, 'Collins', 'Phil', '3rd', 102),
(40, 9012, 'Groban', 'Josh', '1st', 402),
(41, 9013, 'Mellancamp', 'John', '2nd', 402),
(42, 9014, 'Steward', 'Rod', '1st', 402),
(43, 9015, 'Van Dross', 'Luthor', '2nd', 402),
(44, 9016, 'Stark', 'Ringo', '3rd', 402),
(45, 9500, 'Andrews', 'Gavin', '2nd', 101),
(46, 9501, 'Bartos', 'Robert', '3rd', 102),
(47, 9502, 'Camilleri', 'Carmen', '1st', 402),
(48, 9503, 'Innis', 'David', '1st', 101),
(49, 9504, 'Hunter', 'Ralph', '3rd', 102),
(50, 9505, 'O\\''Brien', 'Henry', '1st', 102),
(51, 9506, 'Regina', 'Magda', '3rd', 101),
(52, 9507, 'Sangan', 'Kurt', '3rd', 101),
(53, 9508, 'Sheary', 'Cliff', '2nd', 402),
(54, 9509, 'Sweeney', 'Tom', '1st', 402),
(55, 9510, 'Woodford', 'Penny', '3rd', 402),
(56, 9511, 'Hartigan', 'Charlie', '2nd', 101),
(57, 9512, 'Hammick', 'Maura', '1st', 101),
(58, 9513, 'Gibb', 'Karen', '3rd', 101),
(59, 9514, 'Gebrian', 'Robin', '1st', 402),
(60, 9515, 'French', 'Katie', '1st', 102),
(61, 9516, 'Campagna', 'Karen', '1st', 402),
(62, 9517, 'Barnet', 'Kris', '3rd', 101),
(63, 9518, 'Atkins', 'Phyllis', '1st', 102),
(64, 9519, 'Seifts', 'Ellen', '3rd', 402),
(65, 9520, 'Gebrian', 'Robin', '3rd', 402),
(66, 9521, 'Mitchell', 'Paul', '1st', 102),
(67, 9522, 'Penwood', 'Tom', '3rd', 402),
(68, 9523, 'Prescott', 'Sara', '2nd', 101),
(69, 9524, 'Sperandio', 'Mark', '1st', 102);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `levelID` int(11) NOT NULL AUTO_INCREMENT,
  `bayID` int(11) NOT NULL,
  `slotsPerBay` int(11) NOT NULL,
  `the_level` int(11) NOT NULL,
  PRIMARY KEY (`levelID`),
  KEY `bay_bayID_FK` (`bayID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=206 ;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`levelID`, `bayID`, `slotsPerBay`, `the_level`) VALUES
(129, 67, 2, 1),
(130, 68, 2, 1),
(131, 69, 2, 1),
(132, 70, 2, 1),
(133, 71, 2, 1),
(134, 72, 2, 1),
(135, 73, 2, 1),
(136, 67, 5, 2),
(137, 68, 5, 2),
(138, 69, 5, 2),
(139, 70, 5, 2),
(140, 71, 5, 2),
(141, 72, 5, 2),
(142, 73, 5, 2),
(143, 74, 2, 1),
(144, 75, 2, 1),
(145, 76, 2, 1),
(146, 77, 2, 1),
(147, 78, 2, 1),
(148, 79, 2, 1),
(149, 80, 2, 1),
(150, 74, 4, 2),
(151, 75, 4, 2),
(152, 76, 4, 2),
(153, 77, 4, 2),
(154, 78, 4, 2),
(155, 79, 4, 2),
(156, 80, 4, 2),
(157, 74, 4, 3),
(158, 75, 4, 3),
(159, 76, 4, 3),
(160, 77, 4, 3),
(161, 78, 4, 3),
(162, 79, 4, 3),
(163, 80, 4, 3),
(164, 81, 2, 1),
(165, 82, 2, 1),
(166, 83, 2, 1),
(167, 84, 2, 1),
(168, 85, 2, 1),
(169, 86, 2, 1),
(170, 87, 2, 1),
(171, 81, 5, 2),
(172, 82, 5, 2),
(173, 83, 5, 2),
(174, 84, 5, 2),
(175, 85, 5, 2),
(176, 86, 5, 2),
(177, 87, 5, 2),
(178, 88, 2, 1),
(179, 89, 2, 1),
(180, 90, 2, 1),
(181, 91, 2, 1),
(182, 92, 2, 1),
(183, 93, 2, 1),
(184, 94, 2, 1),
(185, 88, 4, 2),
(186, 89, 4, 2),
(187, 90, 4, 2),
(188, 91, 4, 2),
(189, 92, 4, 2),
(190, 93, 4, 2),
(191, 94, 4, 2),
(192, 95, 2, 1),
(193, 96, 2, 1),
(194, 97, 2, 1),
(195, 98, 2, 1),
(196, 99, 2, 1),
(197, 100, 2, 1),
(198, 101, 2, 1),
(199, 95, 4, 2),
(200, 96, 4, 2),
(201, 97, 4, 2),
(202, 98, 4, 2),
(203, 99, 4, 2),
(204, 100, 4, 2),
(205, 101, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sides`
--

CREATE TABLE IF NOT EXISTS `sides` (
  `sidesID` int(11) NOT NULL AUTO_INCREMENT,
  `AisleID` int(11) NOT NULL,
  `SideCode` int(11) NOT NULL,
  PRIMARY KEY (`sidesID`),
  KEY `aisle_AisleID_FK` (`AisleID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `sides`
--

INSERT INTO `sides` (`sidesID`, `AisleID`, `SideCode`) VALUES
(10, 7, 0),
(11, 8, 0),
(12, 8, 1),
(13, 9, 1),
(14, 9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE IF NOT EXISTS `slots` (
  `slotID` int(11) NOT NULL AUTO_INCREMENT,
  `levelID` int(11) NOT NULL,
  `slot` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `slot_of_slot` int(11) NOT NULL,
  PRIMARY KEY (`slotID`),
  KEY `level_levelID_FK` (`levelID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=697 ;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`slotID`, `levelID`, `slot`, `slot_of_slot`) VALUES
(445, 129, '51-0411', 11),
(446, 129, '51-0412', 12),
(447, 130, '51-0611', 11),
(448, 130, '51-0612', 12),
(449, 131, '51-0811', 11),
(450, 131, '51-0812', 12),
(451, 132, '51-1011', 11),
(452, 132, '51-1012', 12),
(453, 133, '51-1211', 11),
(454, 133, '51-1212', 12),
(455, 134, '51-1411', 11),
(456, 134, '51-1412', 12),
(457, 135, '51-1611', 11),
(458, 135, '51-1612', 12),
(459, 136, '51-0421', 21),
(460, 136, '51-0422', 22),
(461, 136, '51-0423', 23),
(462, 136, '51-0424', 24),
(463, 136, '51-0425', 25),
(464, 137, '51-0621', 21),
(465, 137, '51-0622', 22),
(466, 137, '51-0623', 23),
(467, 137, '51-0624', 24),
(468, 137, '51-0625', 25),
(469, 138, '51-0821', 21),
(470, 138, '51-0822', 22),
(471, 138, '51-0823', 23),
(472, 138, '51-0824', 24),
(473, 138, '51-0825', 25),
(474, 139, '51-1021', 21),
(475, 139, '51-1022', 22),
(476, 139, '51-1023', 23),
(477, 139, '51-1024', 24),
(478, 139, '51-1025', 25),
(479, 140, '51-1221', 21),
(480, 140, '51-1222', 22),
(481, 140, '51-1223', 23),
(482, 140, '51-1224', 24),
(483, 140, '51-1225', 25),
(484, 141, '51-1421', 21),
(485, 141, '51-1422', 22),
(486, 141, '51-1423', 23),
(487, 141, '51-1424', 24),
(488, 141, '51-1425', 25),
(489, 142, '51-1621', 21),
(490, 142, '51-1622', 22),
(491, 142, '51-1623', 23),
(492, 142, '51-1624', 24),
(493, 142, '51-1625', 25),
(494, 143, '52-0411', 11),
(495, 143, '52-0412', 12),
(496, 144, '52-0611', 11),
(497, 144, '52-0612', 12),
(498, 145, '52-0811', 11),
(499, 145, '52-0812', 12),
(500, 146, '52-1011', 11),
(501, 146, '52-1012', 12),
(502, 147, '52-1211', 11),
(503, 147, '52-1212', 12),
(504, 148, '52-1411', 11),
(505, 148, '52-1412', 12),
(506, 149, '52-1611', 11),
(507, 149, '52-1612', 12),
(508, 150, '52-0421', 21),
(509, 150, '52-0422', 22),
(510, 150, '52-0423', 23),
(511, 150, '52-0424', 24),
(512, 151, '52-0621', 21),
(513, 151, '52-0622', 22),
(514, 151, '52-0623', 23),
(515, 151, '52-0624', 24),
(516, 152, '52-0821', 21),
(517, 152, '52-0822', 22),
(518, 152, '52-0823', 23),
(519, 152, '52-0824', 24),
(520, 153, '52-1021', 21),
(521, 153, '52-1022', 22),
(522, 153, '52-1023', 23),
(523, 153, '52-1024', 24),
(524, 154, '52-1221', 21),
(525, 154, '52-1222', 22),
(526, 154, '52-1223', 23),
(527, 154, '52-1224', 24),
(528, 155, '52-1421', 21),
(529, 155, '52-1422', 22),
(530, 155, '52-1423', 23),
(531, 155, '52-1424', 24),
(532, 156, '52-1621', 21),
(533, 156, '52-1622', 22),
(534, 156, '52-1623', 23),
(535, 156, '52-1624', 24),
(536, 157, '52-0431', 31),
(537, 157, '52-0432', 32),
(538, 157, '52-0433', 33),
(539, 157, '52-0434', 34),
(540, 158, '52-0631', 31),
(541, 158, '52-0632', 32),
(542, 158, '52-0633', 33),
(543, 158, '52-0634', 34),
(544, 159, '52-0831', 31),
(545, 159, '52-0832', 32),
(546, 159, '52-0833', 33),
(547, 159, '52-0834', 34),
(548, 160, '52-1031', 31),
(549, 160, '52-1032', 32),
(550, 160, '52-1033', 33),
(551, 160, '52-1034', 34),
(552, 161, '52-1231', 31),
(553, 161, '52-1232', 32),
(554, 161, '52-1233', 33),
(555, 161, '52-1234', 34),
(556, 162, '52-1431', 31),
(557, 162, '52-1432', 32),
(558, 162, '52-1433', 33),
(559, 162, '52-1434', 34),
(560, 163, '52-1631', 31),
(561, 163, '52-1632', 32),
(562, 163, '52-1633', 33),
(563, 163, '52-1634', 34),
(564, 164, '52-0311', 11),
(565, 164, '52-0312', 12),
(566, 165, '52-0511', 11),
(567, 165, '52-0512', 12),
(568, 166, '52-0711', 11),
(569, 166, '52-0712', 12),
(570, 167, '52-0911', 11),
(571, 167, '52-0912', 12),
(572, 168, '52-1111', 11),
(573, 168, '52-1112', 12),
(574, 169, '52-1311', 11),
(575, 169, '52-1312', 12),
(576, 170, '52-1511', 11),
(577, 170, '52-1512', 12),
(578, 171, '52-0321', 21),
(579, 171, '52-0322', 22),
(580, 171, '52-0323', 23),
(581, 171, '52-0324', 24),
(582, 171, '52-0325', 25),
(583, 172, '52-0521', 21),
(584, 172, '52-0522', 22),
(585, 172, '52-0523', 23),
(586, 172, '52-0524', 24),
(587, 172, '52-0525', 25),
(588, 173, '52-0721', 21),
(589, 173, '52-0722', 22),
(590, 173, '52-0723', 23),
(591, 173, '52-0724', 24),
(592, 173, '52-0725', 25),
(593, 174, '52-0921', 21),
(594, 174, '52-0922', 22),
(595, 174, '52-0923', 23),
(596, 174, '52-0924', 24),
(597, 174, '52-0925', 25),
(598, 175, '52-1121', 21),
(599, 175, '52-1122', 22),
(600, 175, '52-1123', 23),
(601, 175, '52-1124', 24),
(602, 175, '52-1125', 25),
(603, 176, '52-1321', 21),
(604, 176, '52-1322', 22),
(605, 176, '52-1323', 23),
(606, 176, '52-1324', 24),
(607, 176, '52-1325', 25),
(608, 177, '52-1521', 21),
(609, 177, '52-1522', 22),
(610, 177, '52-1523', 23),
(611, 177, '52-1524', 24),
(612, 177, '52-1525', 25),
(613, 178, '53-0311', 11),
(614, 178, '53-0312', 12),
(615, 179, '53-0511', 11),
(616, 179, '53-0512', 12),
(617, 180, '53-0711', 11),
(618, 180, '53-0712', 12),
(619, 181, '53-0911', 11),
(620, 181, '53-0912', 12),
(621, 182, '53-1111', 11),
(622, 182, '53-1112', 12),
(623, 183, '53-1311', 11),
(624, 183, '53-1312', 12),
(625, 184, '53-1511', 11),
(626, 184, '53-1512', 12),
(627, 185, '53-0321', 21),
(628, 185, '53-0322', 22),
(629, 185, '53-0323', 23),
(630, 185, '53-0324', 24),
(631, 186, '53-0521', 21),
(632, 186, '53-0522', 22),
(633, 186, '53-0523', 23),
(634, 186, '53-0524', 24),
(635, 187, '53-0721', 21),
(636, 187, '53-0722', 22),
(637, 187, '53-0723', 23),
(638, 187, '53-0724', 24),
(639, 188, '53-0921', 21),
(640, 188, '53-0922', 22),
(641, 188, '53-0923', 23),
(642, 188, '53-0924', 24),
(643, 189, '53-1121', 21),
(644, 189, '53-1122', 22),
(645, 189, '53-1123', 23),
(646, 189, '53-1124', 24),
(647, 190, '53-1321', 21),
(648, 190, '53-1322', 22),
(649, 190, '53-1323', 23),
(650, 190, '53-1324', 24),
(651, 191, '53-1521', 21),
(652, 191, '53-1522', 22),
(653, 191, '53-1523', 23),
(654, 191, '53-1524', 24),
(655, 192, '53-0411', 11),
(656, 192, '53-0412', 12),
(657, 193, '53-0611', 11),
(658, 193, '53-0612', 12),
(659, 194, '53-0811', 11),
(660, 194, '53-0812', 12),
(661, 195, '53-1011', 11),
(662, 195, '53-1012', 12),
(663, 196, '53-1211', 11),
(664, 196, '53-1212', 12),
(665, 197, '53-1411', 11),
(666, 197, '53-1412', 12),
(667, 198, '53-1611', 11),
(668, 198, '53-1612', 12),
(669, 199, '53-0421', 21),
(670, 199, '53-0422', 22),
(671, 199, '53-0423', 23),
(672, 199, '53-0424', 24),
(673, 200, '53-0621', 21),
(674, 200, '53-0622', 22),
(675, 200, '53-0623', 23),
(676, 200, '53-0624', 24),
(677, 201, '53-0821', 21),
(678, 201, '53-0822', 22),
(679, 201, '53-0823', 23),
(680, 201, '53-0824', 24),
(681, 202, '53-1021', 21),
(682, 202, '53-1022', 22),
(683, 202, '53-1023', 23),
(684, 202, '53-1024', 24),
(685, 203, '53-1221', 21),
(686, 203, '53-1222', 22),
(687, 203, '53-1223', 23),
(688, 203, '53-1224', 24),
(689, 204, '53-1421', 21),
(690, 204, '53-1422', 22),
(691, 204, '53-1423', 23),
(692, 204, '53-1424', 24),
(693, 205, '53-1621', 21),
(694, 205, '53-1622', 22),
(695, 205, '53-1623', 23),
(696, 205, '53-1624', 24);

-- --------------------------------------------------------

--
-- Table structure for table `slotsleveled`
--

CREATE TABLE IF NOT EXISTS `slotsleveled` (
  `SlotsLeveledIndex` int(11) NOT NULL AUTO_INCREMENT,
  `Aisle` int(11) NOT NULL,
  `Bay` int(11) NOT NULL,
  `Position` int(11) NOT NULL,
  `YesLeveled` int(11) NOT NULL,
  `NoLeveled` int(11) NOT NULL,
  PRIMARY KEY (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tasksheet`
--

CREATE TABLE IF NOT EXISTS `tasksheet` (
  `TaskSheetIndex` int(11) NOT NULL AUTO_INCREMENT,
  `employeeIndex` int(11) NOT NULL,
  `SlotsLeveledIndex` int(11) NOT NULL,
  PRIMARY KEY (`TaskSheetIndex`),
  KEY `EmployeeIndexEmployeeTable_fk` (`employeeIndex`),
  KEY `SlotsLeveledIndex_SlotLeveled_fk` (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
  `WarehouseID` int(11) NOT NULL AUTO_INCREMENT,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`WarehouseID`),
  UNIQUE KEY `WarehouseNo` (`WarehouseNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`WarehouseID`, `WarehouseNo`) VALUES
(1, 101),
(2, 102),
(3, 402);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aisle`
--
ALTER TABLE `aisle`
  ADD CONSTRAINT `warehouse_WarehouseID_FK` FOREIGN KEY (`WarehouseID`) REFERENCES `warehouse` (`WarehouseID`);

--
-- Constraints for table `bay`
--
ALTER TABLE `bay`
  ADD CONSTRAINT `sides_sidesID_FK` FOREIGN KEY (`sidesID`) REFERENCES `sides` (`sidesID`);

--
-- Constraints for table `level`
--
ALTER TABLE `level`
  ADD CONSTRAINT `bay_bayID_FK` FOREIGN KEY (`bayID`) REFERENCES `bay` (`bayID`);

--
-- Constraints for table `sides`
--
ALTER TABLE `sides`
  ADD CONSTRAINT `aisle_AisleID_FK` FOREIGN KEY (`AisleID`) REFERENCES `aisle` (`AisleID`);

--
-- Constraints for table `slots`
--
ALTER TABLE `slots`
  ADD CONSTRAINT `level_levelID_FK` FOREIGN KEY (`levelID`) REFERENCES `level` (`levelID`);

--
-- Constraints for table `tasksheet`
--
ALTER TABLE `tasksheet`
  ADD CONSTRAINT `EmployeeIndexEmployeeTable_fk` FOREIGN KEY (`employeeIndex`) REFERENCES `employees` (`employeeIndex`),
  ADD CONSTRAINT `SlotsLeveledIndex_SlotLeveled_fk` FOREIGN KEY (`SlotsLeveledIndex`) REFERENCES `slotsleveled` (`SlotsLeveledIndex`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
