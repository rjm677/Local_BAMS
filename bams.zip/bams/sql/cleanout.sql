delete from aisle
delete from bay
delete from level
delete from sides
delete from slots
