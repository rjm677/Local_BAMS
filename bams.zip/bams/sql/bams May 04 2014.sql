-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 04, 2014 at 11:54 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bams`
--
CREATE DATABASE IF NOT EXISTS `bams` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bams`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE IF NOT EXISTS `adminusers` (
  `AdminUsersIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `AdminUserName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phoneNumber` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'No () - just digits',
  `passWord` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `MothersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  `FathersName` char(35) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`AdminUsersIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=87 ;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`AdminUsersIndex`, `manNumber`, `AdminUserName`, `phoneNumber`, `passWord`, `MothersName`, `FathersName`) VALUES
(64, '8084', 'Bob Morelli', '203 213-0725', 'WH8084', 'Lucy', 'Jim'),
(65, '8085', 'Dad', '203 677-2566', 'WH8085', 'Mili', 'Luigi'),
(66, '8086', 'Lucy', '203 677-2566', 'WH8086', 'Nonni', 'Francuuci'),
(67, '8087', 'Dennis Hopper', '123', 'WH8087', 'mom', 'dad'),
(68, '8088', 'Marcia Hopkins', '123', 'WH8088', 'Mom', 'Dad'),
(70, '9051', 'Mike Roche', '666777', 'WH9051', 'Mary', 'Sam'),
(71, '7070', 'Kari Underwood', '203 124 4567', 'WH7070', 'Mom', 'Dad'),
(72, '2001', 'Ralph Lauren', '203 677-2566', 'WH2001', 'Mama', 'Popa'),
(73, '1234', 'Mary Smith', '860 123 4567', 'WH1234', 'Mother', 'Father'),
(74, '5678', 'Don Henley', '340 678 9124', 'WH5678', 'Esmerelda', 'Dennis'),
(75, '55990', 'Sam Snead', '222', 'WH55990', 'Mom', 'Dad'),
(78, '12377', 'Young Blood', '123', 'WH12377', 'Mommy', 'Daddy'),
(79, '2010', 'Warren Beatty', '123', 'WH2010', 'Mom', 'Dad'),
(80, '20116', 'Earl the Pearl', '245', 'WH20116', 'm', 'd'),
(81, '8089', 'Larry Niven', '2032130725', 'WH8089', 'Greta', 'Warren'),
(84, '888888', 'xxx', 'xxx', 'xxx', 'xxx', 'xxx'),
(85, '4343', 'Kevin Sharp', '1234', 'WH4343', 'Mommy', 'Daddy'),
(86, '10199', 'Sanjay Gupta', '123', 'WH10199', 'Mommy', 'Daddy');

-- --------------------------------------------------------

--
-- Table structure for table `aisles`
--

CREATE TABLE IF NOT EXISTS `aisles` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `section` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `Aisle` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `Level` int(11) NOT NULL,
  `Height` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bay` int(8) NOT NULL,
  `position` int(8) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Use to Store Slot info' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employeeIndex` int(11) NOT NULL AUTO_INCREMENT,
  `manNumber` int(11) NOT NULL,
  `LastName` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `FirstName` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Shift` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `WarehouseNo` int(11) NOT NULL,
  PRIMARY KEY (`employeeIndex`),
  UNIQUE KEY `manNumber` (`manNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employeeIndex`, `manNumber`, `LastName`, `FirstName`, `Shift`, `WarehouseNo`) VALUES
(1, 9000, 'Police', 'Sting', '1st', 101),
(2, 9001, 'Maddona', 'Mia', '3rd', 101);

-- --------------------------------------------------------

--
-- Table structure for table `slotsleveled`
--

CREATE TABLE IF NOT EXISTS `slotsleveled` (
  `SlotsLeveledIndex` int(11) NOT NULL AUTO_INCREMENT,
  `Aisle` int(11) NOT NULL,
  `Bay` int(11) NOT NULL,
  `Position` int(11) NOT NULL,
  `YesLeveled` int(11) NOT NULL,
  `NoLeveled` int(11) NOT NULL,
  PRIMARY KEY (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tasksheet`
--

CREATE TABLE IF NOT EXISTS `tasksheet` (
  `TaskSheetIndex` int(11) NOT NULL AUTO_INCREMENT,
  `employeeIndex` int(11) NOT NULL,
  `SlotsLeveledIndex` int(11) NOT NULL,
  PRIMARY KEY (`TaskSheetIndex`),
  KEY `EmployeeIndexEmployeeTable_fk` (`employeeIndex`),
  KEY `SlotsLeveledIndex_SlotLeveled_fk` (`SlotsLeveledIndex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tasksheet`
--
ALTER TABLE `tasksheet`
  ADD CONSTRAINT `EmployeeIndexEmployeeTable_fk` FOREIGN KEY (`employeeIndex`) REFERENCES `employees` (`employeeIndex`),
  ADD CONSTRAINT `SlotsLeveledIndex_SlotLeveled_fk` FOREIGN KEY (`SlotsLeveledIndex`) REFERENCES `slotsleveled` (`SlotsLeveledIndex`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
