<?php
/* EIPpartialFormhandler.inc.php
*/
$okayPHP = 1;

require_once('includes/connect_vars.inc.php');
$dbc_EIP = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_EIP)  {
	$content_sw =9;
	$title = "Employee Add Form\n";
	$attention_bar = "Error: mysqli_connect failed in EIPpartialFormHandler.inc.php\n";
	$BackgroundRed = 1;
}  else  {
	$EIPwarehouseNo_sw 	= mysqli_real_escape_string($dbc_EIP, trim($_POST['EIPwarehouseNo_sw']));
	$EIPshift_sw   		= mysqli_real_escape_string($dbc_EIP, trim($_POST['EIPshift_sw']));  
	$EIPempLastName     = mysqli_real_escape_string($dbc_EIP, trim($_POST['EIPempLastName']));
	$EIPempfirstName 	= mysqli_real_escape_string($dbc_EIP, trim($_POST['EIPempfirstName']));
	$EIPmanNumber 		= mysqli_real_escape_string($dbc_EIP, trim($_POST['EIPmanNumber']));
	switch ($EIPwarehouseNo_sw)  {
		case  '1' :
			   $EIPwarehouseNo = 101;
				break;
		case  '2' : 
			   $EIPwarehouseNo = 102;
			   break;
		case  '3' :
			   $EIPwarehouseNo = 402;
			   break;
		default :
				$EIPwarehouseNo = 0;
				$content_sw =9;
				$title = "Employee Add Menu\n";
				$attention_bar = "Error: Warehouse Number undefined\n";
				$BackgroundRed = 1;
				$okayPHP = 0;
		}
	switch ($EIPshift_sw)  {
		case  '1' :
			   $EIPshift = '1st';
				break;
		case  '2' :
			   $EIPshift = '2nd';
			   break;
		case  '3' :
			   $EIPshift = '3rd';
			   break;
		default :
				$EIPshift = 'x';
				$content_sw =9;
				$title = "Employee Add Form\n";
				$attention_bar = "Error: shift is undefined\n";
				$BackgroundRed = 1;
				$okayPHP = 0;
		}
	/*	
		echo "<br>";
			*/
if($okayPHP)  {	
	$query_EmpOnFile   = "SELECT *\n";
	$query_EmpOnFile  .= "FROM employees WHERE\n";
	$query_EmpOnFile  .= "manNumber = '{$EIPmanNumber}'\n";
	
	$dataEIP01 = mysqli_query($dbc_EIP, $query_EmpOnFile); 
	if(!$dataEIP01)  {
		$content_sw =9;
		$title = "Employee Add Form\n";
		$attention_bar = "mysqli_query failed when checking for duplicate man number on file\n";
		$BackgroundRed = 1;
	} else {
		if(mysqli_affected_rows($dbc_EIP) > 0)  {
			$content_sw =9;
			$title = "Employee Add Form\n";
			$attention_bar = "Unable to Add this man number as it is already on file\n";
			$BackgroundRed = 1;
		}  else  {
			$query_insert  = "INSERT INTO employees \n";
			$query_insert .= "(employeeIndex, manNumber, LastName, FirstName, Shift, WarehouseNo) \n";
			$query_insert .= "VALUES \n";
			$query_insert .= "('Null', '{$EIPmanNumber}', '{$EIPempLastName}','{$EIPempfirstName}', 
			                 '{$EIPshift}', '{$EIPwarehouseNo}')\n";
		    //echo $query_insert;
			$dataEIP02 = mysqli_query($dbc_EIP, $query_insert); 
			if(!$dataEIP02)  {
				$content_sw =9;
				$title = "Employee Add Form\n";
				$attention_bar = "Error: mysqli_query for SQL insert failed in EIPpartialFormHandler.php\n";
				$BackgroundRed = 1;
			} else  {
				if(mysqli_affected_rows($dbc_EIP) != 1)  {
					$content_sw =9;
					$title = "Employee Add Form\n";
					$attention_bar = "Error: SQL failed to add employee to database in EIPpartialFormHandler.php\n";
					$BackgroundRed = 1;
				} else {
					$content_sw =9;
					$title = "Employee Add Form\n";
					$attention_bar = $EIPempfirstName ." ". $EIPempLastName . " has been added to the database\n";
					$BackgroundRed = 0; //display with blue background.
					$EIPempLastName="";
					$EIPempfirstName="";
					$EIPmanNumber="";
				} // End of else for a good record inserted.
			} //end of else for good mysqli_query of insert sql.
		}//end of else for not a duplicate man number
	} //end of else for good mysqli_query.
} //End of $okayPHP.
} //End else for good mysqli_connect.	

$EIPthreadID = mysqli_thread_id($dbc_EIP);
mysqli_kill($dbc_EIP, $EIPthreadID);
mysqli_close($dbc_EIP);