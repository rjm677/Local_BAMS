<!-- AisleChangesMenu.php -->

<div class=MenuWrapper>
				<div id=AisleChangesGenerate class=buttonEM><a href="index.php?content_sw=13&title=Generate Aisle Changes &attention_bar=Please complete this form">Generate New Slots</a></div>
				
				<div id=AisleChangesDelete class=buttonEM><a href="index.php?content_sw=14&title=Delete Slots in the  Database&attention_bar=Please Fill Out Form" >Delete slots</a></div>
				
				
				<div id=AisleChangesReport class=buttonEM><a href="report.php?content_sw=2"  >Run Slots Report</a></div>
				
				<div id=AisleChangesMenuReturn class=buttonEM>
					<a href="index.php?content_sw=2&title=Main Menu&attention_bar=Please make a Selection">Return to Main Menu</a>
				</div>
</div>	