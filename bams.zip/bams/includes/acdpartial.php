<?php
/* ACDpartial.php  
	Aisle Changes Delete.  */

if(!isset($ACDwarehouseNo_sw))  {
	$ACDwarehouseNo_sw_option = array();
	for($i=0;$i<4;$i++)  {
		$ACDwarehouseNo_sw_option[$i] = " ";  
	} //End of for loop.
} //End of not set $ACDwarehouseNo_sw, could be sent here from menu ---
// as opposed to dropping in from form handler after submit button is hit.

if(!isset($ACDaisle)) {
	$ACDaisle = " ";
}

if(!isset($ACDstartingBay)) {
	$ACDstartingBay = " ";
}

if(!isset($ACDEndingBay)) {
	$ACDEndingBay = " ";
}

if(!isset($ACDlevel_option))  {
	$ACDlevel_option = array();
	for($i=0;$i<4;$i++)  {
		$ACDlevel_option[$i] = " ";
	}	
} //End of not set warehouse_sw_option, coming here from menu, submit hasn't been clicked yet.
?>
<script>
/* alert('script is live');*/
	$("#ACDsubmit").click(function()  {
		var okayJS = true;
		var x;
		var z;
		$("select").each(function()  {
			x = $(this).val();
			//alert(x);
			
			if(x == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				$(this).css({"background-color":"#FFFFFF"});
			} 
		});
		// Test to see if Inputs, other than Input Type=submit is blank.
		$("input").each(function()  {
			x = $(this).val();
			//alert(x);
			y = x.length;
			//alert(y);
			
			if(y == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				z = $(this).attr("type");
				if(z != "submit")  {
					$(this).css({"background-color":"#FFFFFF"});
				}
			}
		});  //End of .each loop thru the input DOM objects.
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Required Field(s) Blank</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
		} else  {
		
		var test1;
		var test2;
		test1 = $("#ACDstartingBay").val();
		test2 = $("#ACDEndingBay").val();

		test1 = parseInt(test1);
		test2 = parseInt(test2);
		
		
		if(isNaN(test1))  {
			okayJS = false;
				$("#ACDstartingBay").css({"background-color":"#FF4242"});
		} else {
				$("#ACDstartingBay").css({"background-color":"#FFFFFF"});
		}
			
		if(isNaN(test2))  {
			okayJS = false;
			$("#ACDEndingBay").css({"background-color":"#FF4242"});
		} else {
			$("#ACDEndingBay").css({"background-color":"#FFFFFF"});
		}
			
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Field(s) is not a number</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});	
		} else {
			if(test2 < test1) {
				okayJS = false;
				$("#Attention_bar").html("<h2>Error: Ending bay is smaller than starting bay</h2>");
				$("#Attention_bar").css({"background-color":"#990000"});	
			} else {
				var isOdd = {};
					isOdd.ACDstartingBay = test1%2;
					isOdd.ACDEndingBay   = test2%2;
					if(!isOdd.ACDstartingBay == isOdd.ACDEndingBay) {
						okayJS = false;
						$("#ACDstartingBay").css({"background-color":"#FF4242"});
						$("#ACDEndingBay").css({"background-color":"#FF4242"});
						$("#Attention_bar").html("<h2>Error: Both must be odd or Both must be even</h2>");
						$("#Attention_bar").css({"background-color":"#990000"});	
					} else {
						$("#ACDstartingBay").css({"background-color":"#FFFFFF"});
						$("#ACDEndingBay").css({"background-color":"#FFFFFF"});
					}
			}//end of if for ending bay is smaller than starting bay.
			


		} //end of else for bays numbers are really numbers.
		} //end of else for bays are not blank.
		
		//Put logic here for Aisle is less than 10, ie
		// aisle 1 becomes 01  this is only for numeric aisles.
		
		if(okayJS)  {
			var str_ACDaisle = $("#ACDaisle").val();
			var INT_ACDaisle = parseInt(str_ACDaisle);
			if(isNaN(INT_ACDaisle))  {
				str_ACDaisle = str_ACDaisle.toUpperCase();
				$("#ACDaisle").val(str_ACDaisle);
			} else {
				if(INT_ACDaisle < 10) {
					str_ACDaisle = "0"+str_ACDaisle;
					$("#ACDaisle").val(str_ACDaisle);  //If it is numeric and >= 10 just leave it alone.
				}
			}
		
		
		} //end of okayJS for cleaning up aisle, ie is it string or Int, lower case string, or INT < 10?
		return okayJS;	
		}); //end of ACDsubmit click handler.

}); //end of document.ready.

</script>

<div id=ACDwrapper>
	<form id=ACDform name=ACDform action=index.php method=post>
<!--ACDcolumn01 ===================================================================== -->
		<div id=ACDcolumn01 > 
			<div class=ACDlabelBackground>
				<span>Warehouse No.</span>
			</div>
			<div class=ACDlabelBackground>
				<span>Starting Bay</span>
			</div>    
			<div class=ACDlabelBackground id=ACDlevelLabel>
				<span>Level</span>
			</div>	
			
		</div> <!-- End of Column01 -->

<!--ACDcolumn02 ===================================================================== -->
<div id=ACDcolumn02 > 
			<div class=ACDselectBox>
			<select id=ACDwarehouseNo_sw name=ACDwarehouseNo_sw class=ACDselectTag>
				<option value=0 <?php echo $ACDwarehouseNo_sw_option[0]; ?>> </option>
				<option value=1 <?php echo $ACDwarehouseNo_sw_option[1]; ?>>101</option>
				<option value=2 <?php echo $ACDwarehouseNo_sw_option[2]; ?>>102</option>
				<option value=3 <?php  echo $ACDwarehouseNo_sw_option[3]; ?>>402</option>
			</select> 
			</div>
			
			<input type=text id=ACDstartingBay name=ACDstartingBay class=myTextBox value="<?php echo $ACDstartingBay?>"> 
			<div class=ACDselectBox id=ACDlevelDiv>
				<select id=ACDlevel name=ACDlevel class=ACDselectTag>
					<option value=0 <?php echo $ACDlevel_option[0]?>></option>
					<option value=1 <?php echo $ACDlevel_option[1]?>>1</option>
					<option value=2 <?php echo $ACDlevel_option[2]?>>2</option>
					<option value=3 <?php echo $ACDlevel_option[3]?>>3</option>
				</select>
			</div>	
		
		</div> <!-- End of Column02 -->
<!--ACDcolumn03 ===================================================================== -->
		<div id=ACDcolumn03 > 
			<div class=ACDlabelBackground>
				<span>Aisle</span>
			</div>
			
			
			
			
			<div class=ACDlabelBackground>
				<span>Ending Bay</span>
			</div> 
			<div id=ACDbuttonCancel> 
				<a href="index.php?content_sw=15&attention_bar=Make a Selection&title=Aisle Changes Menu">Return</a>
			</div> 
			
		</div> <!-- End of Column03. -->
<!--ACDcolumn04 ===================================================================== -->	
		<div id=ACDcolumn04 > 
			<input type=text id=ACDaisle name=ACDaisle class=myTextBox value="<?php echo $ACDaisle ?>">
			
			
			<input type=text id=ACDEndingBay name=ACDEndingBay class=myTextBox value="<?php echo $ACDEndingBay?>"> 
			<input type=submit id=ACDsubmit name=ACDsubmit value=Submit>	
		</div> <!-- End of Column04. -->	
		

		
	</form>  <!-- End of ACDform. -->
</div> <!-- End of ACDwrapper. -->








