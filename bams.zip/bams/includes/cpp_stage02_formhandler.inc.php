<?php
//CPP_Stage02_FormHandler.Inc.php
require_once('includes/connect_vars.inc.php');
$dbc_CPPstage02 = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
//echo "I am in formHandler for CPP stage 02\n";
if(!$dbc_CPPstage02)  {
	$CPPokayPHP = 0;     // Indicate to ChangePasswordPartialStage01.php that
						// it is nessessary to display the value previously entered for
						// CPPmanNumberStage01.
	$BackgroundRed = 1;  //Make background of Attention_bar red.
	$content_sw = 5;
	$title = "<h2> Change Password Screen </h2>";
	$attention_bar = "<h2> Error -- mysqli_connect has failed  in CPPstage02</h2>"; 
} else  {
	$CPPnewPassWord   = mysqli_real_escape_string($dbc_CPPstage02, trim($_POST['CPPnewPassWord']));
	$queryCPPstg02  = "UPDATE adminusers\n";
	$queryCPPstg02 .= "SET passWord = '{$CPPnewPassWord}'\n";
	$queryCPPstg02 .= "WHERE AdminUsersIndex = '{$AdminUsersIndex}'\n";
	
	$dataCPPstg02   = mysqli_query($dbc_CPPstage02, $queryCPPstg02);
		if(!$dataCPPstg02)  {
			$BackgroundRed = 1;  //Make background of Attention_bar red.
			$content_sw = 5;
			$title = "<h2> Change Password Screen </h2>";
			$attention_bar = "<h2> Error -- mysqli_query has failed in CPPstage02</h2>";			
		}  else  {
			if(mysqli_affected_rows($dbc_CPPstage02) == 1)  {
				//password update as sucessful.
					$content_sw       = 2;
					$attention_bar    = "<h2>You have successfully updated your password</h2>";
					$title            = "<h2>Main Menu</h2>";
				} else { //mysqli_affected_rows has not returned one, and only one record.
					
					$CPPokayPHP = 0;      // must set man number text box value argument to $CPPmanNumberStage01.
					$BackgroundRed = 1;  //Make background of Attention_bar red.
					$content_sw = 5;
					$title = "<h2> Change Password Screen </h2>";
					$attention_bar = "<h2> Error -- mysqli_fetch_array has failed in CPPstage01</h2>";
				} // End of mysqli_fetch_array failure.
			  
			}  // End of good mysqli_query.
		} // End of good mysqli_connect.
		mysqli_close($dbc_CPPstage02);











?>