<?php

//echo "I am in RegAdminFormHandler";
require_once('includes/connect_vars.inc.php');
$dbc_LRP = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_LRP)  {
	$content_sw = 3;
	$title         =  "Register for a Login";
	$attention_bar = "RegAdmnFormHandler failed at mysqli_connect " . mysqli_connect_error();
} else  { //good mysqli_connect.
	//echo "we have a good mysqli_connect";
	$manNumber   = mysqli_real_escape_string($dbc_LRP, trim($_POST['LRP_manNumber']));
	$adminName   = mysqli_real_escape_string($dbc_LRP, trim($_POST['LRP_AdminName']));  
	
	//echo "$adminName is: " . $adminName;
	
	$passWord    = mysqli_real_escape_string($dbc_LRP, trim($_POST['LRP_passWord']));
	$phoneNumber = mysqli_real_escape_string($dbc_LRP, trim($_POST['LRP_phoneNumber']));
	$mothersName = mysqli_real_escape_string($dbc_LRP, trim($_POST['LRP_mothersName']));
	$fathersName = mysqli_real_escape_string($dbc_LRP, trim($_POST['LRP_fathersName']));

	$query_testForOnFile  = "SELECT *\n";
	$query_testForOnFile .= "FROM adminusers WHERE\n";
	$query_testForOnFile .= "manNumber = '{$manNumber}'\n";

	$data_testForOnFile = mysqli_query($dbc_LRP, $query_testForOnFile);
	if($data_testForOnFile)  {
	//echo "hello from 24";
		if(mysqli_affected_rows($dbc_LRP) > 0) {
			//echo "hello from line 26";
			$content_sw    =  3;
			$title         = "Register for a Login";
			$attention_bar = "Error -- Man Number already on file";
			$BackgroundRed = 1;
		} else {		
			//echo "hello from line 31";
			$query_Insert_Data  = "INSERT INTO adminusers (AdminUsersIndex, manNumber, AdminUserName, "; 
            $query_Insert_Data .= "phoneNumber, passWord, MothersName, FathersName) VALUES" ;
			$query_Insert_Data .= "('Null', '{$manNumber}', '{$adminName}', '{$phoneNumber}', ";
			$query_Insert_Data .= "'{$passWord}', '{$mothersName}', '{$fathersName}');\n";
			
			$dataInsert  = mysqli_query($dbc_LRP, $query_Insert_Data);
			
				if (mysqli_affected_rows($dbc_LRP) != 1)  {
					$attention_bar = "<h2>ERROR -- $query_Insert_Data is unabile to insert data into the database.</h2>\n";
					$BackgroundRed = 1; //an error has occurred, we want the attention_bar to turn red.
				}   else {
				//Wrote to database sucessfully.
				$attention_bar = "<h2>You have sucessfully registered as an administrative user.</h2>\n";
				$BackgroundRed = 0; //an error has not occurred,we want the attention_bar to turn blue.
				$title = "<h2>Main Menu</h2>";
				
				$content_sw = 2;
				$showLogout = 1;
				$query_getIndex = "SELECT AdminUsersIndex, AdminUserName FROM adminusers where manNumber = '{$manNumber}'";
				$query_getIndex .= "AND passWord = '{$passWord}'";
				//echo "<br>";
				//echo $query_getIndex;
				$data_getIndex = mysqli_query($dbc_LRP, $query_getIndex);
				//if ($data_getIndex)  {
					//echo "<br>We have data";
				//} else {
					//echo "<br>we do not have data";
				//}
				$row_getIndex = mysqli_fetch_array($data_getIndex);
				
				$_SESSION['AdminUsersIndex'] = $row_getIndex['AdminUsersIndex'];
				$AdminUsersIndex             = $row_getIndex['AdminUsersIndex'];
				//echo "AdminUserName is: " . $row_getIndex['AdminUserName'];
				
				$_SESSION['AdminUsersName']  = $row_getIndex['AdminUserName'];
				//echo "AdminUsersName is: " . $_SESSION['AdminUsersName'];
				
				$AdminUsersName  = $row_getIndex['AdminUserName'];
				} //Successful database operation.
			
			} // End of Else for man number not on file.		
		} else { //End of passed test for record found, --  error, already on file.
			echo "Test to see if manNumber is already on file has failed";
		} //end of mannumber already on file else.
	} // End of good mysqli_connect. 
?>
