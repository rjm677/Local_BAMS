<?php
//CPP_Stage01_FormHandler.Inc.php
require_once('includes/connect_vars.inc.php');
$dbc_CPPstage01 = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
//echo "I am in formHandler for CPP stage 01\n";
if(!$dbc_CPPstage01)  {
	$CPPokayPHP = 0;     // Indicate to ChangePasswordPartialStage01.php that
						// it is nessessary to display the value previously entered for
						// CPPmanNumberStage01.
	$BackgroundRed = 1;  //Make background of Attention_bar red.
	$content_sw = 5;
	$title = "<h2> Change Password Screen </h2>";
	$attention_bar = "<h2> Error -- mysqli_connect has failed  in CPPstage01</h2>";
} else  {
	$CPPmanNumberStage01   = mysqli_real_escape_string($dbc_CPPstage01, trim($_POST['CPPmanNumberStage01']));
	$CPPoldPasswordStage01 = mysqli_real_escape_string($dbc_CPPstage01, trim($_POST['CPPoldPassWordStage01']));
	$queryCPPstg01  = "SELECT AdminUsersIndex,AdminUserName\n";
	$queryCPPstg01 .= "FROM adminusers\n";
	$queryCPPstg01 .= "WHERE manNumber = '{$CPPmanNumberStage01}' AND ";
	$queryCPPstg01 .= "passWord = '{$CPPoldPasswordStage01}'\n";
	$dataCPPstg01   = mysqli_query($dbc_CPPstage01, $queryCPPstg01);
		if(!$dataCPPstg01)  {
			$BackgroundRed = 1;  //Make background of Attention_bar red.
			$content_sw = 5;
			$title = "<h2> Change Password Screen </h2>";
			$attention_bar = "<h2> Error -- mysqli_query has failed in CPPstage01</h2>";			
		}  else  {
			if(mysqli_affected_rows($dbc_CPPstage01) == 1)  {
				//login credentials have worked.
				//echo "You are logged in";
				$rowCPPstg01 = mysqli_fetch_array($dataCPPstg01);
				if ($rowCPPstg01)  {
					$AdminUsersIndex  = $rowCPPstg01['AdminUsersIndex'];
					$AdminUsersName   = $rowCPPstg01['AdminUserName'];
					//echo "AdminUsersIndex is: " . $AdminUsersIndex;
					$_SESSION['AdminUsersIndex'] = $AdminUsersIndex;
					$_SESSION['AdminUsersName']  = $AdminUsersName;
					
					$showLogout = 1;
					$content_sw       = 7;
					$attention_bar    = "<h2>Now enter your New Password Twice</h2>";
					$title            = "<h2>Change Password Form Stage 02</h2>";
				} else {
					//login failed at mysqli_fetch_array.
					$CPPokayPHP = 0;      // must set man number text box value argument to $CPPmanNumberStage01.
					$BackgroundRed = 1;  //Make background of Attention_bar red.
					$content_sw = 5;
					$title = "<h2> Change Password Screen </h2>";
					$attention_bar = "<h2> Error -- mysqli_fetch_array has failed in CPPstage01</h2>";
				} // End of mysqli_fetch_array failure.
			} else {  //mysqli_affected_rows has not returned one, and only one record.
					  //login atttempt has failed.
					 $CPPokayPHP = 0;      // must set man number text box value argument to $CPPmanNumberStage01.
					$BackgroundRed = 1;  //Make background of Attention_bar red.
					$content_sw = 5;
					$title = "<h2> Change Password Screen </h2>";
					$attention_bar = "<h2> Error -- ManNumber/Password combination not on file</h2>"; 
			}
		}
		mysqli_close($dbc_CPPstage01);
}










?>