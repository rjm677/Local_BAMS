<!-- EmployeeSearch.php -->   
<form name=EMPsearchForm 	id=EMPsearchForm action="index.php" method="post">
	<div id=EMPsearchWrapper>
		<div id=EMPsearchformLabels >
			<div class=EMPsearchlabelBackground>
				<span class=EMPspanText>Employee Man Number: </span>
			</div>
			<div id=EMPsearchbuttonCancel>
				<a href="index.php?content_sw=6&title=Employee Menu&attention_bar=Please make a selection" class=EMPspanText>Cancel</a>
			</div>
		</div>  <!-- End of EMPsearchformLabels -->
		<div id=EMPsearchinputField>
			<input type=hidden name=linkAction value="<?php echo $linkAction;?>">
			<input type=text  name=EMPmanNumber        id=EMPmanNumber>
			<input type=submit name=EMPsearchbutton id=EMPsearchbutton  value="Search for Employee">
		</div>  <!-- End of EMPsearchinputField -->
	</div> <!-- End of EMPsearchWrapper -->
</form>
		
	