<?php

// For WAMP Server
// Define database connection constants for now.
define('DB_HOST', "localhost");
define('DB_USER', "Test101");
define('DB_PASSWORD', "Test123");
define('DB_DATABASE', "bams");

// For GoDaddy
//define('DB_HOST', "localhost");
//define('DB_USER', "rjmor677_bams");
//define('DB_PASSWORD', "D0g1bobo");
//define('DB_DATABASE', "rjmor677_bams");
?>
