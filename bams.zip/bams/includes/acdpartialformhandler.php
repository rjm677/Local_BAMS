<?php
/* ACDpartialFormhandler.php
Aisle Changes Delete
*/
$slotID_array = array();

require_once('includes/truefalse.php');
$okayPHP = TRUE;
$slot_deletion_ctr = 0;
require_once('includes/connect_vars.inc.php');
$dbc_ACD = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_ACD)  {
	$content_sw =15;
	$title = "Aisle Changes Menu\n";
	$attention_bar = "Error: mysqli_connect failed in ACDpartialFormHandler.php\n";
	$attention_bar .= mysqli_error($dbc_ACD);
	$BackgroundRed = TRUE;
	$okayPHP = FALSE;
}  else  { //0001
//  Get form POST variables.
	$ACDwarehouseNo_sw 	= mysqli_real_escape_string($dbc_ACD, trim($_POST['ACDwarehouseNo_sw']));
	$ACDaisle          	= mysqli_real_escape_string($dbc_ACD, trim($_POST['ACDaisle']));
	$ACDstartingBay 	= mysqli_real_escape_string($dbc_ACD, trim($_POST['ACDstartingBay']));
	$ACDlevel 	        = mysqli_real_escape_string($dbc_ACD, trim($_POST['ACDlevel']));  
	$ACDEndingBay 		= mysqli_real_escape_string($dbc_ACD, trim($_POST['ACDEndingBay']));
	
	$ACDstartingBay    = (INT) $ACDstartingBay;
	$ACDEndingBay	   = (INT) $ACDEndingBay;
	$ACDlevel		   = (INT) $ACDlevel;
	$ACDwarehouseNo_sw = (INT) $ACDwarehouseNo_sw;
	
	$Query01  = "SELECT AisleID \n";
	$Query01 .= "FROM aisle \n";
	$Query01 .= "WHERE WarehouseID = '{$ACDwarehouseNo_sw}' \n";
	$Query01 .= "AND Aisle = '{$ACDaisle}' \n";
	
	$data_aisle_get = mysqli_query($dbc_ACD, $Query01);
	if(!$data_aisle_get) { 
		$content_sw = 14;
		$title = "<h2>Aisle Changes Delete</h2>";
		$attention_bar = "<h2>mysqli_query has failed for get aisle record get in ACDpartialFormhandler</h2>\n";
		$attention_bar .= mysqli_error($dbc_ACD);
		$BackgroundRed = TRUE;
		$okayPHP = FALSE;
	}  else  {//0002
		if(mysqli_affected_rows($dbc_ACD) < 1)  {
			$content_sw = 14;
			$title = "<h2>Aisle Changes Delete</h2>";
			$attention_bar = "<h2>Aisle is not on file</h2>\n";
			$BackgroundRed = TRUE;
			$okayPHP = FALSE;
		} else { //0003
			//echo "I am at 0003 <br>";
			$row_ACD = mysqli_fetch_array($data_aisle_get);
			$AisleID = $row_ACD['AisleID'];
			$content_sw = 14;
			$title = "<h2>Aisle Changes Delete</h2>";
			$attention_bar = "<h2>Aisle is on file</h2>\n";	

			$SideCode = ($ACDstartingBay % 2);
			
			$Query03  = "SELECT sidesID\n";
			$Query03 .= "from sides\n";
			$Query03 .= "WHERE AisleID = \n";
			$Query03 .= "'{$AisleID}' AND SideCode = '{$SideCode}'";
			
			$data_side_search = mysqli_query($dbc_ACD, $Query03);
			
			if(!$data_side_search)  {
				$content_sw = 14;
				$title = "<h2>Aisle Changes Delete</h2>";
				$attention_bar = "<h2>Search for side record failed in Query03:" . mysqli_error($dbc_ACD) . "</h2>";
				$okayPHP = FALSE;
				$BackgroundRed = TRUE;
			} else { //0004 search for sideID has nor failed.
				if(mysqli_affected_rows($dbc_ACD) != 1)  {
					$content_sw = 14;
					$title = "<h2>Aisle Changes Delete</h2>";
					$attention_bar = "<h2>Slots on this side of the aisle do not appear to be in database</h2>";
					$okayPHP = FALSE;
					$BackgroundRed = TRUE;
				} else {   //0005 begining of else for found the correct record in the sides table.
					//echo" I am at 0005 <br>";
					$row_getSideCode = mysqli_fetch_array($data_side_search);
					$sidesID = $row_getSideCode['sidesID'];

					$stop = $ACDEndingBay + 1;
					$start = $ACDstartingBay;
					//var_dump($start);
					//var_dump($stop);
			
					for($Bay = $start; $Bay < $stop; $Bay = $Bay + 2) { //0006 Begining of Bay loop.
					//echo $Bay;
					//echo "<br>";
					
					$slotID_array = array();
					
					$Query05  = "SELECT bayID \n";
					$Query05 .= "FROM bay \n";
					$Query05 .= "WHERE sidesID = '{$sidesID}' \n";
					$Query05 .= "AND bay = '{$Bay}'\n";
					$data_bay_get = mysqli_query($dbc_ACD, $Query05);
					if(!$data_bay_get) {
						$content_sw = 14;
						$title = "<h2>Aisle Changes Delete</h2>";
						$attention_bar  = "<h2>mysqli_query has failed for get bay record get in ACGpartialFormhandler\n";
						$attention_bar .= mysqli_error($dbc_ACD) . "</h2>\n";
						$BackgroundRed = TRUE;
						$okayPHP = FALSE;
						break; //Out of for loop on bay.
					}  else  { //0007 search for bayID has not failed.
						//echo "I am at 0007 <br>";
						//echo "affected rows is";
						//echo mysqli_affected_rows($dbc_ACD);
						if(mysqli_affected_rows($dbc_ACD) > 0)  {  //do nothing if bay row doesn't exist.
							$row_ACD = mysqli_fetch_array($data_bay_get);
							$bayID = $row_ACD['bayID'];
							//echo "bayID is: $bayID <br>";
						//} else { //0008 obtained a good bayID.
							//echo "I am at 0008 <br>";
							$Query07 = "SELECT levelID \n";
							$Query07 .= "FROM level \n";
							$Query07 .= "WHERE bayID = '{$bayID}' AND \n";
							$Query07 .= "the_level = '{$ACDlevel}' \n";
				
							$data_level_get = mysqli_query($dbc_ACD, $Query07);
					
							if(!$data_level_get) { //0009 query succeeded for levelID search.
								//echo mysqli_error($dbc_ACD);
								//echo "not getting a good levelID";
							} else {//echo " I am at 0009 <br>";
							//Do nothing if no level row in level table.
								//if(mysqli_affected_rows($dbc_ACD) > 0) {
									$row_ACD = mysqli_fetch_array($data_level_get);
									$levelID = $row_ACD['levelID'];
									//echo "the levelID is $levelID <br>";
								//}//0010 found levelID row in database.

									$Query09  = "SELECT slotID \n";
									$Query09 .= "FROM slots \n";
									$Query09 .= "WHERE levelID = '{$levelID}' \n";
									$data_slot_get = mysqli_query($dbc_ACD, $Query09);
					
									if($data_slot_get) { // 0011
										if(mysqli_affected_rows($dbc_ACD) > 0) { //0012
											
											while ($X = mysqli_fetch_array($data_slot_get)) { 
												//var_dump($X);
												
												$Query10  = "DELETE from slots \n";
												$Query10 .= "WHERE SlotID = '{$X[0]}'";
												$data_slot_delete = mysqli_query($dbc_ACD, $Query10);
												$slot_deletion_ctr++;
											}
										$Query11  = "DELETE from level \n";
										$Query11 .=	"WHERE levelID = '{$levelID}'";
										$data_level_delete = mysqli_query($dbc_ACD, $Query11);
										$slot_deletion_ctr += mysqli_affected_rows($dbc_ACD);
					
									
									}//0012
									}//0011
									                 //0010 found levelID row in database.
								}//0009 query succeeded for levelID search.
						}//0008 obtained a good bayID.
					}//0007 search for bayID has not failed.
			} //0006 End of bay for loop.

			// Return to slot input form, display total slots created on attention bar.
			if($okayPHP)  {
				$content_sw = 14;
				$title = "<h2>Aisle Changes Delete</h2>";
				$attention_bar = "<h2>Total slots deleted: $slot_deletion_ctr ";
			} //End of $okayPHP is TRUE.
			
		} //0005 end of else for found the correct record in the sides table.
		} //0004 search for sideID has nor failed.
		} //0003 found the aisle record in aisle table.
	} //0002 End of else for good mysqli_query for aisle_get.

		$ACDwarehouseNo_sw_option = array();   
		for($i=0;$i<4;$i++)  {
		$ACDwarehouseNo_sw_option[$i] = " ";
		}	
		$ACDwarehouseNo_sw_option[$ACDwarehouseNo_sw] = 'selected ="selected"';

		$ACDlevel_option = array();
		for($j=0;$j<4;$j++)  {
		$ACDlevel_option[$j] = " ";
		}	
		$ACDlevel_option[$ACDlevel] = 'selected ="selected"';

} // 0001 end of else for we have a good mysqli_connect(). 
?>