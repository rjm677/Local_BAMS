<?php
/* Employee Search Form Handler  */
require_once('includes/connect_vars.inc.php');
$dbc_EMP =mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_EMP)  {
	$BackgroundRed = 1; //display error message w/ red background.	
	$content_sw = 6; // emoloyee menu.
	$title = "<h2>Employee Menu</h2>";
	$attention_bar = "<h2>Error: failed to establish database connection in ESpartialFormhandler.php</h2>";
} else { //good mysqli_connect.
	$linkAction = mysqli_real_escape_string($dbc_EMP, trim($_POST['linkAction']));
	$EMPmanNumber = mysqli_real_escape_string($dbc_EMP, trim($_POST['EMPmanNumber']));

	$EMP_query01  = "SELECT * \n";
	$EMP_query01 .= "from employees \n";
	$EMP_query01 .= "WHERE manNumber = '{$EMPmanNumber}'\n";
	
	$data_query01 = mysqli_query($dbc_EMP, $EMP_query01);
	if(!$data_query01)  {  //query failed to execute.
		$BackgroundRed = 1; //display error message w/ red background.	
		$content_sw = 6; // employee menu.
		$title = "<h2>Employee Menu</h2>";
		$attention_bar = "<h2>Error: query01 in ESpartialFormhandler.php failed to execute</h2>";
	} else {
		if(mysqli_affected_rows($dbc_EMP) != 1)  {
			$BackgroundRed = 1; //display error message w/ red background.	
			$content_sw = 10; // employee search partial.
			$title = "<h2>Employee Search screen</h2>";
			$attention_bar = "<h2>Error: Man Number not on file</h2>";
		} else  {
			$row_EMP = mysqli_fetch_array($data_query01);
				$EMPemployeeIndex = $row_EMP['employeeIndex'];
				//echo 'Employee Index is' . "$EMPemployeeIndex";
				$EMPmanNumber     = $row_EMP['manNumber'];
				$EMPLastName      = $row_EMP['LastName'];
				$EMPFirstName     = $row_EMP['FirstName'];
				//var_dump($EMPFirstName);
				//echo "this is from ESpartialFormhandler";
				$EMPShift         = $row_EMP['Shift'];
				$EMPWarehouseNo   = $row_EMP['WarehouseNo'];
				
					$SelectedShift = array(" "," "," ");
					$SelectedWarehouseNo = array(" "," "," ");
					switch($EMPShift)  {
						case '1st':  $SelectedShift[0] = 'selected="selected"';
						              break;
						case '2nd':  $SelectedShift[1] = 'selected="selected"';
						     		  break;
						case '3rd':  $SelectedShift[2] = 'selected="selected"';
									  break;
						default : echo "$EMPshift has a bad value";
					}
					
					$SelectedWarehouseNo = array(" "," "," ");
					
					switch($EMPWarehouseNo)  {
						case '101':  $SelectedWarehouseNo[0] = 'selected="selected"';
						              break;
						case '102':  $SelectedWarehouseNo[1] = 'selected="selected"';
						     		  break;
						case '402':  $SelectedWarehouseNo[2] = 'selected="selected"';
									  break;
						default : echo "$EMPWarehouseNo has a bad value";
					}
				if($linkAction==trim("employeeMenuChange"))  {
					$content_sw = 11;
					$attention_bar = "<h2>Please Update the Following Information</h2>";
					$title = "<h2>Employee Change Form</h2>";
				} elseif($linkAction==trim("employeeMenuDelete"))  {
					$content_sw = 12;
					$attention_bar = "<h2>Please Review the Following Information</h2>";
					$title = "<h2>Employee Delete Form</h2>";
				} else  {
					echo"LinkAction isn't defined properly";
				} // End of Elseif for linkAction values.
		} //End of else for $EMPmanNumber is on file.
	} //End of good query01 execution.
} //End of else for good database connection.
?>