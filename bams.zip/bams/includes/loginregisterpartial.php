
<script>

$(document).ready(function()  {
	//alert("script is live");
	$("#LRP_Submit").click(function()  {
		var Return_code = true;
		var LRP_masterKey = $("#LRP_masterKey").val();	
		//alert(LRP_masterKey);
		if(LRP_masterKey != "Adam6701")  {
			$("#Attention_bar").html("<h2>Registration failed -- Incorrect Master key entered</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
			$("#LRP_masterKey").css({"background-color":"#FF4242"});
			Return_code = false;
		}  else  {
			$("#LRP_masterKey").css({"background-color":"#FFFFFF"});
			var LRP_passWord = $("#LRP_passWord").val();
			var LRP_passWordConfirm = $("#LRP_passWordConfirm").val();
			if(LRP_passWord != LRP_passWordConfirm) {
				$("#Attention_bar").html("<h2>Registration failed -- Password and Password Again not the same</h2>");
				$("#Attention_bar").css({"background-color":"#990000"});
				$("#LRP_passWord").css({"background-color":"#FF4242"});
				$("#LRP_passWordConfirm").css({"background-color":"#FF4242"});
				Return_code = false;
			}  else  {
				$("#LRP_passWord").css({"background-color":"#FFFFFF"});
				$("#LRP_passWordConfirm").css({"background-color":"#FFFFFF"});
				$("input").each(function()  {
					x = $(this).val();
					y = x.length;
					if(!y)  {
						Return_code = false;
						$(this).css({"background-color":"#FF4242"});
					}
				});
				if (!Return_code)  {
					$("#Attention_bar").html("<h2>Registration failed -- Required Field(s) Blank</h2>");
					$("#Attention_bar").css({"background-color":"#990000"});
				}
			}
		}
		return Return_code;
	});
});

</script>


			<form id =LoginRegister name=LoginRegister id=LoginRegister action="index.php" method="post">
					<div id=LRP_LabelsLeft >
						
						<div class=LRP_labelBackground >
							<label class=LRP_labelTextL>Man Number: </label>
						</div>
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextL>Name: </label>
						</div>
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextL>Password: </label>
						</div>
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextL>Passwd Again: </label>
						</div> 
					</div>   
					
					<div id=LRP_InputsLeft>  
						<input type=text  id=LRP_manNumber        name=LRP_manNumber       	class=LRP_inputL ><br>
						<input type=text  id=LRP_AdminName        name=LRP_AdminName  		class=LRP_inputL ><br>
						<input type=password  id=LRP_passWord         name=LRP_passWord  		class=LRP_inputL ><br>
						<input type=password  id=LRP_passWordConfirm  name=LRP_passWordConfirm  class=LRP_inputL ><br> 
					</div>
					
					<div id=LRP_LabelsRight >  
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextR>PhoneNumber:<span class=red>   *</span> </label>
						</div>
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextR>Mother's Name:<span class=red>*</span> </label>
						</div>
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextR>Father's Name:<span class=red> *</span> </label>
						</div>
						<div class=LRP_labelBackground>
							<label class=LRP_labelTextR>Master Key:</label>
						</div>
							
					</div>    
					
					<div id=LRP_InputsRight> 
						<input type=text  id=LRP_phoneNumber   name=LRP_phoneNumber     class=LRP_inputR ><br>
						<input type=text  id=LRP_mothersName   name=LRP_mothersName     class=LRP_inputR ><br>
						<input type=text  id=LRP_fathersName   name=LRP_fathersName     class=LRP_inputR ><br>
						<input type=text  id=LRP_masterKey     name=LRP_masterKey     	class=LRP_inputR ><br> 
					</div>
					<div id=LRPbuttonWrapper>
						<div id=message>
							<span class=red> * </span> The purpose of these fields is to help you
							if you forget your password. You don't have to enter real info,
							just something you will remember.
						</div>
						<div id=LRPRegisterCancel>
							<a href=index.php>Cancel</a>
						</div>
						
							<input type=submit id=LRP_Submit name=LRP_Submit value=Submit> 
						  
					</div>	  
			</form> 

		
	