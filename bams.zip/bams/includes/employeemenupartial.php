		
			<div class=MenuWrapper>
				<div id=EmployeeMenuAdd class=buttonEM><a href="index.php?linkAction=employeeMenuAdd&content_sw=9&title=Add Employee To Database&attention_bar=Please complete this form">Add New Employee</a></div>
				<div id=EmployeeMenuChange class=buttonEM><a href="index.php?linkAction=employeeMenuChange&content_sw=10&title=Change Employee in Database&attention_bar=Please Enter Employee Man Number" >Change Employee Data</a></div>
				<div id=EmployeeMenuDelete class=buttonEM><a href="index.php?linkAction=employeeMenuDelete&content_sw=10&title=Delete Employee in Database&attention_bar=Please Enter Employee Man Number"  >Delete an Employee</a></div>
				<div id=RunEmployeeReport class=buttonEM><a href="report.php?content_sw=1"  >Run Employee Report</a></div>
				<div id=EmployeeMenuReturn class=buttonEM>
					<a href="index.php?linkAction=employeeMenuReturn&content_sw=2&title=Main Menu&attention_bar=Please make a Selection">Return to Main Menu</span>
				</div>
			</div>	
		
		
		
		