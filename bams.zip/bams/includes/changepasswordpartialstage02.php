<!-- ChangePasswordPartial -->  
<script>

$(document).ready(function()  {
document.getElementById("CPPnewPassWord").focus();
	$("#CPPbuttonNext").click(function()  {
		okayJS = true;
		emptyField = false;
		var CPPnewPassWord = $("#CPPnewPassWord").val();
		//alert(CPPnewPassWord);
		var CPPnewPassWordAgain = $("#CPPnewPassWordAgain").val();
		//alert(CPPnewPassWordAgain);
		var len1 = CPPnewPassWord.length;
		if(!len1) {
			emptyField = true;
			$("#CPPnewPassWord").css({"background-color":"#FF4242"});
		
		}
		var len2 = CPPnewPassWordAgain.length;
		if(!len2)  {
			emptyField = true;
			$("#CPPnewPassWordAgain").css({"background-color":"#FF4242"});
		}
		if(emptyField)  {
			$("#Attention_bar").html("<h2>Error: Required Fields are Blank:</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
			okayJS = false;
		}
		if(CPPnewPassWord != CPPnewPassWordAgain)  {
			$("#Attention_bar").html("<h2>Error: Password and Password Again are not the Same</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
			okayJS = false;
		}
		return okayJS;
	});	
});




</script> 

 
<?php
$htmlOut = ' value="' .$CPPmanNumberStage01.'"';

$htmlOut2 = ' value="' .$CPPoldPasswordStage01.'"';

?>

<form name = CPPformStg02 id=CPPformStg02  action="index.php" method="post">
<div id=CPPformDivStage02>
	<div id=CPPformLabelsStage02 >
		<div class=CPPlabelBackground>
			<span class=CPPspanText>Man Number: </span>
		</div>
		<div class=CPPlabelBackground>
			<span class=CPPspanText>Old Password: </span>
		</div>
		<div class=CPPlabelBackground>
			<span class=CPPspanText>New Password:</span>
		</div> 
		<div class="CPPlabelBackground">
			<span class=CPPspanText>New Password Again: </span>
		</div>
		<div id=CPPbuttonCancel>
			<a href=index.php class=CPPspanText>Cancel</a>
		</div>
	</div>
	<div id=CPPinputFieldsStage02>
		<input type=text         name=CPPmanNumberStg02        id=CPPmanNumberStg02        class=greyOut <?php echo $htmlOut ?>>
		<input type=password     name=CPPoldPassWordStg02      id=CPPoldPassWordStg02      class=greyOut <?php echo $htmlOut2 ?> >
		<input type=password     name=CPPnewPassWord           id=CPPnewPassWord           class=CPPinputs>
		<input type=password     name=CPPnewPassWordAgain      id=CPPnewPassWordAgain      class=CPPinputs>
		<div>
			<input type=submit id=CPPbuttonNext name=CPPbuttonNext class=CPPspanText value=Next>
		</div>
	</div>
</div>
</form>
		
	