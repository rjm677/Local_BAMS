<?php
//FPP_Stage01_FormHandler.Inc.php
require_once('includes/connect_vars.inc.php');
$dbc_FPPstage01 = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
//echo "Hello from line 5";
if(!$dbc_FPPstage01)  {
	$FPPokayPHP = 0;     
	$BackgroundRed = 1;  //Make background of Attention_bar red.
	$content_sw = 4; //FPPpartialStage01.php
	$title = "<h2> Forgot Password Screen </h2>";
	$attention_bar = "<h2> Error -- mysqli_connect has failed  in FPPpartialStage01.php</h2>";
} else  {
	//Sanitize the input.
	$FPPmanNumberStage01 = mysqli_real_escape_string($dbc_FPPstage01, trim($_POST['FPPmanNumber']));
	$FPPinfo = mysqli_real_escape_string($dbc_FPPstage01, trim($_POST['info']));
	$FPPanswer = mysqli_real_escape_string($dbc_FPPstage01, trim($_POST['FPPanswer']));
	
	$whereArray = array("1" => "MothersName = '{$FPPanswer}'\n", "2" => "FathersName = '{$FPPanswer}'\n", 
"3" => "phoneNumber = '{$FPPanswer}'\n");
	//var_dump($whereArray);
	
	
	$queryFPPstg01  = "SELECT AdminUsersIndex\n";
	$queryFPPstg01 .= "FROM adminusers\n";
	$queryFPPstg01 .= "WHERE manNumber = '{$FPPmanNumberStage01}' AND ";
	$queryFPPstg01 .= $whereArray[$FPPinfo];
	//var_dump($queryFPPstg01);
	
	$dataFPPstg01   = mysqli_query($dbc_FPPstage01, $queryFPPstg01);
		if(!$dataFPPstg01)  {
			$BackgroundRed = 1;  //Make background of Attention_bar red.
			$content_sw = 4;
			$title = "<h2> Forgot Password Screen </h2>";
			$attention_bar = "<h2>Error: FPP_Stage01FormHandler.Inc.php failed at mysqli_query (first one)</h2>\n";
			
			
			
		}  else  {  //Query executed properly.
			if(mysqli_affected_rows($dbc_FPPstage01) != 1)  {
				// Security Question Answer is Not Correct for this Man Number.
				$BackgroundRed = 1;  //Make background of Attention_bar red.
				$content_sw = 4;
				$title = "<h2> Forgot Password Screen </h2>";
				$attention_bar = "<h2> Error -- Man Number / Security Question Not on File</h2>";			
			} else  {	
				// Security Question Answer is Correct for this Man Number.
				
				$rowFPPstg01 = mysqli_fetch_array($dataFPPstg01);
				if ($rowFPPstg01)  {
					$AdminUsersIndex  = $rowFPPstg01['AdminUsersIndex'];
					
					$query02FPPstg01  = "UPDATE adminusers\n";
					$query02FPPstg01  .="set passWord = 'FriendlyWindows'\n";
					$query02FPPstg01  .="WHERE AdminUsersIndex = '{$AdminUsersIndex}'\n";
					//var_dump($query02FPPstg01);
					
					$data02FPPstg01   = mysqli_query($dbc_FPPstage01, $query02FPPstg01);
					if(mysqli_affected_rows($dbc_FPPstage01) == 1)  {
					  //success, one row was updated.
					  //pull up FPPpartialStage02.php.
					  $content_sw = 8;
					  $attention_bar = "Security question answered correctly";
					  $title = "Forgot Password Screen Stage02";
					  
					  
					//echo "mysqli_affected_rows =" . mysqli_affected_rows($dbc_FPPstage01);
					}  else  {
					   // handle failure of second query.
						$BackgroundRed = 1;  //Make background of Attention_bar red.
						$content_sw = 4;
						$title = "<h2> Forgot Password Screen </h2>";
						$attention_bar = "<h2> Error -- FPP update operation did not change password on one row</h2>";			
					   
					} //end of failure of update password.
				} else {  //mysqli_fetch_array has failed.	
					$BackgroundRed = 1;  //Make background of Attention_bar red.
					$content_sw = 4;
					$title = "<h2> Forgot Password Screen </h2>";
					$attention_bar = "<h2> Error -- FPP mysqli_fetch_array for password update has failed</h2>";			
					
				} // end of else for mysqli_fetch array (failure) from first database operation.	
					
			} // end of else for good match -- security question answer and man number match what is in the database.
		} // end of else for mysqli_query of first query is successful.



} //End of else which is a good mysqli_connect.
?>