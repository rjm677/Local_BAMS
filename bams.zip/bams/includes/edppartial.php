<!-- EDPpartial.php  -->

<div id=EDPwrapper>
	<form id=EDPform name=EDPform action=index.php method=post>
	<div id=EDPleft>
		<div class=EDPlabelBackground>
			<span>Warehouse No.</span>
		</div>
		<div class=EDPlabelBackground>
			<span>Shift</span>
		</div>
		<div class=EDPlabelBackground>
			<span>First Name</span>
		</div>
		<div class=EDPlabelBackground>
			<span>Last Name</span>
		</div>
		<div class=EDPlabelBackground>
			<span>Man Number</span>
		</div>
		<div id=EDPbuttonCancel>
			<a href="index.php?content_sw=6&attention_bar=Make a Selection&title=Employee Menu">Cancel</a>
		</div>
	</div> <!-- End of #EDPleft.  -->
	<div id=EDPright>
		<input type=hidden id=EDPemployeeIndex value="<?php echo $EMPemployeeIndex;?>" name=EDPemployeeIndex>
		<input type=text   id=EDPwarehouseNo   value="<?php echo $EMPWarehouseNo;?>" disabled="disabled">
		<input type=text   id=EDPshift         value="<?php echo $EMPShift;?>" disabled="disabled">
		<input type=text   id=EDPempfirstName  value="<?php echo $EMPFirstName;?>" disabled="disabled">
		<input type=text   id=EDPempLastName   value="<?php echo $EMPLastName;?>" disabled="disabled">
		<input type=text   id=EDPmanNumber     value="<?php echo $EMPmanNumber;?>" disabled="disabled">
		<input type=submit name=EDPsubmit id=EDPsubmit value=Delete>
	
	</div> <!-- End of EIPright -->
	</form>
	
</div> <!-- End of #EIPwrapper.   -->