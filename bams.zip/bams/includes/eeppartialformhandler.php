<?php
//EEPpartialFormhandler.php

$okayPHP = 1;
require_once('includes/connect_vars.inc.php');
$dbc_EEP = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);

if(!$dbc_EEP)  {
	$BackgroundRed = 1;  //Make background of Attention_bar red.
	$content_sw = 11;  //EEPpartial.php
	$title = "<h2> Change Employee Information Screen </h2>";
	$attention_bar = "<h2> Error -- mysqli_connect has failed  in EEPpartial.php</h2>"; 
} else  {
	$EEPwarehouseNo_sw = mysqli_real_escape_string($dbc_EEP, trim($_POST['EEPwarehouseNo_sw']));
	$EEPshift_sw       = mysqli_real_escape_string($dbc_EEP, trim($_POST['EEPshift_sw']));
	$EMPemployeeIndex  = mysqli_real_escape_string($dbc_EEP, trim($_POST['EMPemployeeIndex']));
	$EEPFirstName   = mysqli_real_escape_string($dbc_EEP, trim($_POST['EEPFirstName']));
	$EEPLastName    = mysqli_real_escape_string($dbc_EEP, trim($_POST['EEPLastName']));
	$EEPmanNumber      = mysqli_real_escape_string($dbc_EEP, trim($_POST['EEPmanNumber']));
	
switch ($EEPwarehouseNo_sw)  {
		case  '1' :
			   $EEPwarehouseNo = 101;
				break;
		case  '2' : 
			   $EEPwarehouseNo = 102;
			   break;
		case  '3' :
			   $EEPwarehouseNo = 402;
			   break;
		default :
				$EEPwarehouseNo = 0;
				$content_sw =11;
				$title = "Employee Change Form\n";
				$attention_bar = "Error: Warehouse Number undefined\n";
				$BackgroundRed = 1;
				$okayPHP = 0;
		}
	switch ($EEPshift_sw)  {
		case  '1' :
			   $EEPshift = '1st';
				break;
		case  '2' :
			   $EEPshift = '2nd';
			   break;
		case  '3' :
			   $EEPshift = '3rd';
			   break;
		default :
				$EEPshift = 'x';
				$content_sw =11;
				$title = "Employee Change Form\n";
				$attention_bar = "Error: shift is undefined\n";
				$BackgroundRed = 1;
				$okayPHP = 0;
		}

if($okayPHP)  {
	$query_EEP  = "UPDATE employees\n";
	$query_EEP .= "SET manNumber = '{$EEPmanNumber}', \n";
	$query_EEP .=  "FirstName = '{$EEPFirstName}', \n";
	$query_EEP .=  "LastName = '{$EEPLastName}', \n";
	$query_EEP .=  "Shift = '{$EEPshift}', \n";
	$query_EEP .=  "WarehouseNo = '{$EEPwarehouseNo}' \n";
	$query_EEP .= "WHERE employeeIndex = '{$EMPemployeeIndex}'\n";
	//echo $query_EEP;
	$data_EEP   = mysqli_query($dbc_EEP, $query_EEP);
		if(!$data_EEP)  {
			$BackgroundRed = 1;  //Make background of Attention_bar red.
			$content_sw = 6;
			$title = "<h2> Change Employee Information Form </h2>";
			$attention_bar = "<h2> Error -- mysqli_query has failed in EEPpartialFormhandler.php</h2>";	
			
		}  else  {
			if(mysqli_affected_rows($dbc_EEP) == 1)  {
				//password update as sucessful.
					$content_sw       = 6;
					$attention_bar    = "<h2>You have successfully updated " . $EEPFirstName . " " . $EEPLastName . "</h2>";
					$title            = "<h2>Employee Menu</h2>";
				} else { //mysqli_affected_rows has not returned one, and only one record.
					$BackgroundRed = 1;  //Make background of Attention_bar red.
					$content_sw = 6;
					$title = "<h2>Employee Menu</h2>";
					$attention_bar = "<h2> Error -- delete operation has failed to affect only one row</h2>";
				}
			  
			}  // End of good mysqli_query.
			}  // End of OkayPHP = 1.
		} // End of good mysqli_connect.
$EEPthreadID = mysqli_thread_id($dbc_EEP);
mysqli_kill($dbc_EEP, $EEPthreadID);
mysqli_close($dbc_EEP);
?>