		  <!-- Forgot Password Partial  -->
			<form id=FPPpartialForm name=FPPpartialForm  action="index.php" method=post>
				<div id=FPPFormDiv>
					<div id=FPPformLabels >
						<div class=FPPlabelBackground>
							<label>Man Number: </label>
						</div>
						<div class=FPPlabelBackground>
							<select name=info id=info>
								<option value=1>Mother's Name</option>
								<option value=2>Father's Name </option>
								<option value=3>Phone Number </option>
							</select>
						</div>
						        
						<div id=FPPbuttonCancel>
							<a href=index.php >Cancel</a>
						</div>
					</div>  <!-- End of FPPformLabels  -->

					<div id=FPPinputFields>
							<input type=text  id=FPPmanNumber name=FPPmanNumber maxlength=12>
							<input type=text  id=FPPanswer name=FPPanswer>
							<input type=submit id=FPPsearchForPassword name=FPPsearchForPassword value=Submit> 
					</div>  <!-- End of FPPinputFields -->
				</div> <!-- End of FPPFormDiv -->
			</form>
		
	