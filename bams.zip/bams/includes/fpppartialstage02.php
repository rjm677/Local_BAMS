		  <!-- Forgot Password Partial  -->
			
				<div id=FPPwrapper>
					<div id=FPPstg02Left>
						
						<div id=FPPstg02ManNumber>
							<span>Man Number</span>
						</div>
						<div id=FPPstg02PasswdLabel>
							<span>Temporary Password</span>
						</div>
						
						<div id=FPPbuttonCancel>
							<a href=logout.php >Cancel</a>
						</div>
						
						
					</div>
					<div id=FPPstg02Right> 
						<div id=FPPstg02MN class=greyOut>
							<?php echo $FPPmanNumberStage01; ?>
						</div> 
						<div id=FPPstg02Passwd class=RedLetters>
							<span>FriendlyWindows</span>
						</div>
						<div id=FPPstg02ChangePasswdButton>
							<a href="index.php?linkAction=ChangePasswordStage01&content_sw=5&title=Change Password Form&attention_bar=Please Change Your Password" id=changePassword>Change Password</a>							 
						</div> 
					</div>
				</div>
					
					
					
					
					
				</div>
			
		
	