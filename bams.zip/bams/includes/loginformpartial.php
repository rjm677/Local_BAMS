
<!--LoginFormPartial -->
<?php
$buttonRegAdminURL  = 'http://localhost/bams/index.php';
$buttonRegAdminURL .='?linkAction="RegAdmn"&';



 



?>
<script>
//alert('In the Script tags');

$(document).ready(function()  {
	
	$("#submit_form").click(function() {
		
		returnCode = true;
		var manNumber = $("#manNumber").val();
		var passWord  = $("#passWord").val();
		
		var okaymanNumber = manNumber.length;
		var okaypassWord = passWord.length;

		if(!okaymanNumber)  {
			$("#manNumber").css({"background-color":"#FF4242"});
			returnCode = false;
		}

		if(!okaypassWord)  {
			$("#passWord").css({"background-color":"#FF4242"});
			returnCode = false;
		}
		if (!okaymanNumber || !okaypassWord) {
			$("#Attention_bar").html("<h2>Required Field(s) Blank</h2>");
			$("#Attention_bar").css({"background-color" : "FFFFFF"});
		}	
		return returnCode;
	});
}); 

</script>
<form name=loginform id=loginform action="<?php echo "{$_SERVER['PHP_SELF']}"; ?>" method=post>
    <div id=loginForm>
					
        <div id=formLabels >
            <div class=labelBackground>
                <label>Man Number: </label>
            </div>
            <div class=labelBackground>
                <label>Password: </label>
            </div>
            <div id=buttonRegAdmin>
<a href="index.php?linkAction=RegAdmn&content_sw=3&title=Login Register Form&attention_bar=Please Register for an Account"> 
    Register </a> 
           </div>
		   <div id=link_LoginForgotPasswd>  
			<a href="index.php?linkAction=ForgotPasswd&content_sw=4&title=Login Forgot Password Form&attention_bar=Please Complete Form" id=forgotPassword>Forgot Password</a> 
			</div>
			
        </div>
         <div id=inputFields>
            <input type=text     name=manNumber id=manNumber  maxlength=12><br>
            <input type=password name=passWord  id=passWord maxlength=15><br>
							
             <input type=submit   name=submit_form    id=submit_form   value="Log On">
			 
             <div id=changePasswordButton>
				 <a href="index.php?linkAction=ChangePasswordStage01&content_sw=5&title=Change Password Form&attention_bar=Please Change Your Password" id=changePassword>Change Password</a> 
			 </div>
			 
        </div>
				
    </div>
</form>






	