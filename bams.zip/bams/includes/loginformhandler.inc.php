<?php
function loginFormHandler ($manNumber, $passWord)  {
$LFPreturnVars = array('attention_bar' => "", 'BackgroundRed' => 0,'content_sw' => 1, 'title' =>"");
require_once('includes/connect_vars.inc.php');
 $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if (!$dbc) {
	$LFPreturnVars['attention_bar'] = " Can't connect to host". mysqli_connect_error();
	$LFPreturnVars['BackgroundRed'] = 1;
} else  { //Sucessfully connected to Database 
	$manNumber   = mysqli_real_escape_string($dbc, trim($manNumber));
	$passWord    = mysqli_real_escape_string($dbc, trim($passWord));
	$query = "SELECT AdminUsersIndex, manNumber, AdminUserName, passWord\n";
	$query .="FROM adminusers WHERE\n";
	$query .="manNumber = '{$manNumber}' AND passWord = '{$passWord}'\n";
	$data = mysqli_query($dbc, $query);			   
	if (!$data) {
		$LFPreturnVars['attention_bar'] = " Database query failed.";
		$LFPreturnVars['BackgroundRed'] = 1;
	} else  {
		if (mysqli_affected_rows($dbc) == 1) {
			$row = mysqli_fetch_array($data);
			$AdminUsersIndex = $row['AdminUsersIndex'];
			$_SESSION['AdminUsersIndex'] = $AdminUsersIndex;
			$LFPreturnVars['attention_bar'] = "You are successfully logged in" ;
			$LFPreturnVars['BackgroundRed'] = 0;
                                                        //make background of Attention_bar blue.			   
			$LFPreturnVars['content_sw']    = 2;
			$LFPreturnVars['title']    = "<h2>Main Menu</h2>";
			$AdminUserName = $row['AdminUserName'];
			$_SESSION['AdminUsersName'] = $AdminUserName;
			$LFPreturnVars['AdminUsersName'] =$AdminUserName;
		} else {  //we do not have one and only one record.
			$LFPreturnVars['attention_bar'] =
                                                        "<h2> Man Number / Password combination is not on record</h2>";
			$LFPreturnVars['BackgroundRed'] = 1;
			$LFPreturnVars['content_sw']    = 1;
			$LFPreturnVars['title']    = "<h2>Login Form</h2>";
			$LFPreturnVars['AdminUsersName'] ="";
		} // end of not one and only one record returned.
	}  // end of good mysqli_query.
} // end of good mysqli_connect.
mysqli_close($dbc);
return $LFPreturnVars;
} //end of function.	
