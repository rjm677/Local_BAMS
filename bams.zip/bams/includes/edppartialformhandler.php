<?php
//EDPpartialFormhandler.php
require_once('includes/connect_vars.inc.php');
$dbc_EDP = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);

if(!$dbc_EDP)  {
	$BackgroundRed = 1;  //Make background of Attention_bar red.
	$content_sw = 6;
	$title = "<h2> Employee Menu</h2>";
	$attention_bar = "<h2> Error -- mysqli_connect has failed  in EDPpartialFormhandler.php</h2>"; 
} else  {
	//echo "Good mysqli_connect";
	$EDPemployeeIndex  = mysqli_real_escape_string($dbc_EDP, trim($_POST['EDPemployeeIndex']));
	//echo 'employee Index is:' . "$EDPemployeeIndex";
	
	$query_EDP  = "DELETE FROM employees \n";
	$query_EDP .= "WHERE employeeIndex = '{$EDPemployeeIndex}'\n";
	//echo "$query_EDP";
	$data_EDP   = mysqli_query($dbc_EDP, $query_EDP);
		if(!$data_EDP)  {
			$BackgroundRed = 1;  //Make background of Attention_bar red.
			$content_sw = 6;
			$title = "<h2> Employee Menu </h2>";
			$attention_bar = "<h2> Error -- Delete Database Operation failed in EDPpartialFormhandler.php</h2>";			
		}  else  {
			
			//$X = mysqli_affected_rows($dbc_EDP);
			
			//echo 'Number of rows affected:' . "$X";
			if(mysqli_affected_rows($dbc_EDP) == 1)  {
				
					$content_sw       = 6;
					$attention_bar    = "<h2>You have successfully deleted a row from employee database</h2>";
					$title            = "<h2>Employee Menu</h2>";
				} else { //mysqli_affected_rows has not returned one, and only one record.
					$BackgroundRed = 1;  //Make background of Attention_bar red.
					$content_sw = 6;
					$title = "<h2> Employee Menu</h2>";
					$attention_bar = "<h2> Error -- failed to affect one, and only one, row</h2>";
				} // End of mysqli_fetch_rows failure.
			  
			}  // End of good mysqli_query.
		} // End of good mysqli_connect.
		
$EDPthreadID = mysqli_thread_id($dbc_EDP);		
mysqli_kill($dbc_EDP, $EDPthreadID);		
mysqli_close($dbc_EDP);
		
		
		











?>