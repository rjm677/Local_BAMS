<!-- GTSpartial.php   Generate Task Sheets.
-->


<script>
$(document).ready(function()  {
	//alert('script is live');
	$("#Broken_Ring").hide();
	$("#Modal").hide();

	$("#GTSemployeeNumber").blur(function() {
		//alert('blur activated'); 
		var myGTSemployeeNumber;
		myGTSemployeeNumber = $("#GTSemployeeNumber").val();
		NameOBJ = {};
		NameOBJ.GTSemployeeNumber = myGTSemployeeNumber;
		//alert(NameOBJ.GTSemployeeNumber);
		$.post("getname.php", NameOBJ, ResponseFunc, 'json'); 
	});	
	
	
	function ResponseFunc(ResponseFuncOBJ)  {
		//alert('inside function'); 
	   	myGTSemployeeName = ResponseFuncOBJ.GTSemployeeName;
		myPHPstatus = ResponseFuncOBJ.PHPstatus;
		if(myPHPstatus == 1) {
			$("#GTSemployeeName").val(myGTSemployeeName);
			$("#GTSemployeeName").css({"background-color":"#424242"});
		}  else  {
			var myAttention_bar;
			switch (myPHPstatus)  {
				case  -1 :
					myAttention_bar = "Database connection Failed";
					break;
				case -2 :
					myAttention_bar = "Man Number not on file";
					break;
				case -3 :
					myAttention_bar = "Man Number not input";
					break;
				case -4 :
					myAttention_bar = "Query Failed";
					break;
				case -5 :
					myAttention_bar = "Fetch Failed";
					break;
				default: myAttention_bar = "Unknown Error";
			} 
			myAttention_bar = '<h2>' + myAttention_bar + '</h2>';
			$("#Attention_bar").html(myAttention_bar);
			$("#Attention_bar").css({"background-color":"#990000"});
	
		} 
	} 
	
	$("#GTSsubmit").click(function()  {
		//alert('script is live in submit section');
		var okayJS = true;
		var x;  
		var z;

		$("select").each(function()  {
			x = $(this).val();
			//alert(x);
			
			if(x == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				$(this).css({"background-color":"#FFFFFF"});
			} 
		});
		//alert('hello from line 26');
		// Test to see if Inputs, other than Input Type=submit is blank.
		$("input").each(function()  {
			x = $(this).val();
			//alert(x);
			y = x.length;
			//alert(y);
			
			if(y == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				z = $(this).attr("type");
				if(z != "submit")  {
					$(this).css({"background-color":"#FFFFFF"});
				}
			}
		});  //End of .each loop thru the input DOM objects.
		//alert('hello from line 44');
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Required Field(s) Blank</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
		} else  {
		
		var test1;
		var test2;
		test1 = $("#GTSstartingBay").val();
		test2 = $("#GTSEndingBay").val();

		test1 = parseInt(test1);
		test2 = parseInt(test2);
		
		//alert('hello from line 58');
		if(isNaN(test1))  {
				okayJS = false;
				$("#GTSstartingBay").css({"background-color":"#FF4242"});
		} else {
				$("#GTSstartingBay").css({"background-color":"#FFFFFF"});
		}
			
		if(isNaN(test2))  {
			okayJS = false;
			$("#GTSEndingBay").css({"background-color":"#FF4242"});
		} else {
			$("#GTSEndingBay").css({"background-color":"#FFFFFF"});
		}
			
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Field(s) is not a number</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});	
		} 
		//alert('hello from line 77');	


		
		} //end of else for bays are not blank.
		
		//Put logic here for Aisle is less than 10, ie
		// aisle 1 becomes 01  this is only for numeric aisles.
		//alert('hello from line 85');
		if(okayJS)  {
			var str_GTSstartingaisle = $("#GTSstartingaisle").val();
			var INT_GTSstartingaisle = parseInt(str_GTSstartingaisle);
			if(isNaN(INT_GTSstartingaisle))  {
				str_GTSstartingaisle = str_GTSstartingaisle.toUpperCase();
				$("#GTSstartingaisle").val(str_GTSstartingaisle);
			} else {
				if(INT_GTSstartingaisle < 10) {
					str_GTSstartingaisle = "0"+str_GTSstartingaisle;
					$("#GTSstartingaisle").val(str_GTSstartingaisle);  //If it is numeric and >= 10 just leave it alone.
				}
			}
		}   //end of okayJS for cleaning up starting aisle, ie is it string or Int, lower case string, or INT < 10?
		
		if(okayJS)  {
			 var str_GTSEndingAisle = $("#GTSEndingAisle").val();
			// alert(str_GTSEndingAisle);
			var INT_GTSEndingAisle = parseInt(str_GTSEndingAisle);
			 if(isNaN(INT_GTSEndingAisle))  {
				str_GTSEndingAisle = str_GTSEndingAisle.toUpperCase();
				$("#GTSEndingAisle").val(str_GTSEndingAisle);
			}  else {
				 if(INT_GTSEndingAisle < 10) {
					str_GTSEndingAisle = "0" + str_GTSEndingAisle;
					$("#GTSEndingAisle").val(str_GTSEndingAisle);  //If it is numeric and >= 10 just leave it alone. 
				}
			} 
		}

		//alert('hello from line 101');
		//Put logic here for making it an error if none of the three levels are clicked.
		
		var mylevel_1;
		mylevel_1 = $("#level_1").is(':checked');
		
		var mylevel_2;
		mylevel_2 = $("#level_2").is(':checked');
		
		var mylevel_3;
		mylevel_3 = $("#level_3").is(':checked');
		
		
		if(!mylevel_1 && !mylevel_2 && !mylevel_3) {
			okayJS = false;
			$("#Attention_bar").html("<h2>Error: At least one level must be checked</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});	
		}
		
			
			
		//}
		if(okayJS)  {
			$("#Broken_Ring").show();
			$("#Modal").show();
		}
		//alert('test checkboxs');
		//alert('okayJS is' + okayJS);
		return okayJS;	
		//return false; 
		}); //end of GTSsubmit click handler.

}); //end of document.ready.

</script>






<div id=GTSwrapper>
	<form id=GTSform name=GTSform action=report.php method=post>
		<input type=hidden name=content_sw id=content_sw value=3>
		<div id=GTScolumn01>
			<div class=GTSlabelBackground>
				<span>Employee No</span>
			</div>
			<div class=GTSlabelBackground>
				<span>Warehouse No.</span>
			</div>
			<div class=GTSlabelBackground>
				<span>Starting Aisle</span>
			</div>
			<div class=GTSlabelBackground>
				<span>Starting Bay</span>
			</div>
			
		</div> <!-- End of Column01 -->

		<div id=GTScolumn02> 
			<input type=text id=GTSemployeeNumber name=GTSemployeeNumber   class=myTextBox>
			<div class=GTSselectBox>
				<select id=GTSwarehouseNo_sw name=GTSwarehouseNo_sw class=GTSselectTag>
					<option value=0 > </option>
					<option value=1 >101</option>
					<option value=2 >102</option>
					<option value=3 >402</option>
				</select> 
			</div>
			<input type=text id=GTSstartingaisle name=GTSstartingaisle class=myTextBox>
			<input type=text id=GTSstartingBay name=GTSstartingBay class=myTextBox> 
		</div> <!-- End of Column02 -->

		<div id=GTScolumn03> 
			<div class=GTSlabelBackground>
				<span>Employee Name</span>
			</div>
			<div class=GTSlabelBackground>
				<span>Level</span>
			</div>
			<div class=GTSlabelBackground>
				<span>Ending Aisle</span>
			</div> 
			<div class=GTSlabelBackground>
				<span>Ending Bay</span>
			</div> 
			<div id=GTSbuttonCancel> 
				<a href="index.php?content_sw=2&attention_bar=Please Make a Selection&title=Main Menu">Return</a>
			</div> 
		</div> <!-- End of Column03. -->
		
		<div id=GTScolumn04> 
			<input type=text id=GTSemployeeName name=GTSemployeeName class=GTSmyTextBox>
			<div id=LevelCheckboxs>
				
				<div id=Level1>
					<label for=level_1>1</label> 
					<input type=checkbox id=level_1 name=level_1 class=chkBox value=1>
				</div>
				
				  
				<div id=Level2>
					<label for=level_2>2</label>
					<input type=checkbox id=level_2 name=level_2 class=chkBox value=1>
				</div>
				
				
				<div id=Level3>
					<label for=level_3>3</label>
					<input type=checkbox id=level_3 name=level_3 class=chkBox value=1> 
				</div>		
			</div> <!-- End of LevelCheckboxs -->
			
			<input type=text id=GTSEndingAisle name=GTSEndingAisle class=GTSmyTextBox>
			<input type=text id=GTSEndingBay name=GTSEndingBay class=GTSmyTextBox>
			<input type=submit id=GTSsubmit name=GTSsubmit value=Submit> 
		</div> <!-- End of Column04. -->
		
	</form>
</div> <!-- End of ACwrapper. -->

<div id=Modal>
	<img src=images/modal3.jpg >
</div>

<div id=Broken_Ring>
	<img src=images/spinning_wheel_broken_ring.gif >
</div>
