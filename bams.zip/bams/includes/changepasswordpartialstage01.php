<!-- ChangePasswordPartialStage01.php -->   

<script>
	
$(document).ready(function()  {
	$("#CPPbuttonContinue").click(function()  {
	
		var okayJS = true;
		var CPPmanNumberStage01 = $("#CPPmanNumberStage01").val();
		var CPPoldPassWordStage01 = $("#CPPoldPassWordStage01").val();
		
		if(CPPmanNumberStage01.length == 0)  {
			okayJS = false;
			$("#CPPmanNumberStage01").css({"background-color":"#FF4242"});
		}
		
		if(CPPoldPassWordStage01.length == 0)  {
			okayJS = false;
			$("#CPPoldPassWordStage01").css({"background-color":"#FF4242"});
		}		
		
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Required Field(s) are blank</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
		}
		
	return okayJS;		
	});
	
}); //End of document.ready.
//==================================		
</script>

			<form name = CPPformStage01 id =CPPformStage01 action="index.php" method="post">
				<div id=CPPformDivStage01>
					<div id=CPPformLabels >
						<div class=CPPlabelBackground>
							<span class=CPPspanText>Man Number: </span>
						</div>
						<div class=CPPlabelBackground>
							<span class=CPPspanText>Old Password: </span>
						</div>
						 		
						<div id=CPPbuttonCancel>
							<a href=index.php class=CPPspanText>Cancel</a>
						</div>
					</div>  <!-- End of CPPformLabels -->
					<div id=CPPinputFieldsStage01>
							<input type=text         name=CPPmanNumberStage01        id=CPPmanNumberStage01    class=CPPinputs>
							<input type=password     name=CPPoldPassWordStage01      id=CPPoldPassWordStage01  class=CPPinputs>
					
							<input type=submit name=CPPbuttonContinue id=CPPbuttonContinue  value=Continue>
					</div>  <!-- End of CPPinputfields -->
				</div> <!-- End of CPPformDivStage01 -->
			</form>
		
	