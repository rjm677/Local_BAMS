
<?php
/*EIPpartial.php
  Employee Insert Partial
*/

		if(!isset($EIPempLastName))  {
			$EIPempLastName="";
		}
		if(!isset($EIPempfirstName))  {
			$EIPempfirstName="";
		}
		if(!isset($EIPmanNumber))  {  
			$EIPmanNumber="";
		}
		
?>
<script>
$(document).ready(function()  {
	$("#EIPsubmit").click(function()  {
		var okayJS = true;
		var x;
		var y;
		var z;
		$("select").each(function()  {
			x = $(this).val();
			//alert(x);
			
			if(x == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				$(this).css({"background-color":"#FFFFFF"});
			} 
		});
		
		
		$("input").each(function()  {
			x = $(this).val();
			//alert(x);
			y = x.length;
			//alert(y);
			
			if(y == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				z = $(this).attr("type");
				if(z != "submit")  {
					$(this).css({"background-color":"#FFFFFF"});
				}
			}
		});
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Required Field(s) Blank</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
		}
		return okayJS;
	});
});
</script>

<div id=EIPwrapper>
	<form id=EIPform name=EIPform action=index.php method=post>
	<div id=EIPleft>
		<div class=EIPlabelBackground>
			<span>Warehouse No.</span>
		</div>
		<div class=EIPlabelBackground>
			<span>Shift</span>
		</div>
		<div class=EIPlabelBackground>
			<span>First Name</span>
		</div>
		<div class=EIPlabelBackground>
			<span>Last Name</span>
		</div>
		<div class=EIPlabelBackground>
			<span>Man Number</span>
		</div>
		<div id=EIPbuttonCancel>
			<a href="index.php?content_sw=6&attention_bar=Make a Selection&title=Employee Menu">Cancel</a>
		</div>
	</div> <!-- End of #EIPleft.  -->
	<div id=EIPright>
		<div class=EIPselectBox>
			<select id=EIPwarehouseNo_sw name=EIPwarehouseNo_sw class=EIPselectTag>
				<option value=0> </option>
				<option value=1>101</option>
				<option value=2>102</option>
				<option value=3>402</option>
			</select> 
		</div>
	
		<div class=EIPselectBox>  
			<select id=EIPshift_sw  name=EIPshift_sw class=EIPselectTag>
				<option value=0> </option>
				<option value=1>1st</option>
				<option value=2>2nd</option>
				<option value=3>3rd</option>
			</select> 
		</div>
		<input  type=text id=EIPempfirstName  name=EIPempfirstName value="<?php echo $EIPempfirstName;?>" >
		<input type=text id=EIPempLastName name=EIPempLastName value="<?php echo $EIPempLastName;?>">
		<input  type=text id=EIPmanNumber name=EIPmanNumber value="<?php echo $EIPmanNumber;?>">
		<input  type=submit name=EIPsubmit id=EIPsubmit value=Submit>
	
	</div> <!-- End of EIPright -->
	</form>
	
</div> <!-- End of #EIPwrapper.   -->