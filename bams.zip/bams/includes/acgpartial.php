<!-- ACGpartial.php   Aisle Changes Generate.
-->
<?php

if(!isset($ACGwarehouseNo_sw))  {
	$warehouse_sw_option = array();
	for($i=0;$i<4;$i++)  {
		$warehouse_sw_option[$i] = " ";
	}	
} //End of not set warehouse_sw_option, coming here from menu, submit hasn't been clicked yet.



if(!isset($ACGslotsPerBay_option))  {
	$ACGslotsPerBay_option = array();
	for($i=0;$i<13;$i++)  {
		$ACGslotsPerBay_option[$i] = " ";
	}	
} //End of not set warehouse_sw_option, coming here from menu, submit hasn't been clicked yet.



if(!isset($ACGlevel_option))  {
	$ACGlevel_option = array();
	for($i=0;$i<4;$i++)  {
		$ACGlevel_option[$i] = " ";
	}	
} //End of not set warehouse_sw_option, coming here from menu, submit hasn't been clicked yet.

if(!isset($ACGEndingBay)) {
	$ACGEndingBay = " ";
}

if(!isset($ACGstartingBay)) {
	$ACGstartingBay = " ";
}

if(!isset($ACGaisle)) {
	$ACGaisle = " ";
}

?>
<script>
$(document).ready(function()  {
	//alert('script is live');
	$("#Broken_Ring").hide();
	$("#Modal").hide();
	$("#ACGsubmit").click(function()  {
		
		var okayJS = true;
		var x;
		var z;
		$("select").each(function()  {
			x = $(this).val();
			//alert(x);
			
			if(x == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				$(this).css({"background-color":"#FFFFFF"});
			} 
		});
		
		// Test to see if Inputs, other than Input Type=submit is blank.
		$("input").each(function()  {
			x = $(this).val();
			//alert(x);
			y = x.length;
			//alert(y);
			
			if(y == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				z = $(this).attr("type");
				if(z != "submit")  {
					$(this).css({"background-color":"#FFFFFF"});
				}
			}
		});  //End of .each loop thru the input DOM objects.
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Required Field(s) Blank</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
		} else  {
		
		var test1;
		var test2;
		test1 = $("#ACGstartingBay").val();
		test2 = $("#ACGEndingBay").val();

		test1 = parseInt(test1);
		test2 = parseInt(test2);
		
		
		if(isNaN(test1))  {
			okayJS = false;
				$("#ACGstartingBay").css({"background-color":"#FF4242"});
		} else {
				$("#ACGstartingBay").css({"background-color":"#FFFFFF"});
		}
			
		if(isNaN(test2))  {
			okayJS = false;
			$("#ACGEndingBay").css({"background-color":"#FF4242"});
		} else {
			$("#ACGEndingBay").css({"background-color":"#FFFFFF"});
		}
			
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Field(s) is not a number</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});	
		} else {
			if(test2 < test1) {
				okayJS = false;
				$("#Attention_bar").html("<h2>Error: Ending bay is smaller than starting bay</h2>");
				$("#Attention_bar").css({"background-color":"#990000"});	
			} else {
				var isOdd = {};
					isOdd.ACGstartingBay = test1%2;
					isOdd.ACGEndingBay   = test2%2;
					if(!isOdd.ACGstartingBay == isOdd.ACGEndingBay) {
						okayJS = false;
						$("#ACGstartingBay").css({"background-color":"#FF4242"});
						$("#ACGEndingBay").css({"background-color":"#FF4242"});
						$("#Attention_bar").html("<h2>Error: Both must be odd or Both must be even</h2>");
						$("#Attention_bar").css({"background-color":"#990000"});	
					} else {
						$("#ACGstartingBay").css({"background-color":"#FFFFFF"});
						$("#ACGEndingBay").css({"background-color":"#FFFFFF"});
					}
			}//end of if for ending bay is smaller than starting bay.
			


		} //end of else for bays numbers are really numbers.
		} //end of else for bays are not blank.
		
		//Put logic here for Aile is less than 10, ie
		// aisle 1 becomes 01  this is only for numeric aisles.
		
		if(okayJS)  {
			var str_ACGaisle = $("#ACGaisle").val();
			var INT_ACGaisle = parseInt(str_ACGaisle);
			if(isNaN(INT_ACGaisle))  {
				str_ACGaisle = str_ACGaisle.toUpperCase();
				$("#ACGaisle").val(str_ACGaisle);
			} else {
				if(INT_ACGaisle < 10) {
					str_ACGaisle = "0"+str_ACGaisle;
					$("#ACGaisle").val(str_ACGaisle);  //If it is numeric and >= 10 just leave it alone.
				}
			}
		
		
		} //end of okayJS for cleaning up aisle, ie is it string or Int, lower case string, or INT < 10?
		
		if(okayJS)  {
			$("#Broken_Ring").show();
			$("#Modal").show();
		}
		return okayJS;	
		}); //end of ACGsubmit click handler.

}); //end of document.ready.

</script>






<div id=ACwrapper>
	<form id=ACGform name=ACGform action=index.php method=post>

		<div id=ACGcolumn01 class=MyColumn> 
			<div class=ACGlabelBackground>
				<span>Warehouse No.</span>
			</div>
			<div class=ACGlabelBackground>
				<span>Aisle</span>
			</div>
			<div class=ACGlabelBackground>
				<span>Starting Bay</span>
			</div>
			
		</div> <!-- End of Column01 -->

		<div id=ACGcolumn02 class=MyColumn> 
			<div class=ACGselectBox>
			<select id=ACGwarehouseNo_sw name=ACGwarehouseNo_sw class=ACGselectTag>
				<option value=0 <?php echo $warehouse_sw_option[0]; ?>> </option>
				<option value=1 <?php echo $warehouse_sw_option[1]; ?>>101</option>
				<option value=2 <?php echo $warehouse_sw_option[2]; ?>>102</option>
				<option value=3 <?php echo $warehouse_sw_option[3]; ?>>402</option>
			</select> 
			</div>
			<input type=text id=ACGaisle name=ACGaisle class=myTextBox value="<?php echo $ACGaisle ?>">
			<input type=text id=ACGstartingBay name=ACGstartingBay class=myTextBox value="<?php echo $ACGstartingBay?>"> 
		</div> <!-- End of Column02 -->

		<div id=ACGcolumn03 class=MyColumn> 
			<div class=ACGlabelBackground>
				<span>Slots Per Bay</span>
			</div>
			<div class=ACGlabelBackground>
				<span>Level</span>
			</div>
			
			<div class=ACGlabelBackground>
				<span>Ending Bay</span>
			</div> 
			<div id=ACGbuttonCancel> 
				<a href="index.php?content_sw=15&attention_bar=Make a Selection&title=Aisle Changes Menu">Return</a>
			</div> 
		</div> <!-- End of Column03. -->
		
		<div id=ACGcolumn04 class=MyColumn> 
			<div class=ACGselectBox>
			<select id=ACGslotsPerBay name=ACGslotsPerBay class=ACGselectTag>
				<option value=0 <?php echo $ACGslotsPerBay_option[0] ?>></option>
				<option value=1 <?php echo $ACGslotsPerBay_option[1] ?>>1</option>
				<option value=2 <?php echo $ACGslotsPerBay_option[2] ?>>2</option>
				<option value=3 <?php echo $ACGslotsPerBay_option[3] ?>>3</option>
				<option value=4 <?php echo $ACGslotsPerBay_option[4] ?>>4</option>
				<option value=5 <?php echo $ACGslotsPerBay_option[5] ?>>5</option>
				<option value=6 <?php echo $ACGslotsPerBay_option[6] ?>>6</option>
				<option value=7 <?php echo $ACGslotsPerBay_option[7] ?>>7</option>
				<option value=8 <?php echo $ACGslotsPerBay_option[8] ?>>8</option>
				<option value=9 <?php echo $ACGslotsPerBay_option[9] ?>>9</option>
				<option value=10 <?php echo $ACGslotsPerBay_option[10] ?>>10</option>
				<option value=11 <?php echo $ACGslotsPerBay_option[11] ?>>11</option>
				<option value=12 <?php echo $ACGslotsPerBay_option[12] ?>>12</option>
			</select> 
			</div>
			<div class=ACGselectBox>
			<select id=ACGlevel name=ACGlevel class=ACGselectTag>
				<option value=0 <?php echo $ACGlevel_option[0]?>></option>
				<option value=1 <?php echo $ACGlevel_option[1]?>>1</option>
				<option value=2 <?php echo $ACGlevel_option[2]?>>2</option>
				<option value=3 <?php echo $ACGlevel_option[3]?>>3</option>
			</select>
			</div>
			<input type=text id=ACGEndingBay name=ACGEndingBay class=myTextBox value="<?php echo $ACGEndingBay?>">
			<input type=submit id=ACGsubmit name=ACGsubmit value=Submit> 
		</div> <!-- End of Column04. -->
		
	</form>
</div> <!-- End of ACwrapper. -->

<div id=Modal>
	<img src=Images/Modal3.jpg >
</div>



<!-- <img src=Images/modal.gif> -->
<div id=Broken_Ring>
	<img src=Images/Spinning-Wheel-Broken-ring.gif >
</div>
