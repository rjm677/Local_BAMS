<?php
/* ACGpartialFormhandler.php
Aisle Changes Generate
*/


require_once('includes/truefalse.php');
$okayPHP = TRUE;
$slot_creation_ctr = 0;
require_once('includes/connect_vars.inc.php');
$dbc_ACG = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if(!$dbc_ACG)  {
	$content_sw =15;
	$title = "Aisle Changes Menu\n";
	$attention_bar = "Error: mysqli_connect failed in ACGpartialFormHandler.php\n";
	$BackgroundRed = TRUE;
	$okayPHP = FALSE;
}  else  {
//  Get form POST variables.
	$ACGwarehouseNo_sw 	= mysqli_real_escape_string($dbc_ACG, trim($_POST['ACGwarehouseNo_sw']));
	$ACGaisle          	= mysqli_real_escape_string($dbc_ACG, trim($_POST['ACGaisle']));
	$ACGstartingBay 	= mysqli_real_escape_string($dbc_ACG, trim($_POST['ACGstartingBay']));
	$ACGslotsPerBay 	= mysqli_real_escape_string($dbc_ACG, trim($_POST['ACGslotsPerBay']));
	$ACGlevel 	        = mysqli_real_escape_string($dbc_ACG, trim($_POST['ACGlevel']));  
	$ACGEndingBay 		= mysqli_real_escape_string($dbc_ACG, trim($_POST['ACGEndingBay']));
	
	$ACGstartingBay    = (INT) $ACGstartingBay;
	$ACGEndingBay	   = (INT) $ACGEndingBay;
	$ACGslotsPerBay    = (INT) $ACGslotsPerBay;
	$ACGlevel		   = (INT) $ACGlevel;
	$ACGwarehouseNo_sw = (INT) $ACGwarehouseNo_sw;
	
	
/*	
	echo $ACGwarehouseNo_sw;
	echo "<br>";
	echo $ACGaisle;
	echo "<br>";
	echo $ACGstartingBay;
	echo "<br>";
	echo $ACGslotsPerBay;
	echo "<br>";
	echo $ACGlevel;
	echo "<br>";
	echo $ACGEndingBay;
	echo "<br>";
*/
	//check and see if aisle row is in aisle table.
	
	$Query01  = "SELECT * \n";
	$Query01 .= "FROM aisle \n";
	$Query01 .= "WHERE WarehouseID = '{$ACGwarehouseNo_sw}' \n";
	$Query01 .= "AND Aisle = '{$ACGaisle}' \n";
	
	$data_aisle_get = mysqli_query($dbc_ACG, $Query01);
	if(!$data_aisle_get) {
		$content_sw = 13;
		$title = "<h2>Generate Aisle Changes</h2>";
		$attention_bar = "<h2>mysqli_query has failed for get aisle record get in ACGpartialFormhandler</h2>\n";
		$BackgroundRed = TRUE;
		$okayPHP = FALSE;
	}  else  {
		if(mysqli_affected_rows($dbc_ACG) > 0)  {
			$row_ACG = mysqli_fetch_array($data_aisle_get);
			$AisleID = $row_ACG['AisleID'];
		} else {
			$Query02  = "INSERT  INTO aisle \n";
			$Query02 .= "(AisleID, WarehouseID, Aisle) \n";
			$Query02 .= "VALUES \n";
			$Query02 .= "('null', '{$ACGwarehouseNo_sw}', '{$ACGaisle}')\n";
			$data_aisle_insert = mysqli_query($dbc_ACG, $Query02);
			if(!$data_aisle_insert) {
				$content_sw = 13;
				$title = "<h2>Generate Aisle Changes</h2>";
				$attention_bar = "<h2>mysqli_query has failed for get aisle record insert in ACGpartialFormhandler</h2>\n";
				$okayPHP = FALSE;
				$BackgroundRed = TRUE;
			} else  {
				if(mysqli_affected_rows($dbc_ACG) != 1) {
					$content_sw = 13;
					$title = "<h2>Generate Aisle Changes</h2>";
					$attention_bar = "<h2>mysqli_query has failed to insert one and only one row in ACGpartialFormhandler</h2>\n";
					$okayPHP = FALSE;
					$BackgroundRed = TRUE;
				} else  {
					$AisleID = mysqli_insert_id($dbc_ACG);
					//one record inserted sucessfully.
					}
				} //End of else for did insert just one row.
			} //End of else for good mysqli_query for inserting an aisle row.
		$SideCode = ($ACGstartingBay % 2);
		$Query03  = "SELECT *\n";
		$Query03 .= "from sides\n";
		$Query03 .= "WHERE AisleID = \n";
		$Query03 .= "'{$AisleID}' AND SideCode = '{$SideCode}'";
		$data_side_search = mysqli_query($dbc_ACG, $Query03);
		if(!$data_side_search)  {
			$content_sw = 13;
			$title = "<h2>Generate Aisle Changes</h2>";
			$attention_bar = "<h2>failed in Query03:" . mysqli_error($dbc_ACG) . "</h2>";
			$okayPHP = FALSE;
			$BackgroundRed = TRUE;
		} else {
			if(mysqli_affected_rows($dbc_ACG) == 1)  {
				$row_getSideCode = mysqli_fetch_array($data_side_search);
				$sidesID = $row_getSideCode['sidesID'];
			} else { //need to insert record in the sides table.
				$Query04  = "INSERT INTO sides \n";
				$Query04 .= "(sidesID, AisleID, SideCode) \n";
				$Query04 .= "VALUES\n";
				$Query04 .= "('null', '{$AisleID}', '{$SideCode}')\n";
				
				$data_sides_insert = mysqli_query($dbc_ACG, $Query04);
				if(!$data_sides_insert) {
					$content_sw = 13;
					$title = "<h2>Generate Aisle Changes</h2>";
					$attention_bar = mysqli_error($dbc_ACG);
					$attention_bar .= "<h2>mysqli_query has failed for Query04 in ACGpartialFormhandler</h2>\n";
					$okayPHP = FALSE;
					$BackgroundRed = TRUE;
				} else {
					$sidesID = mysqli_insert_id($dbc_ACG);
				} //end of else for good sides insert.
			} //end of else for found the correct record in the sides table.
			$stop = $ACGEndingBay + 1;
			$start = $ACGstartingBay;
			//var_dump($start);
			//var_dump($stop);
			
			for($Bay = $start; $Bay < $stop; $Bay = $Bay + 2) {
				//echo $Bay;
				//echo "<br>";
				$Query05  = "SELECT * \n";
				$Query05 .= "FROM bay \n";
				$Query05 .= "WHERE sidesID = '{$sidesID}' \n";
				$Query05 .= "AND bay = '{$Bay}'\n";
				$data_bay_get = mysqli_query($dbc_ACG, $Query05);
				if(!$data_bay_get) {
					$content_sw = 13;
					$title = "<h2>Generate Aisle Changes</h2>";
					$attention_bar  = "<h2>mysqli_query has failed for get bay record get in ACGpartialFormhandler\n";
					$attention_bar .= mysqli_error($dbc_ACG) . "</h2>\n";
					$BackgroundRed = TRUE;
					$okayPHP = FALSE;
					break;
				}  else  {
					
					if(mysqli_affected_rows($dbc_ACG) > 0)  {
						$row_ACG = mysqli_fetch_array($data_bay_get);
						$bayID = $row_ACG['bayID'];
						//var_dump($bayID);
					} else {
					
					
						$Query06  = "INSERT INTO bay \n";
						$Query06 .= "(bayID, sidesID, bay) \n";
						$Query06 .= "VALUES \n";
						$Query06 .= "('null', '{$sidesID}', '{$Bay}')\n";
						$data_bay_insert = mysqli_query($dbc_ACG, $Query06);
						if(!$data_bay_insert) {
							$content_sw = 13;
							$title = "<h2>Generate Aisle Changes</h2>";
							$attention_bar  = "<h2>mysqli_query has failed for get bay record get in ACGpartialFormhandler\n";
							$attention_bar .= mysqli_error($dbc_ACG) . "</h2>\n";
							$BackgroundRed = TRUE;
							$okayPHP = FALSE;
							break;
						} else {
							$bayID = mysqli_insert_id($dbc_ACG);
						
						} // End of Else for good $query06.
					
					}  //end of else for insert bay record in bay table.
					//echo $bayID . "<br>";
				
				 }//End of else for sucessful query into bay table - found or not found (Insert)
				//echo "The level in ACGlevel is: " . "$ACGlevel";
				$Query07 = "SELECT * \n";
				$Query07 .= "FROM level \n";
				$Query07 .= "WHERE bayID = '{$bayID}' AND \n";
				$Query07 .= "the_level = '{$ACGlevel}' \n";
				
				$data_level_get = mysqli_query($dbc_ACG, $Query07);
					
				if(!$data_level_get) {
					$content_sw = 13;
					$title = "<h2>Generate Aisle Changes</h2>";
					$attention_bar = "<h2>mysqli_query failed for searching for level row in Query07";
					$attention_bar .= mysqli_error($dbc_ACG) . "</h2>\n";
					$BackgroundRed = TRUE;
					$okayPHP = FALSE;
					break;
				} else {
					if(mysqli_affected_rows($dbc_ACG) > 0) {
						$row_ACG = mysqli_fetch_array($data_level_get);
						$levelID = $row_ACG['levelID']; 
						//echo "the levelID is: "; var_dump($levelID);
					} else { //must insert level row
						$Query08  = "INSERT INTO level \n";
						$Query08 .= "(levelID, bayID, the_level, slotsPerBay) \n";
						$Query08 .= "VALUES \n";
						$Query08 .= "('null', '{$bayID}', '{$ACGlevel}', '{$ACGslotsPerBay}')\n";
						
						$data_level_insert = mysqli_query($dbc_ACG, $Query08);
						if(!$data_level_insert) {
							$content_sw = 13;
							$title = "<h2>Generate Aisle Changes</h2>";
							$attention_bar = "<h2>mysqli_query failed for insering level row in Query08";
							$attention_bar .= mysqli_error($dbc_ACG) . "</h2>\n";
							$BackgroundRed = TRUE;
							$okayPHP = FALSE;
							break;
						} else  {
							 $levelID = mysqli_insert_id($dbc_ACG);
						} //End of else for good mysqli_query on Query08, for inserting level row.
					} //end of else for must insert level row.
				} //end of else for good mysqli_query for searching for level row.
			
				$slotofslot = ($ACGlevel * 10) + 1;
				//echo "Starting slot of slot is: " . "$slotofslot";
				for($i = 0; $i < $ACGslotsPerBay; $i++) {
					//echo "$slotofslot" . "<br>\n";
					
					$strSlot = "$ACGaisle" . "-";
					if($Bay < 10) {
						$strSlot .= "0" . "$Bay";
					} else {
						$strSlot .= "$Bay";
					}
					
					$strSlot .= $slotofslot;
					//echo "$strSlot" . "<br>";
					
					$Query09  = "SELECT * \n";
					$Query09 .= "FROM slots \n";
					$Query09 .= "WHERE levelID = '{$levelID}' \n";
					$Query09 .= "AND slot_of_slot = '{$slotofslot}'\n";
				
					
					$data_slot_get = mysqli_query($dbc_ACG, $Query09);
					
				if(!$data_slot_get) {
					$content_sw = 13;
					$title = "<h2>Generate Aisle Changes</h2>";
					$attention_bar = "<h2>mysqli_query failed for searching for slot row in Query09";
					$attention_bar .= mysqli_error($dbc_ACG) . "</h2>\n";
					$BackgroundRed = TRUE;
					$okayPHP = FALSE;
					break 2;
				} else {
					if(mysqli_affected_rows($dbc_ACG) == 0) {  //do nothing if already in table
						$Query10  = "INSERT INTO slots \n";
						$Query10 .= "(slotID, levelID, slot, slot_of_slot) \n";
						$Query10 .= "VALUES \n";
						$Query10 .= "('null', '{$levelID}', '{$strSlot}', '{$slotofslot}')\n";
						
						$data_slot_insert = mysqli_query($dbc_ACG, $Query10);
						if(!$data_slot_insert) {
							$content_sw = 13;
							$title = "<h2>Generate Aisle Changes</h2>";
							$attention_bar = "<h2>mysqli_query failed for inserting slot row in Query10";
							$attention_bar .= mysqli_error($dbc_ACG) . "</h2>\n";
							$BackgroundRed = TRUE;
							$okayPHP = FALSE;
							//break 2;
						} else {  //good slot insert.
							$slot_creation_ctr++;
						
						} //End of else for good slot insert in slots table.
					
					}// End of if for slot row is not already in the table.
					
				} //End of else for search for slot row, good query09. 	
					
					
					
					$slotofslot++;
				} // End of slot inner for loop.





			
				
			} //end of bay for loop.

			// Return to slot input form, display total slots created on attention bar.
			if($okayPHP)  {
				$content_sw = 13;
				$title = "<h2>Generate Aisle Changes</h2>";
				$attention_bar = "<h2>Total slots created: $slot_creation_ctr ";
			} //End of $okayPHP is TRUE.
		} //End of else for good Query03, a record has been inserted into the sides table.
	} // End of else for good mysqli_query for aisle_get.

		$warehouse_sw_option = array();
		for($i=0;$i<4;$i++)  {
		$warehouse_sw_option[$i] = " ";
		}	
	$warehouse_sw_option[$ACGwarehouseNo_sw] = 'selected ="selected"';
	
	
	
	
		$ACGlevel_option = array();
		for($j=0;$j<4;$j++)  {
		$ACGlevel_option[$j] = " ";
		}	
	 //echo "ACGlevel is: $ACGlevel \n";
	$ACGlevel_option[$ACGlevel] = 'selected ="selected"';
	
	
	
	
		$ACGslotsPerBay_option = array();
		for($i=0;$i<13;$i++)  {
		$ACGslotsPerBay_option[$i] = " ";
		}
		//var_dump($ACGslotsPerBay_option);
	// echo "ACGslotsPerBay is: $ACGslotsPerBay\n";
	$ACGslotsPerBay_option[$ACGslotsPerBay] = 'selected ="selected"';
	
} //end of else for we have a good mysqli_connect().
?>