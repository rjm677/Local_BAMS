<!--  EEPpartial.php          -->
<!--  Employee Edit Partial   -->

<script>
$(document).ready(function()  {
	$("#EEPsubmit").click(function()  {
		var okayJS = true;
		var x;
		var y;
		var z;
		$("select").each(function()  {
			x = $(this).val();
			//alert(x);
			
			if(x == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				$(this).css({"background-color":"#FFFFFF"});
			} 
		});
		
		
		$("input").each(function()  {
			x = $(this).val();
			//alert(x);
			y = x.length;
			//alert(y);
			
			if(y == 0)  {
				okayJS = false;
				$(this).css({"background-color":"#FF4242"});
			}  else  {
				z = $(this).attr("type");
				if(z != "submit")  {
					$(this).css({"background-color":"#FFFFFF"});
				}
			}
		});
		if(!okayJS)  {
			$("#Attention_bar").html("<h2>Error: Required Field(s) Blank</h2>");
			$("#Attention_bar").css({"background-color":"#990000"});
		}
		return okayJS;
	});
});
</script>

<div id=EEPwrapper>
	<form id=EEPform name=EEPform action=index.php method=post>
	<div id=EEPleft>
		<div class=EEPlabelBackground>
			<span>Warehouse No.</span>
		</div>
		<div class=EEPlabelBackground>
			<span>Shift</span>
		</div>
		<div class=EEPlabelBackground>
			<span>First Name</span>
		</div>
		<div class=EEPlabelBackground>
			<span>Last Name</span>
		</div>
		<div class=EEPlabelBackground>
			<span>Man Number</span>
		</div>
		<div id=EEPbuttonCancel>
			<a href="index.php?content_sw=6&attention_bar=Make a Selection&title=Employee Menu">Cancel</a>
		</div>
	</div> <!-- End of #EIPleft.  -->
	<div id=EEPright>
		<div class=EEPselectBox>
			<select id=EEPwarehouseNo_sw name=EEPwarehouseNo_sw class=EEPselectTag>
				<option value=0> </option>  <!-- one of the below options will have 
				                                 selected="selected" included in tag.  -->
				<option value=1 <?php echo $SelectedWarehouseNo[0];?>>101</option>
				<option value=2 <?php echo $SelectedWarehouseNo[1];?>>102</option>
				<option value=3 <?php echo $SelectedWarehouseNo[2];?>>402</option>
			</select> 
		</div>
	
		<div class=EEPselectBox>  
			<select id=EEPshift_sw  name=EEPshift_sw class=EEPselectTag>
				<option value=0> </option> <!-- one of the below options will have
												selected="selected" included in tag.  -->
				<option value=1 <?php echo $SelectedShift[0];?>>1st</option>
				<option value=2 <?php echo $SelectedShift[1];?>>2nd</option>
				<option value=3 <?php echo $SelectedShift[2];?>>3rd</option>
			</select> 
		</div>
		<input type=hidden id=EMPemployeeIndex name=EMPemployeeIndex value="<?php echo $EMPemployeeIndex;?>" >
		<input type=text   id=EEPFirstName  name=EEPFirstName  value="<?php echo $EMPFirstName;?>" >
		<input type=text   id=EEPLastName   name=EEPLastName   value="<?php echo $EMPLastName;?>">
		<input type=text   id=EEPmanNumber     name=EEPmanNumber     value="<?php echo $EMPmanNumber;?>">
		<input type=submit name=EEPsubmit id=EEPsubmit value=Submit>
	
	</div> <!-- End of EEPright -->
	</form>
	
</div> <!-- End of #EEPwrapper.   -->